
$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new()
$shared='C:/Mac/Home/Documents/FPGA/FPGA_latency_refresh_20261030/tests/bitstream_driver_validation'
$config=Get-Content "$shared/request.json" -Raw | ConvertFrom-Json
$original=$config.vm_original_build
$clone=$config.vm_clone_build
$tool='C:/pango/PDS_2022.2-SP6.4/bin/pds_shell.exe'
$firmwareExtensions=@('.sbit','.bit','.bin')
$proc=$null
$exitCode=$null
$errorMessage=$null
$success=$false
$originalBefore=$null
$originalPnrBefore=$null
$clonePnrBefore=$null
$originalPnrAfter=$null
$clonePnrAfter=$null
$files=[ordered]@{}
$logFiles=[ordered]@{}
function Convert-Map($value) {
 $result=[ordered]@{}
 foreach($entry in $value.PSObject.Properties){$result[$entry.Name]=[string]$entry.Value}
 return $result
}
$expectedSources=Convert-Map $config.source_sha256
function Get-HashTree([string]$directory,[string]$filter='*') {
 $result=[ordered]@{}
 $base=(Get-Item -LiteralPath $directory).FullName
 Get-ChildItem -LiteralPath $directory -Recurse -File -Filter $filter | Sort-Object FullName | ForEach-Object {
  $name=$_.FullName.Substring($base.Length+1).Replace([char]92,'/')
  $result[$name]=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
 }
 return $result
}
function Assert-EqualMaps($actual,$expected,[string]$label) {
 if($actual.Count -ne $expected.Count){throw "$label inventory changed"}
 foreach($key in $expected.Keys){if($actual[$key] -cne $expected[$key]){throw "$label changed: $key"}}
}
function Assert-BoundEvidence {
 foreach($entry in $config.bound_files_vm_sha256.PSObject.Properties) {
  if((Get-FileHash -LiteralPath $entry.Name -Algorithm SHA256).Hash.ToLowerInvariant() -cne $entry.Value){throw "Audited evidence changed: $($entry.Name)"}
 }
 $rtr=Join-Path $original 'report_timing/video_correct_ddr_top.rtr'
 if((Get-FileHash -LiteralPath $rtr -Algorithm SHA256).Hash.ToLowerInvariant() -cne $config.rtr_sha256){throw 'VM RTR differs from the audited report'}
}
function Assert-SourceInputs {
 foreach($directory in @($config.vm_sources,$config.host_sources)) {
  $actual=[ordered]@{}
  Get-ChildItem -LiteralPath $directory -File | ForEach-Object {$actual[$_.Name]=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()}
  if($actual.Count -ne 151){throw 'Need exactly151 staged sources'}
  Assert-EqualMaps $actual $expectedSources '151 source SHA256'
 }
 foreach($entry in @(@{name='source_manifest.json';hash=$config.manifest_sha256},@{name='build_full.tcl';hash=$config.build_tcl_sha256})) {
  if((Get-FileHash -LiteralPath (Join-Path $config.vm_project $entry.name) -Algorithm SHA256).Hash.ToLowerInvariant() -cne $entry.hash){throw "Staged project changed: $($entry.name)"}
 }
}
function Assert-NoFirmware([string]$directory) {
 $existing=@(Get-ChildItem -LiteralPath $directory -Recurse -File | Where-Object {$_.Extension -in $firmwareExtensions})
 if($existing.Count){throw 'Refusing original/clone build with preexisting bitstream output'}
}
function Assert-OriginalUnchanged {
 Assert-EqualMaps (Get-HashTree $original) $originalBefore 'Original native build'
 Assert-EqualMaps (Get-HashTree $original '*_pnr.adf') $originalPnrBefore 'Original PNR DB'
 Assert-EqualMaps (Get-HashTree $clone '*_pnr.adf') $clonePnrBefore 'Cloned PNR DB'
 Assert-SourceInputs
 Assert-BoundEvidence
}
function Test-ForbiddenAction([string]$text) {
 if($text -match '(?im)^\s*Executing\s*:\s*(compile|synthesize|dev_map|pnr)\b'){return $true}
 foreach($match in [regex]::Matches($text,'(?im)^\s*Process\s+"([^"]+)"\s+started')) {
  if(($match.Groups[1].Value.ToLowerInvariant() -replace '[^a-z]','') -cne 'generatebitstream'){return $true}
 }
 return $false
}
function Stop-CloneTree {
 if($null -ne $proc) {
  $proc.Refresh()
  if(!$proc.HasExited){& "$env:SystemRoot/System32/taskkill.exe" /PID $proc.Id /T /F | Out-Null}
 }
}
function Get-CurrentLog {
 $text=''
 foreach($name in @('firmware_tool.log','firmware_tool.err')) {
  $path=Join-Path $clone $name
  if(Test-Path -LiteralPath $path){$text+=Get-Content -LiteralPath $path -Raw -ErrorAction SilentlyContinue}
 }
 return $text
}
try {
 Assert-BoundEvidence
 Assert-SourceInputs
 Assert-NoFirmware $original
 if(Test-Path -LiteralPath $clone){throw 'Firmware clone already exists; refusing stale generation'}
 $originalBefore=Get-HashTree $original
 $originalPnrBefore=Get-HashTree $original '*_pnr.adf'
 if(!$originalPnrBefore.Contains('place_route/video_correct_ddr_top_pnr.adf')){throw 'Audited native PNR DB is missing'}
 $projects=@(Get-ChildItem -LiteralPath $original -File -Filter '*.pds')
 if($projects.Count -ne 1){throw 'Need one unambiguous original PDS project'}
 $projectText=Get-Content -LiteralPath $projects[0].FullName -Raw
 foreach($option in @('prj_work_dir','prj_impl_dir')) {
  if($projectText -notmatch ('\(_option\s+'+$option+'\s+\(_string\s+"\."\)')){throw 'PDS working/implementation directory is not proven relative'}
 }
 foreach($command in @('cmd_compile','cmd_synthesize','cmd_devmap','cmd_pnr','cmd_report_post_pnr_timing')) {
  $pattern='\(_command\s+'+$command+'\s+\(_gci_state\s+\(_integer\s+2\)\)' 
  if($projectText -notmatch $pattern){throw "Audited PDS predecessor is not completed: $command"}
 }
 $normalized=$projectText.Replace([char]92,'/')
 if($normalized.IndexOf($original,[StringComparison]::OrdinalIgnoreCase) -ge 0){throw 'PDS retains an absolute original-build path; isolated generation is not proven'}
 Copy-Item -LiteralPath $original -Destination $clone -Recurse
 Assert-EqualMaps (Get-HashTree $clone) $originalBefore 'Complete native build clone'
 Assert-NoFirmware $clone
 $clonePnrBefore=Get-HashTree $clone '*_pnr.adf'
 Assert-EqualMaps $clonePnrBefore $originalPnrBefore 'Cloned PNR DB'
 $project=Join-Path $clone $projects[0].Name
 $proc=Start-Process -FilePath $tool -WorkingDirectory $clone -ArgumentList @('-project',$project,'-run','gen_bit_stream') -PassThru -NoNewWindow -RedirectStandardOutput "$clone/firmware_tool.log" -RedirectStandardError "$clone/firmware_tool.err"
 $null=$proc.Handle
 @{status='running';pid=$proc.Id;hardware_accessed=$false;clone=$clone} | ConvertTo-Json | Set-Content "$shared/vm_status.json" -Encoding UTF8
 $deadline=[DateTime]::UtcNow.AddMinutes(30)
 while(!$proc.WaitForExit(250)) {
  if(Test-ForbiddenAction (Get-CurrentLog)){Stop-CloneTree;throw 'PDS scheduled a forbidden upstream/non-bitstream action'}
  if([DateTime]::UtcNow -gt $deadline){Stop-CloneTree;throw 'Bitstream generation timed out'}
 }
 $proc.WaitForExit()
 $proc.Refresh()
 if($null -eq $proc.ExitCode){throw 'Native exit code is unavailable'}
 $exitCode=[int]$proc.ExitCode
 $text=Get-CurrentLog
 if(Test-ForbiddenAction $text){Stop-CloneTree;throw 'PDS scheduled a forbidden upstream/non-bitstream action'}
 if($exitCode -ne 0 -or $text -match '(?im)^\s*E:'){throw 'PDS bitstream action failed'}
 Assert-OriginalUnchanged
 $generated=@(Get-ChildItem -LiteralPath $clone -Recurse -File | Where-Object {$_.Extension -in $firmwareExtensions})
 if(!$generated.Count){throw 'PDS produced no new firmware output'}
 foreach($file in $generated) {
  if($file.Length -le 0){throw "Empty generated firmware: $($file.Name)"}
  if($files.Contains($file.Name)){throw 'Generated firmware basenames collide'}
  $files[$file.Name]=(Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
 }
 Assert-SourceInputs
 Assert-BoundEvidence
 foreach($file in $generated) {
  $target=Join-Path $shared $file.Name
  if(Test-Path -LiteralPath $target){throw 'Refusing to overwrite local firmware'}
  Copy-Item -LiteralPath $file.FullName -Destination $target
  if((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -cne $files[$file.Name]){throw 'Copied firmware hash mismatch'}
 }
 Assert-OriginalUnchanged
 $success=$true
} catch {
 $errorMessage=$_.Exception.Message
 Stop-CloneTree
} finally {
 try {
  if($null -ne $originalPnrBefore){$originalPnrAfter=Get-HashTree $original '*_pnr.adf'}
  if($null -ne $clonePnrBefore){$clonePnrAfter=Get-HashTree $clone '*_pnr.adf'}
  if($success) {
   Assert-EqualMaps $originalPnrAfter $originalPnrBefore 'Final original PNR DB'
   Assert-EqualMaps $clonePnrAfter $clonePnrBefore 'Final cloned PNR DB'
  }
 } catch {
  $success=$false
  $errorMessage='Final DB hash verification failed: '+$_.Exception.Message
 }
 if(Test-Path -LiteralPath $clone) {
  Get-ChildItem -LiteralPath $clone -Recurse -File -Filter '*.log' | ForEach-Object {
   $relative=$_.FullName.Substring((Get-Item -LiteralPath $clone).FullName.Length+1).Replace([char]92,'/')
   $hash=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
   if($null -eq $originalBefore -or !$originalBefore.Contains($relative) -or $hash -cne $originalBefore[$relative]) {
    $target=Join-Path "$shared/logs" $relative
    New-Item -ItemType Directory -Force (Split-Path $target) | Out-Null
    Copy-Item -LiteralPath $_.FullName -Destination $target
    $logFiles[$relative]=$hash
   }
  }
  if(Test-Path -LiteralPath "$clone/firmware_tool.err") {
   New-Item -ItemType Directory -Force "$shared/logs" | Out-Null
   Copy-Item -LiteralPath "$clone/firmware_tool.err" -Destination "$shared/logs/firmware_tool.err"
  }
 }
 $mainHash=$null
 if($null -ne $originalPnrBefore){$mainHash=$originalPnrBefore['place_route/video_correct_ddr_top_pnr.adf']}
 @{passed=$success;status=if($success){'completed'}else{'failed'};returncode=$exitCode;error=$errorMessage;
   hardware_accessed=$false;clone=$clone;pnr_db_sha256=$mainHash;pnr_db_sha256_all=$originalPnrBefore;
   pnr_db_evidence=@{original_before=$originalPnrBefore;clone_before=$clonePnrBefore;original_after=$originalPnrAfter;clone_after=$clonePnrAfter};
   files=$files;logs=$logFiles;source_sha256=$config.source_sha256;native_audit_sha256=$config.native_audit_sha256;
   original_and_clone_pnr_unchanged=$success;original_build_unchanged=$success;sources_unchanged=$success} |
   ConvertTo-Json -Depth 12 | Set-Content "$shared/vm_result.json" -Encoding UTF8
}
if(!$success){exit 1}
exit 0
