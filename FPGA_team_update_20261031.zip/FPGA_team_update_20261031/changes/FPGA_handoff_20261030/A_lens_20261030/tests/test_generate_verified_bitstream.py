import importlib.util
import json
import re
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location('verified_bitstream',ROOT/'tools/generate_verified_bitstream.py')
driver=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(driver)


class BitstreamGateTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir=ROOT/'tests')
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        candidate=self.root/'candidate'
        (candidate/'sources').mkdir(parents=True)
        (candidate/'project').mkdir()
        self.candidate=candidate
        self.build=candidate/'build/native_test'
        (self.build/'report_timing').mkdir(parents=True)
        (self.build/'place_route').mkdir()
        for n in range(150):(candidate/f'sources/test_{n}.v').write_text(f'// synthetic test fixture {n}\n')
        shutil.copyfile(driver.REFERENCE_FDC,candidate/'sources/board_ddr.fdc')
        sources=driver.source_hashes(candidate/'sources')
        manifest=candidate/'project/source_manifest.json'
        manifest.write_text(json.dumps({'source_sha256':sources}))
        (candidate/'project/build_full.tcl').write_text('// nonexecutable test fixture\n')
        from audit_native import timing_rows
        reference=timing_rows((driver.REFERENCE/'video_correct_ddr_top.rtr').read_text(),require_pass=False)
        lines=['PG2L100H FBG676 2022.2-SP6.4','Timing analysis mode : multi corner',
               'Design Summary : All Constraints Met.']
        lines += [f'{name} {period:.6f} {{0 1}}' for name,period in driver.CLOCKS.items()]
        for kind in ['Setup','Hold','Recovery','Removal','Minimum Pulse Width']:
            for corner in ['Slow','Fast']:
                lines.append(f'{kind} Summary({corner} Corner):')
                lines += [' '.join(row['clocks'])+' 1.000 0.000 0 1' for row in reference if row['kind']==kind and row['corner']==corner]
                lines.append('='*30)
        vm='C:/Temp/FPGA_opt/native_test/build'
        lines.append(vm+'/place_route/video_correct_ddr_top_pnr.adf')
        report=self.build/'report_timing/video_correct_ddr_top.rtr'
        report.write_text('\n'.join(lines))
        for name in ['video_correct_ddr_top.prr','video_correct_ddr_top_prr.prt']:
            shutil.copyfile(driver.REFERENCE/name,self.build/'place_route'/name)
        record=dict(candidate=str(candidate),status='completed',returncode=0,hardware_accessed=False,
                    source_sha256=sources,sources_unchanged=True,vm_local_build=vm,
                    manifest_sha256=driver.sha(manifest),build_tcl_sha256=driver.sha(candidate/'project/build_full.tcl'),
                    io_and_timing_constraints_unchanged=True,firmware_generation_requested=False,
                    reports={'report_timing/video_correct_ddr_top.rtr':driver.sha(report)})
        driver.write_json(self.build/'offline_build_inputs.json',record)
        driver.write_json(self.build/'vm_source_verification.json',dict(passed=True,stage='before_and_after_build',
                          source_count=151,hardware_accessed=False,source_sha256=sources,
                          manifest_sha256=record['manifest_sha256'],build_tcl_sha256=record['build_tcl_sha256']))
        io=driver.io_check(self.build/'place_route/video_correct_ddr_top.prr',self.build/'place_route/video_correct_ddr_top_prr.prt')
        audit=dict(passed=True,hardware_accessed=False,failures=[],
                   timing=dict(passed=True,row_count=104,minimum_slack_ns=1.,report_sha256=driver.sha(report)),io=io,
                   native_inputs_sha256=driver.sha(self.build/'offline_build_inputs.json'),source_manifest_sha256=record['manifest_sha256'])
        driver.write_json(self.build/'native_audit.json',audit)

    def test_complete_synthetic_gate_prepares_without_running(self):
        gate=driver.validate_native_build(self.build)
        self.assertEqual(len(gate['source_sha256']),151)
        out=driver.prepare(self.build,gate)
        self.assertTrue((out/'run_vm.ps1').is_file())
        status=driver.read_json(out/'verification.json')
        self.assertFalse(status['passed'])
        self.assertFalse(status['hardware_accessed'])
        self.assertEqual(status['status'],'prepared_only')
        self.assertFalse(list(out.glob('*.sbit')))

    def test_failed_real_v6_is_refused_before_writes(self):
        build=ROOT/'candidate_optimized_v6/build/pds_20261031_112703_b935c'
        before=(build/'firmware_verified').exists()
        with self.assertRaisesRegex(ValueError,'Native audit'):
            driver.validate_native_build(build)
        self.assertEqual((build/'firmware_verified').exists(),before)

    def test_stale_report_missing_source_and_incomplete_vm_evidence_rejected(self):
        report=self.build/'report_timing/video_correct_ddr_top.rtr'
        report.write_text(report.read_text()+'\nstale report mutation')
        with self.assertRaisesRegex(ValueError,'timing report'):
            driver.validate_native_build(self.build)
        # Restore the fixture via setUp to test an independent missing source.
        self.setUp()
        (self.candidate/'sources/test_0.v').unlink()
        with self.assertRaisesRegex(ValueError,'151'):
            driver.validate_native_build(self.build)
        self.setUp()
        path=self.build/'vm_source_verification.json'
        data=driver.read_json(path);data['stage']='before_build';driver.write_json(path,data)
        with self.assertRaisesRegex(ValueError,'before and after'):
            driver.validate_native_build(self.build)

    def test_script_uses_existing_project_and_fail_closed_process_guard(self):
        out=driver.prepare(self.build,driver.validate_native_build(self.build))
        text=(out/'run_vm.ps1').read_text()
        self.assertIn("'-project'",text)
        self.assertIn("'-run','gen_bit_stream'",text)
        self.assertNotIn("'-file'",text)
        self.assertNotIn('-input_db_file',text)
        self.assertIn('$null=$proc.Handle',text)
        self.assertIn('$proc.Refresh()',text)
        self.assertIn('/T /F',text)
        self.assertIn('Assert-SourceInputs',text)
        self.assertIn('Assert-OriginalUnchanged',text)
        self.assertIn('Assert-NoFirmware',text)
        self.assertIn(".Replace([char]92,'/')",text)
        option=re.search(r"\$projectText -notmatch \('([^']*)'\+\$option\+'([^']*)'\)",text)
        self.assertIsNotNone(option)
        option_pattern=option[1]+'prj_work_dir'+option[2]
        self.assertRegex('(_option prj_work_dir (_string "."))',option_pattern)
        state=re.search(r"\$pattern='([^']*)'\+\$command\+'([^']*)'",text)
        self.assertIsNotNone(state)
        state_pattern=state[1]+'cmd_pnr'+state[2]
        self.assertRegex('(_command cmd_pnr\n (_gci_state (_integer 2)))',state_pattern)
        self.assertNotRegex('(_command cmd_pnr\n (_gci_state (_integer 0)))',state_pattern)
        self.assertIn(r"(?im)^\s*Executing\s*:\s*(compile|synthesize|dev_map|pnr)\b",text)
        self.assertIn(r'(?im)^\s*Process\s+"([^"]+)"\s+started',text)

    def test_upstream_detector_ignores_architecture_message(self):
        self.assertFalse(driver.forbidden_action('Compiling architecture definition.'))
        self.assertFalse(driver.forbidden_action('Process "Generate Bitstream" started.'))
        for text in ['Process "Compile" started.','Process "Synthesize" started.',
                     'Process "Device Map" started.','Process "Place & Route" started.',
                     'Executing : pnr -gplace_seed 73','Process "Report Timing" started.']:
            self.assertTrue(driver.forbidden_action(text),text)

    def fake_vm_result(self,out,mutate_sources=False,mutate_clone_pnr=False):
        config=driver.read_json(out/'request.json')
        # Deliberately unusable bytes; this exercises collection metadata only.
        firmware=out/'fixture.sbit'
        firmware.write_bytes(b'UNIT TEST FIXTURE -- NOT AN FPGA BITSTREAM')
        db={'place_route/video_correct_ddr_top_pnr.adf':'a'*64,
            'place_route/route_constraint_ite_1/video_correct_ddr_top_pnr.adf':'b'*64}
        evidence={name:db.copy() for name in ['original_before','clone_before','original_after','clone_after']}
        if mutate_clone_pnr:evidence['clone_after']['place_route/route_constraint_ite_1/video_correct_ddr_top_pnr.adf']='c'*64
        driver.write_json(out/'vm_result.json',dict(passed=True,returncode=0,hardware_accessed=False,
            source_sha256=config['source_sha256'],native_audit_sha256=config['native_audit_sha256'],
            original_and_clone_pnr_unchanged=True,original_build_unchanged=True,sources_unchanged=True,
            pnr_db_sha256='a'*64,pnr_db_sha256_all=db,pnr_db_evidence=evidence,
            files={'fixture.sbit':driver.sha(firmware)},logs={}))
        if mutate_sources:(self.candidate/'sources/test_1.v').write_text('changed while external action ran')
        return 0

    def test_synthetic_collection_checks_returned_bindings_and_hashes(self):
        out=driver.prepare(self.build,driver.validate_native_build(self.build))
        with patch.object(driver.vm_exec,'run_file',side_effect=lambda *a,**k:self.fake_vm_result(out)):
            result=driver.execute(out)
        self.assertTrue(result['passed'])
        self.assertEqual(result['files']['fixture.sbit'],driver.sha(out/'fixture.sbit'))

    def test_external_success_cannot_hide_a_late_source_change(self):
        out=driver.prepare(self.build,driver.validate_native_build(self.build))
        with patch.object(driver.vm_exec,'run_file',side_effect=lambda *a,**k:self.fake_vm_result(out,True)):
            result=driver.execute(out)
        self.assertFalse(result['passed'])
        self.assertTrue(result['errors'])

    def test_external_success_cannot_hide_nested_clone_pnr_changes(self):
        out=driver.prepare(self.build,driver.validate_native_build(self.build))
        with patch.object(driver.vm_exec,'run_file',side_effect=lambda *a,**k:self.fake_vm_result(out,mutate_clone_pnr=True)):
            result=driver.execute(out)
        self.assertFalse(result['passed'])
        self.assertTrue(any('PNR DB hashes changed' in error for error in result['errors']))


if __name__=='__main__':unittest.main()
