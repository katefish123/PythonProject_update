"""Reproducible admission/capture RTL checks; no hardware or PDS invocation."""
from pathlib import Path
import hashlib
import json
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
SOURCES = ROOT / "sources"
OUT = ROOT / "verification"
OUT.mkdir(exist_ok=True)
names = ["continuous_source_path.v", "continuous_capture_rx.v"]
files = [SOURCES / name for name in names] + [ROOT / "tests/tb_capture_admission.sv"]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
before = {str(p.relative_to(ROOT)): sha(p) for p in files}
started = time.time()
compile_run = subprocess.run(["iverilog", "-g2012", "-Wall", "-s", "tb_capture_admission", "-o", str(OUT / "unit.vvp"), *map(str, files)], text=True, capture_output=True)
(OUT / "unit_compile.log").write_text(compile_run.stdout + compile_run.stderr)
assert compile_run.returncode == 0, compile_run.stderr
simulation = subprocess.run(["vvp", str(OUT / "unit.vvp")], text=True, capture_output=True, timeout=30)
(OUT / "unit_simulation.log").write_text(simulation.stdout + simulation.stderr)
passed = simulation.returncode == 0 and "PASS CAPTURE_ADMISSION_UNIT" in simulation.stdout
record = {
    "passed": passed,
    "hardware_accessed": False,
    "pds_invoked": False,
    "scope": "Actual native capture receiver, acknowledged rearm CDC, processing-clock input-rate classification, small full-frame data and terminal flow. Scaled periods; not1080p latency or physical timing qualification.",
    "source_sha256": before,
    "sources_unchanged": before == {str(p.relative_to(ROOT)): sha(p) for p in files},
    "elapsed_seconds": time.time() - started,
    "observations": simulation.stdout.splitlines(),
}
(OUT / "unit_verification.json").write_text(json.dumps(record, indent=2))
print(json.dumps(record, indent=2))
raise SystemExit(0 if passed else 1)
