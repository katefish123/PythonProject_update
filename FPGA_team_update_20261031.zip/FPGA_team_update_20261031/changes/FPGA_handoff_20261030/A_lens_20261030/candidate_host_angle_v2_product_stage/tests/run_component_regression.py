"""Exact pixel/address regressions for the registered cache and affine boundaries."""
from pathlib import Path
import hashlib,json,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
results=[]
for name in ['cache_native','cache_small','affine']:
    case=ROOT/'tests/component_regression'/name
    out=ROOT/'verification/component_regression'/name
    out.mkdir(parents=True,exist_ok=True)
    inputs=list(case.glob('*.hex'))+list(case.glob('*.sv'))+list(case.glob('*.v'))
    inputs += ([ROOT/'sources/ddr_quad_tile_cache.v'] if name.startswith('cache') else
               [ROOT/'sources'/n for n in ['lens_affine_instance.v','lens_distort_coord.v','bilinear_interp.v']])
    locked={str(p.relative_to(ROOT)):sha(p) for p in inputs}
    for p in case.glob('*.hex'):shutil.copy2(p,out/p.name)
    top='tb' if name.startswith('cache') else 'tb_affine_retime'
    parameters=[] if name.startswith('cache') else ['-P'+top+'.N='+str(json.loads((case/'parameters.json').read_text())['N'])]
    files=[p for p in inputs if p.suffix in ['.sv','.v']]
    commands=[(['iverilog','-g2012','-s',top,*parameters,'-o',str(out/'sim.vvp'),*map(str,files)],'compile.log'),
              (['vvp',str(out/'sim.vvp')],'simulation.log')]
    for argv,log in commands:
        with (out/log).open('w') as f:r=subprocess.run(argv,cwd=out,stdout=f,stderr=subprocess.STDOUT,timeout=180)
        if r.returncode:raise SystemExit((out/log).read_text())
    text=(out/'simulation.log').read_text()
    passed=('TIMING_COMPONENT_PASS' in text or 'PASS AFFINE_RETIME' in text) and 'FATAL' not in text
    assert all(sha(ROOT/p)==h for p,h in locked.items()),'Component input changed'
    record={'name':name,'passed':passed,'hardware_accessed':False,'input_sha256':locked,'observations':text.splitlines()}
    (out/'verification.json').write_text(json.dumps(record,indent=2)+'\n');results.append(record)
    print(name,'PASS' if passed else 'FAIL',flush=True)
    if not passed:raise SystemExit(1)
record={'passed':all(x['passed'] for x in results),'hardware_accessed':False,'checks':results}
(ROOT/'verification/component_regression/verification.json').write_text(json.dumps(record,indent=2)+'\n')
