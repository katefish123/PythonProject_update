from pathlib import Path
import hashlib,json,subprocess

ROOT=Path(__file__).resolve().parents[1]
PROJECT=ROOT.parent
S=ROOT/'sources';O=ROOT/'verification';O.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
reference=ROOT/'tests/reference_continuous_source_path_v2.v'
refcopy=O/'continuous_source_path_reference.v'
refcopy.write_text(reference.read_text().replace('module continuous_source_path #(', 'module continuous_source_path_reference #(',1)
                  .replace('module capture_admission_control #(', 'module capture_admission_control_reference #(',1)
                  .replace('  capture_admission_control #(', '  capture_admission_control_reference #(',1))
files=[S/n for n in ['continuous_source_path.v','continuous_capture_rx.v','continuous_capture_writer.v','manager_raw.v','c_frame_mode_controller.v',
                     'async_packet_stream.v','async_packet_fifo.v','async_packet_stream_monitored.v','async_packet_fifo_monitored.v','snapshot_cdc.v']]
files += [refcopy,ROOT/'tests/tb_recovery_ownership.sv']
locked={str(p):sha(p) for p in [reference,*files,Path(__file__)]}
observations=[]
cases=[('recovery',{'MODE_RAW':1},[]),('steady',{'MODE_RAW':0},[]),
       ('bad_retry',{'BAD_RETRY':1,'VS_PHASE':1},['+hold_ns=56060'])]
for label,parameters,plusargs in cases:
    compile_args=['iverilog','-g2012','-Wall','-s','tb_recovery_ownership']
    compile_args += ['-Ptb_recovery_ownership.'+k+'='+str(v) for k,v in parameters.items()]
    compile_args += ['-o',str(O/(label+'.vvp')),*map(str,files)]
    for argv,log in [(compile_args,label+'_compile.log'),
                     (['vvp',str(O/(label+'.vvp')),*plusargs],label+'_simulation.log')]:
        with (O/log).open('w') as f:r=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT,timeout=60)
        if r.returncode:print((O/log).read_text());raise SystemExit(r.returncode)
    observations+=(O/(label+'_simulation.log')).read_text().splitlines()
text='\n'.join(observations)
record={'passed':all(s in text for s in ['PASS RAW_LEASE_POST_BEGIN_DEADLOCK_REPRODUCED','PASS STEADY_IDENTICAL_CAPTURE_VS','PASS BAD_TERMINAL_CREDIT_RACE_REPRODUCED']),'hardware_accessed':False,'pds_invoked':False,
        'scope':'Actual source receiver/writer/manager/credit CDC plus actual c_frame_mode_controller; explicit31ms processing/30fps display timing model scaled to8us input frames. No image math or physical latency claim.',
        'clock_model':{'proc_period_ns':10,'rx_period_ns':8,'ui_period_ns':6,'proc_ticks_per_ms':48,'input_period_ns':8000,'display_period_ns':16000,'processing_ns':14880},
        'bad_terminal_case':{'hold_source_write_until_ns':56060,'vs_phase_rx_cycles':1,'physical_bad_frame':5,'note':'Deliberately delayed source write ACK to exercise credit/rearm ordering, not measured physical DDR service.'},
        'input_sha256':locked,'sources_unchanged':all(sha(Path(p))==h for p,h in locked.items()),'observations':observations}
(O/'recovery_verification.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record,indent=2))
raise SystemExit(0 if record['passed'] and record['sources_unchanged'] else 1)
