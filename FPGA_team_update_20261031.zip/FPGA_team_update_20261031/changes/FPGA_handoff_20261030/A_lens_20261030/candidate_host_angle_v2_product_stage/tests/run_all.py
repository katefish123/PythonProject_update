"""Run capture, rate boundaries and actual source/DDR-owner integration in Icarus."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
S = ROOT / "sources"
OUT = ROOT / "verification"
OUT.mkdir(exist_ok=True)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
locked = {p.name: sha(p) for p in S.iterdir() if p.is_file()}
started = time.time()
base = ["continuous_source_path.v", "continuous_capture_rx.v"]
integration = base + ["continuous_capture_writer.v", "manager_raw.v", "async_packet_stream.v", "async_packet_fifo.v", "async_packet_stream_monitored.v", "async_packet_fifo_monitored.v", "snapshot_cdc.v"]
checks = []

def run(name, top, bench, files, parameters=None, simulate=True):
    compile_args = ["iverilog", "-g2012", "-Wall", "-s", top, "-o", str(OUT / (name + ".vvp"))]
    for key, value in (parameters or {}).items():
        compile_args.append(f"-P{top}.{key}={value}")
    compile_args += [str(S / p) for p in files]
    if bench:
        compile_args.append(str(ROOT / "tests" / bench))
    result = subprocess.run(compile_args, text=True, capture_output=True)
    (OUT / (name + "_compile.log")).write_text(result.stdout + result.stderr)
    passed = result.returncode == 0
    observations = []
    if passed and simulate:
        sim = subprocess.run(["vvp", str(OUT / (name + ".vvp"))], text=True, capture_output=True, timeout=60)
        (OUT / (name + "_simulation.log")).write_text(sim.stdout + sim.stderr)
        passed = sim.returncode == 0 and "PASS " in sim.stdout
        observations = sim.stdout.splitlines()
    record = {"name": name, "passed": passed, "parameters": parameters or {}, "observations": observations}
    checks.append(record)
    print(json.dumps(record), flush=True)

run("capture_unit", "tb_capture_admission", "tb_capture_admission.sv", base)
run("rate_boundaries", "tb_admission_rates", "tb_admission_rates.sv", base)
run("source_fast_enabled", "tb_source_admission", "tb_source_admission.sv", integration, {"ENABLE": 1, "PERIOD": 330})
run("source_fast_disabled", "tb_source_admission", "tb_source_admission.sv", integration, {"ENABLE": 0, "PERIOD": 330})
run("source_slow_enabled", "tb_source_admission", "tb_source_admission.sv", integration, {"ENABLE": 1, "PERIOD": 668})
run("source_slow_disabled", "tb_source_admission", "tb_source_admission.sv", integration, {"ENABLE": 0, "PERIOD": 668})
excluded = {"ddr3_ip.v", "ddr3_ip_ddrphy_top.v", "ddr3_ip_slice_top_v1_10.v", "config_pll_27m_10m.v", "video_pll_27m_148m5.v"}
rtl_files = [p.name for p in S.glob("*.v") if p.name not in excluded]
run("complete_core_enabled_elaboration", "video_correct_ddr_continuous_core", None, rtl_files, {"LOW_LATENCY_ADMISSION": 1}, simulate=False)
run("complete_core_disabled_elaboration", "video_correct_ddr_continuous_core", None, rtl_files, {"LOW_LATENCY_ADMISSION": 0}, simulate=False)

record = {"passed": all(x["passed"] for x in checks), "hardware_accessed": False, "pds_invoked": False,
          "scope": "Small actual source receiver/writer/manager/credit and frame/packet ownership integration plus separate rate boundaries. Processing/display timing modeled; no1080p, optical or physical qualification.",
          "checks": checks, "source_sha256": locked,
          "test_sha256": {p.name: sha(p) for p in (ROOT / "tests").iterdir() if p.is_file()},
          "sources_unchanged": locked == {p.name: sha(p) for p in S.iterdir() if p.is_file()},
          "hardware_rate_margin": {"declared_proc_cycles_per_ms": 92813, "nominal_real_processing_hz": 92812500,
                                   "fast_limit_ticks": 92813 * 1000 // 60,
                                   "exact60_nominal_ticks": 92812500 / 60,
                                   "nominal5994_ticks": 92812500 / 59.94},
          "elapsed_seconds": time.time() - started}
record["passed"] = record["passed"] and record["sources_unchanged"]
(OUT / "verification.json").write_text(json.dumps(record, indent=2))
print(json.dumps({k: record[k] for k in ["passed", "sources_unchanged", "elapsed_seconds", "hardware_rate_margin"]}, indent=2))
raise SystemExit(0 if record["passed"] else 1)
