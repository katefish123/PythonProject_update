`timescale 1ns/1ps
module tb_capture_admission;
 reg proc_clk=0,rx_clk=0,rst_n=0,raw_requested=0,rearm=0;
 always #5 proc_clk=~proc_clk;
 always #3 rx_clk=~rx_clk;
 reg rx_vs=0,rx_de=0;reg[23:0]rx_rgb=0;
 wire permit,frame_begin,frame_blocked,close_valid,close_bank,close_ok;
 wire[31:0]close_generation;wire[3:0]close_reason;
 wire packet_valid;wire[319:0]packet_data;wire fault;
 wire[31:0]admitted,dropped;wire[1:0]owned;
 reg release_valid=0,release_bank=0;reg[31:0]release_generation=0;
 // Accelerate wall time: 12 processing ticks/ms means a normalized60 fps
 // frame spans200 processing ticks. The RTL still measures proc ticks only.
 capture_admission_control #(.PROC_CYCLES_PER_MS(12),.FAST_FPS(45)) control(
  .proc_clk(proc_clk),.rx_clk(rx_clk),.rst_n(rst_n),.raw_requested(raw_requested),.rx_vs(rx_vs),
  .rearm(rearm),.ready_source_pending(1'b1),.frame_begin(frame_begin),.frame_blocked(frame_blocked),.bad_close(close_valid&&!close_ok),.permit(permit));
 continuous_capture_rx #(.IN_W(8),.IN_H(8),.SRC_W(8),.SRC_H(8)) capture(
  .clk(rx_clk),.rst_n(rst_n),.enabled(permit),.rx_vs(rx_vs),.rx_de(rx_de),.rx_rgb(rx_rgb),
  .release_valid(release_valid),.release_bank(release_bank),.release_generation(release_generation),
  .packet_valid(packet_valid),.packet_ready(1'b1),.packet_data(packet_data),
  .sample_valid(),.sample_first(),.sample_x(),.sample_y(),.sample_bank(),.sample_generation(),
  .close_valid(close_valid),.close_bank(close_bank),.close_ok(close_ok),.close_generation(close_generation),.close_reason(close_reason),
  .dropped_frames(dropped),.admitted_frames(admitted),.fault(fault),.owned_banks(owned),.frame_begin(frame_begin),.frame_blocked(frame_blocked));
 integer begins=0,good_closes=0,bad_closes=0,ends=0,good_ends=0,bad_ends=0,data_words=0;
 integer base_begins,base_good,base_bad,base_ends;
 // Unit consumer returns a source bank after its terminal observation. Actual
 // integration retains its existing DDR-terminal/manager ownership checks.
 always @(posedge rx_clk)begin
  if(!rst_n)begin release_valid<=0;release_bank<=0;release_generation<=0;end
  else begin
   release_valid<=close_valid;
   if(close_valid)begin release_bank<=close_bank;release_generation<=close_generation;end
   if(frame_begin)begins=begins+1;
   if(close_valid)begin if(close_ok)good_closes=good_closes+1;else bad_closes=bad_closes+1;end
   if(packet_valid)case(packet_data[319:318])
    1:data_words=data_words+1;
    2:begin ends=ends+1;if(packet_data[260])good_ends=good_ends+1;else bad_ends=bad_ends+1;end
   endcase
   if(fault)$fatal(1,"capture credit/queue fault");
  end
 end
 task sensor_frame(input integer period_cycles,input integer bad);
  integer row,column,used;
  begin
   @(negedge rx_clk);rx_vs=1;rx_de=0;
   repeat(2)@(negedge rx_clk);rx_vs=0;
   used=2;
   for(row=0;row<(bad?7:8);row=row+1)begin
    for(column=0;column<8;column=column+1)begin
     rx_de=1;rx_rgb={8'(row),8'(column),8'h71};@(negedge rx_clk);used=used+1;
    end
    rx_de=0;@(negedge rx_clk);used=used+1;
   end
   repeat(period_cycles-used-1)@(negedge rx_clk);
  end
 endtask
 task accepted_event;
  begin @(negedge proc_clk);rearm=1;@(negedge proc_clk);rearm=0;repeat(20)@(negedge rx_clk);end
 endtask
 task settle;
  begin repeat(20)@(negedge rx_clk);end
 endtask
 initial begin
  repeat(10)@(negedge rx_clk);rst_n=1;
  repeat(6)sensor_frame(334,0);settle();
  if(!control.active||control.token)$fatal(1,"fast input did not exhaust initial admission");
  base_begins=begins;repeat(2)sensor_frame(334,0);settle();
  if(begins!=base_begins)$fatal(1,"ungranted60 fps BEGIN");
  $display("PASS FAST_INPUT_STOPS_WITHOUT_ACCEPTANCE begins=%0d",begins);

  accepted_event();base_begins=begins;base_good=good_closes;base_ends=ends;
  repeat(3)sensor_frame(334,0);settle();
  if(begins!=base_begins+1||good_closes!=base_good+1||ends!=base_ends+1)
   $fatal(1,"one grant did not produce one complete good frame");
  $display("PASS ONE_ACCEPTANCE_ONE_BEGIN_END good_ends=%0d",good_ends);

  // A malformed capture has no descriptor to accept. Its END must independently
  // replenish a retry permit and the next valid capture must complete.
  accepted_event();base_begins=begins;base_bad=bad_closes;base_good=good_closes;
  sensor_frame(334,1);repeat(4)sensor_frame(334,0);settle();
  if(begins!=base_begins+2||bad_closes!=base_bad+1||good_closes!=base_good+1)
   $fatal(1,"bad END did not recover without a consumer acceptance");
  if(bad_ends<1)$fatal(1,"bad terminal packet lost");
  $display("PASS BAD_FRAME_RETRY bad_ends=%0d",bad_ends);

  // This uses the same reliable rearm input as a rejected DDR terminal after
  // its proc-domain terminal handshake in continuous_source_path.
  accepted_event();base_begins=begins;repeat(2)sensor_frame(334,0);settle();
  if(begins!=base_begins+1)$fatal(1,"proc bad-terminal rearm event lost");
  $display("PASS PROC_REARM_MAILBOX");

  raw_requested=1;settle();base_begins=begins;
  repeat(5)sensor_frame(334,0);settle();
  if(begins!=base_begins+5||control.active)$fatal(1,"RAW changed original continuous allocation");
  $display("PASS RAW_BYPASS");
  raw_requested=0;settle();repeat(5)sensor_frame(334,0);settle();
  base_begins=begins;repeat(2)sensor_frame(334,0);settle();
  if(begins!=base_begins||!control.active)$fatal(1,"RAW to corrected did not resume throttling");
  $display("PASS RAW_TO_CORRECTED");

  sensor_frame(668,0);settle();
  if(control.active)$fatal(1,"slow input timeout did not release gate");
  base_begins=begins;repeat(5)sensor_frame(668,0);settle();
  if(begins!=base_begins+5)$fatal(1,"30 fps input lost continuous admission");
  $display("PASS FAST_TO_SLOW_AND_30FPS");
  repeat(6)sensor_frame(334,0);settle();base_begins=begins;
  repeat(2)sensor_frame(334,0);settle();
  if(begins!=base_begins||!control.active)$fatal(1,"slow to fast input did not reenable gate");
  $display("PASS SLOW_TO_FAST");

  repeat(5)begin @(negedge proc_clk);rearm=1;@(negedge proc_clk);rearm=0;end
  repeat(30)@(negedge rx_clk);base_begins=begins;
  repeat(3)sensor_frame(334,0);settle();
  if(begins!=base_begins+1)$fatal(1,"rearm mailbox became a queued capture backlog");
  $display("PASS_REARMS_COALESCE");

  @(negedge proc_clk);rearm=1;@(negedge rx_clk);rst_n=0;rearm=0;rx_vs=0;rx_de=0;
  repeat(10)@(negedge rx_clk);rst_n=1;repeat(8)@(negedge rx_clk);base_begins=begins;
  sensor_frame(334,0);settle();
  if(begins!=base_begins+1)$fatal(1,"reset bootstrap missing");
  repeat(6)sensor_frame(334,0);settle();base_begins=begins;
  repeat(2)sensor_frame(334,0);settle();
  if(begins!=base_begins)$fatal(1,"stale pre-reset rearm survived");
  $display("PASS RESET_BOOTSTRAP_AND_CANCEL");
  $display("PASS CAPTURE_ADMISSION_UNIT begins=%0d good_closes=%0d bad_closes=%0d data_words=%0d",begins,good_closes,bad_closes,data_words);
  $finish;
 end
 initial begin #500000;$fatal(1,"unit timeout");end
endmodule
