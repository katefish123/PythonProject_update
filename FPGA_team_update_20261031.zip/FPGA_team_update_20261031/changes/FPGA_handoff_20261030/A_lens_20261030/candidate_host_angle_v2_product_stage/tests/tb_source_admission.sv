`timescale 1ns/1ps
module tb_source_admission #(parameter ENABLE=1,PERIOD=334);
 reg proc_clk=0,rx_clk=0,ui_clk=0,rst_n=0;
 always #5 proc_clk=~proc_clk;
 always #3 rx_clk=~rx_clk;
 always #4 ui_clk=~ui_clk;
 reg rx_vs=0,rx_de=0;reg[23:0]rx_rgb=0;
 wire frame_valid,frame_ready,frame_bank,geometry_valid,fault,cmd_valid,cmd_write;
 wire[31:0]frame_generation,capture_ms,rejected,admitted,dropped;
 wire[95:0]corners;wire[511:0]reasons;wire[3:0]last_reason,faults;
 wire[5:0]fifo_peak;wire[27:0]cmd_addr;wire[255:0]cmd_wdata;wire[31:0]cmd_wstrb;wire[2047:0]cmd_burst_data;
 reg rsp_valid=0,release_valid=0,release_bank=0;
 reg[31:0]release_generation=0;
 reg allow_consume=0,worker_busy=0;integer timer=0;
 reg held_bank;reg[31:0]held_generation;
 assign frame_ready=rst_n&&allow_consume&&!worker_busy;
 continuous_source_path #(.LOW_LATENCY_ADMISSION(ENABLE),.PROC_CYCLES_PER_MS(12),
  .IN_W(8),.IN_H(8),.SRC_W(8),.SRC_H(8),.DATA_FIFO_ADDR_BITS(5),.BURST_BEATS(8)) dut(
  .rx_clk(rx_clk),.proc_clk(proc_clk),.ui_clk(ui_clk),.rst_n(rst_n),.enabled(1'b1),.raw_requested(1'b0),
  .rx_vs(rx_vs),.rx_de(rx_de),.rx_rgb(rx_rgb),.frame_valid(frame_valid),.frame_ready(frame_ready),.frame_bank(frame_bank),
  .frame_generation(frame_generation),.frame_corners(corners),.frame_geometry_valid(geometry_valid),
  .data_fifo_peak(fifo_peak),.frame_capture_ms(capture_ms),.reject_reason_counts(reasons),.admitted_frames(admitted),
  .release_valid(release_valid),.release_bank(release_bank),.release_generation(release_generation),
  .rejected_frames(rejected),.dropped_frames(dropped),.last_failure_reason(last_reason),.fault(fault),.fault_components(faults),
  .cmd_valid(cmd_valid),.cmd_ready(1'b1),.cmd_write(cmd_write),.cmd_addr(cmd_addr),.cmd_wdata(cmd_wdata),.cmd_wstrb(cmd_wstrb),
  .cmd_burst_data(cmd_burst_data),.rsp_valid(rsp_valid),.rsp_write(1'b1));
 integer physical_frame=0,accepted=0,commands=0,bad_frames=0;
 integer source_physical[0:255];time begin_time[0:255];time age_sum=0,max_age=0;
 integer age_count=0;reg[319:0]held_packet;reg packet_stalled=0;
 time t;
 always @(posedge rx_clk)if(rst_n)begin
  if(dut.capture_begin)begin
   source_physical[dut.capture.generation+1]=physical_frame;
   begin_time[dut.capture.generation+1]=$time;
  end
  if(packet_stalled&&(!dut.packet_valid||dut.packet!==held_packet))$fatal(1,"source packet changed under backpressure");
  packet_stalled=dut.packet_valid&&!dut.packet_ready;held_packet=dut.packet;
 end
 always @(posedge ui_clk)begin
  rsp_valid<=rst_n&&cmd_valid;
  if(rst_n&&cmd_valid)begin
   if(!cmd_write||cmd_wstrb!==32'hffffffff||cmd_addr!==(dut.writer.bank?28'h0800000:28'd0))$fatal(1,"native source command changed");
   for(integer k=0;k<64;k=k+1)
    if(cmd_burst_data[k*32+:32]!=={8'd0,8'(source_physical[dut.writer.generation]),8'(k/8),8'(k%8)})
     $fatal(1,"source burst data mismatch generation=%0d index=%0d actual=%h",dut.writer.generation,k,cmd_burst_data[k*32+:32]);
   commands=commands+1;
  end
 end
 always @(posedge proc_clk)begin
  release_valid<=0;
  if(rst_n)begin
   if(fault)$fatal(1,"source ownership fault components=%b",faults);
   if(frame_valid&&frame_ready)begin
    held_bank<=frame_bank;held_generation<=frame_generation;worker_busy<=1;timer<=0;
    accepted=accepted+1;
    if(accepted>=4&&bad_frames==0)begin
     t=$time-begin_time[frame_generation];age_sum=age_sum+t;age_count=age_count+1;
     if(t>max_age)max_age=t;
    end
   end else if(worker_busy)begin
    timer<=timer+1;
    if(timer==369)begin release_valid<=1;release_bank<=held_bank;release_generation<=held_generation;end
    if(timer==399)worker_busy<=0;
   end
  end
 end
 task sensor_frame(input integer bad);
  integer row,column,used;
  begin
   @(negedge rx_clk);physical_frame=physical_frame+1;rx_vs=1;rx_de=0;
   repeat(2)@(negedge rx_clk);rx_vs=0;used=2;
   for(row=0;row<(bad?7:8);row=row+1)begin
    for(column=0;column<8;column=column+1)begin
     rx_de=1;rx_rgb={8'(physical_frame),8'(row),8'(column)};@(negedge rx_clk);used=used+1;
    end
    rx_de=0;@(negedge rx_clk);used=used+1;
   end
   repeat(PERIOD-used-1)@(negedge rx_clk);
  end
 endtask
 integer accepted_before_fault;
 initial begin
  repeat(10)@(negedge rx_clk);rst_n=1;repeat(10)@(negedge rx_clk);allow_consume=1;
  repeat(24)sensor_frame(0);
  if(accepted<8||commands<8||age_count<4)$fatal(1,"insufficient joined-frame coverage");
  $display("SOURCE_AGE_RESULT enable=%0d period=%0d age_count=%0d mean_ns=%0d max_ns=%0d accepted=%0d",ENABLE,PERIOD,age_count,age_sum/age_count,max_age,accepted);
  // Deliberately malformed physical frames continue until one is admitted.
  bad_frames=1;accepted_before_fault=accepted;
  repeat(4)sensor_frame(1);
  repeat(12)sensor_frame(0);
  if(rejected==0||accepted<=accepted_before_fault+2)$fatal(1,"bad DDR terminal did not rearm/recover actual source path");
  if(fault)$fatal(1,"fault after recovery");
  $display("PASS SOURCE_ADMISSION_INTEGRATION enable=%0d period=%0d accepted=%0d commands=%0d rejected=%0d dropped=%0d",ENABLE,PERIOD,accepted,commands,rejected,dropped);
  $finish;
 end
 initial begin #500000;$fatal(1,"integration timeout");end
endmodule
