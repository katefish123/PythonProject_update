`timescale 1ns/1ps
module admission_rate_case #(parameter TICKS=10000,FAST=1,LABEL=60)(output reg finished=0);
 reg proc_clk=0,rx_clk=0,rst_n=0,rx_vs=0,vs_d=0;
 always #5 proc_clk=~proc_clk;
 always #1 rx_clk=~rx_clk;
 always @(posedge rx_clk)vs_d<=rx_vs;
 wire permit;
 // A calibrated600 ticks/ms represents the scaled test timebase exactly.
 // Integer periods keep the60fps boundary phase-stable across both clocks.
 capture_admission_control #(.PROC_CYCLES_PER_MS(600)) control(
  .proc_clk(proc_clk),.rx_clk(rx_clk),.rst_n(rst_n),.raw_requested(1'b0),.rx_vs(rx_vs),
  .rearm(1'b0),.ready_source_pending(1'b1),.frame_begin(rx_vs&&!vs_d&&permit),.frame_blocked(1'b0),.bad_close(1'b0),.permit(permit));
 initial begin
  #100;rst_n=1;#100;
  forever begin
   @(negedge rx_clk);rx_vs=1;
   repeat(4)@(negedge rx_clk);rx_vs=0;
   repeat(TICKS*5-5)@(negedge rx_clk);
  end
 end
 initial begin
  repeat(7)@(posedge rx_vs);repeat(100)@(negedge rx_clk);
  if(control.active!==FAST)$fatal(1,"rate classification label=%0d ticks=%0d expected_fast=%0d actual=%b",LABEL,TICKS,FAST,control.active);
  if(FAST&&(permit||control.suppressed_frames<2))$fatal(1,"fast rate did not suppress ungranted frames");
  if(!FAST&&(!permit||control.suppressed_frames!=0))$fatal(1,"sub60 rate did not retain continuous policy");
  $display("PASS RATE_BOUNDARY label=%0d ticks=%0d fast=%0d suppressed=%0d",LABEL,TICKS,FAST,control.suppressed_frames);
  finished=1;
 end
endmodule
module tb_admission_rates;
 wire[6:0]finished;
 admission_rate_case #(.TICKS(20020),.FAST(0),.LABEL(2997)) r2997(finished[0]);
 admission_rate_case #(.TICKS(20000),.FAST(0),.LABEL(3000)) r30(finished[1]);
 admission_rate_case #(.TICKS(12000),.FAST(0),.LABEL(5000)) r50(finished[2]);
 admission_rate_case #(.TICKS(10909),.FAST(0),.LABEL(5500)) r55(finished[3]);
 admission_rate_case #(.TICKS(10010),.FAST(0),.LABEL(5994)) r5994(finished[4]);
 admission_rate_case #(.TICKS(10000),.FAST(1),.LABEL(6000)) r60(finished[5]);
 admission_rate_case #(.TICKS(9998),.FAST(1),.LABEL(6001)) r6001(finished[6]);
 initial begin wait(&finished);$display("PASS ALL_ADMISSION_RATE_BOUNDARIES");$finish;end
 initial begin #2000000;$fatal(1,"rate timeout");end
endmodule
