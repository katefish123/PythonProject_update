`timescale 1ns/1ps
module cache_lane #(parameter REF=0,WARM=0,N=1200,LINES=128,W=1920,H=1080)(output reg finished=0);
 reg clk=0,rst_n=0;always #4 clk=~clk;
 reg[125:0]vectors[0:N-1];reg[168:0]expected[0:N-1];
 integer tick=0,sent=0,received=0,commands=0,held_cycles=0,request_stalls=0,latency_sum=0;
 integer accepted_at[0:N-1];reg[31:0]mem_epoch[0:1];
 wire req_valid=rst_n&&sent<N&&(WARM||tick%13>=3);
 wire req_ready;wire[27:0]req_base;wire[31:0]req_generation;wire[11:0]req_x,req_y;
 wire req_inside,req_nearest;wire[23:0]req_tag;wire[7:0]req_fx,req_fy;
 assign {req_base,req_generation,req_x,req_y,req_nearest,req_inside,req_tag,req_fx,req_fy}=vectors[sent<N?sent:N-1];
 wire rsp_valid;wire rsp_ready=WARM||tick%31>=13;
 wire rsp_inside;wire[23:0]rsp_p00,rsp_p10,rsp_p01,rsp_p11,rsp_tag;wire[7:0]rsp_fx,rsp_fy;wire[31:0]rsp_generation;
 wire[168:0]actual={rsp_generation,rsp_inside,rsp_p00,rsp_p10,rsp_p01,rsp_p11,rsp_tag,rsp_fx,rsp_fy};
 wire cmd_valid;wire cmd_ready=WARM||tick%11>=4;wire cmd_block;wire[27:0]cmd_addr;
 reg mem_rsp_valid=0;reg[4095:0]rsp_block=0;wire mem_rsp_write=0;wire fault;
 generate if(REF)begin: old
 ddr_quad_tile_cache_reference #(.SRC_W(W),.SRC_H(H),.LINES(LINES)) dut(.clk(clk),.rst_n(rst_n),.req_valid(req_valid),.req_ready(req_ready),.req_base(req_base),.req_generation(req_generation),.req_x(req_x),.req_y(req_y),.req_inside(req_inside),.req_nearest(req_nearest),.req_tag(req_tag),.req_fx(req_fx),.req_fy(req_fy),.rsp_valid(rsp_valid),.rsp_ready(rsp_ready),.rsp_inside(rsp_inside),.rsp_p00(rsp_p00),.rsp_p10(rsp_p10),.rsp_p01(rsp_p01),.rsp_p11(rsp_p11),.rsp_tag(rsp_tag),.rsp_fx(rsp_fx),.rsp_fy(rsp_fy),.rsp_generation(rsp_generation),.cmd_valid(cmd_valid),.cmd_ready(cmd_ready),.cmd_block(cmd_block),.cmd_addr(cmd_addr),.mem_rsp_valid(mem_rsp_valid),.mem_rsp_write(mem_rsp_write),.rsp_block(rsp_block),.fault(fault));
 end else begin: newer
 ddr_quad_tile_cache #(.SRC_W(W),.SRC_H(H),.LINES(LINES)) dut(.clk(clk),.rst_n(rst_n),.req_valid(req_valid),.req_ready(req_ready),.req_base(req_base),.req_generation(req_generation),.req_x(req_x),.req_y(req_y),.req_inside(req_inside),.req_nearest(req_nearest),.req_tag(req_tag),.req_fx(req_fx),.req_fy(req_fy),.rsp_valid(rsp_valid),.rsp_ready(rsp_ready),.rsp_inside(rsp_inside),.rsp_p00(rsp_p00),.rsp_p10(rsp_p10),.rsp_p01(rsp_p01),.rsp_p11(rsp_p11),.rsp_tag(rsp_tag),.rsp_fx(rsp_fx),.rsp_fy(rsp_fy),.rsp_generation(rsp_generation),.cmd_valid(cmd_valid),.cmd_ready(cmd_ready),.cmd_block(cmd_block),.cmd_addr(cmd_addr),.mem_rsp_valid(mem_rsp_valid),.mem_rsp_write(mem_rsp_write),.rsp_block(rsp_block),.fault(fault));
 end endgenerate
 function[23:0]pixel(input[27:0]a,input[31:0]g);
 pixel=((a*13+(a>>8)+g*29+17)&255)<<16|((a*7+(a>>3)+g*31+43)&255)<<8|((a*3+(a>>11)+g*37+97)&255);
 endfunction
 reg pending=0;integer delay=0;reg[27:0]fill_base;reg[31:0]fill_epoch;
 reg held=0;reg[168:0]held_data;
 always @(posedge clk)begin
 tick<=tick+1;
 if(!rst_n)begin sent<=0;received<=0;held<=0;pending<=0;mem_rsp_valid<=0;mem_epoch[0]<=0;mem_epoch[1]<=0;end
 else begin
  if(fault)$fatal(1,"CACHE_UNEXPECTED_FAULT ref=%0d warm=%0d",REF,WARM);
  if(held&&(!rsp_valid||actual!==held_data))$fatal(1,"CACHE_RESPONSE_MOVED_UNDER_STALL ref=%0d",REF);
  held<=rsp_valid&&!rsp_ready;held_data<=actual;
  if(req_valid&&!req_ready)request_stalls++;
  if(rsp_valid&&!rsp_ready)held_cycles++;
  if(req_valid&&req_ready)begin
   accepted_at[sent]<=tick;sent<=sent+1;mem_epoch[req_base>=28'h0800000]<=req_generation;
  end
  if(rsp_valid&&rsp_ready)begin
   if(received>=N||actual!==expected[received])$fatal(1,"CACHE_DATA_MISMATCH ref=%0d warm=%0d index=%0d actual=%h expected=%h",REF,WARM,received,actual,expected[received]);
   if(received>20)latency_sum=latency_sum+tick-accepted_at[received];
   received<=received+1;
  end
  mem_rsp_valid<=0;
  if(cmd_valid&&cmd_ready)begin
   if(pending||!cmd_block||cmd_addr[6:0]!=0)$fatal(1,"CACHE_FILL_OWNERSHIP");
   pending<=1;fill_base<=cmd_addr;fill_epoch<=mem_epoch[cmd_addr>=28'h0800000];
   delay<=WARM?3:3+(commands%17);commands++;
  end
  if(pending)begin
   if(delay!=0)delay<=delay-1;
   else begin
    pending<=0;mem_rsp_valid<=1;
    for(integer k=0;k<128;k++)begin
     rsp_block[k*32+:24]<=pixel(fill_base+k,fill_epoch);
     // Padding may contain arbitrary bits or X: no RGB output uses it.
     rsp_block[k*32+24+:8]<=commands%5==0?8'hxx:(fill_base+k+commands*3);
    end
   end
  end
  if(received==N&&!finished)begin
   if(!WARM&&(held_cycles==0||request_stalls==0||commands<100))$fatal(1,"CACHE_INCOMPLETE_COVERAGE");
   $display("CACHE_PASS ref=%0d warm=%0d requests=%0d commands=%0d response_stalls=%0d request_stalls=%0d warm_latency_sum=%0d",REF,WARM,N,commands,held_cycles,request_stalls,latency_sum);
   finished<=1;
  end
 end
 end
 initial begin
 if(WARM)begin $readmemh("warm_input.hex",vectors);$readmemh("warm_expected.hex",expected);end
 else begin $readmemh("input.hex",vectors);$readmemh("expected.hex",expected);end
 repeat(6)@(negedge clk);rst_n=1;
 if(!WARM)begin
  wait(held&&sent>50);@(negedge clk);rst_n=0;
  repeat(6)@(negedge clk);rst_n=1;
 end
 wait(finished);end
endmodule
module tb;
 wire a,b,c,d;
 cache_lane old(a);cache_lane #(.REF(1)) reference(b);
 cache_lane #(.WARM(1),.N(80),.LINES(128)) warm_new(c);
 cache_lane #(.REF(1),.WARM(1),.N(80),.LINES(128)) warm_old(d);

 initial begin wait(a&&b&&c&&d);
 if(warm_new.latency_sum!=warm_old.latency_sum)$fatal(1,"CACHE_EXTRA_STAGE_LATENCY new=%0d old=%0d",warm_new.latency_sum,warm_old.latency_sum);
 $display("TIMING_COMPONENT_PASS cache_exact=1 registered_tag_matches=1 extra_warm_hit_cycles=0");$finish;end
 initial begin #10000000;$fatal(1,"CACHE_TIMEOUT");end
endmodule
