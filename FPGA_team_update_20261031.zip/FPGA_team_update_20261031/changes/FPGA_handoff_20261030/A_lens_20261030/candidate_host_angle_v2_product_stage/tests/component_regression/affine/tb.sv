`timescale 1ns/1fs
module affine_lane #(parameter REF=0,N=10000)(
 input wire clk,rst_n,in_valid,nearest,input wire[239:0]affine,input wire[11:0]dst_x,dst_y,input integer drive_id,
 output reg[31:0]requests=0,outputs=0,cancelled_requests=0,cancelled_pixels=0,
 output reg request_pulse=0,output integer request_id,output reg[137:0]request_payload,
 output integer latency,output wire drained
);
 reg[137:0]expected[0:N-1];reg[23:0]expected_rgb[0:N-1];
 integer request_ids[0:N-1],input_ticks[0:N-1],response_ids[0:N-1],output_ids[0:N-1];
 integer iw=0,ir=0,rw=0,rr=0,ow=0,orr=0,tick=0,k;
 reg[31:0]rng=32'h783af102;
 wire req_valid,req_inside,req_error,out_valid;wire[23:0]req_tag,addr00,addr10,addr01,addr11,out_rgb,out_tag;wire[7:0]req_fx,req_fy;
 reg rsp_valid=0,rsp_inside=0;reg[23:0]rsp_tag=0,p00=0,p10=0,p01=0,p11=0;reg[7:0]rsp_fx=0,rsp_fy=0;
 reg[137:0]response;
 generate if(REF)begin: baseline
  lens_affine_reference dut(.*);
 end else begin: candidate
  lens_affine_instance dut(.*);
 end endgenerate
 function[23:0]pixel(input[23:0]a);reg[7:0]r,g,b;
 begin r=a*13+(a>>8)+17;g=a*7+(a>>3)+43;b=a*3+(a>>11)+97;pixel={r,g,b};end endfunction
 assign drained=iw==ir&&rw==rr&&ow==orr&&!rsp_valid;
 initial begin $readmemh("expected_requests.hex",expected);$readmemh("expected_rgb.hex",expected_rgb);latency=-1;end
 always @(posedge clk)begin
  tick=tick+1;request_pulse<=0;
  if(!rst_n)begin
   cancelled_requests=cancelled_requests+iw-ir;
   cancelled_pixels=cancelled_pixels+ow-orr;
   iw=0;ir=0;rw=0;rr=0;ow=0;orr=0;rsp_valid<=0;
  end else begin
   if(in_valid)begin request_ids[iw]=drive_id;input_ticks[iw]=tick;iw=iw+1;end
   if(req_valid)begin
    if(ir>=iw)$fatal(1,"unexpected request ref=%0d",REF);
    k=request_ids[ir];
    if({req_error,req_inside,req_tag,addr00,addr10,addr01,addr11,req_fx,req_fy}!==expected[k])
     $fatal(1,"integer golden request mismatch ref=%0d id=%0d actual=%h expected=%h",REF,k,{req_error,req_inside,req_tag,addr00,addr10,addr01,addr11,req_fx,req_fy},expected[k]);
    if(latency<0)latency=tick-input_ticks[ir];
    if(latency!=tick-input_ticks[ir])$fatal(1,"request latency changed ref=%0d",REF);
    ir=ir+1;requests=requests+1;
    response_ids[rw]=k;rw=rw+1;
    request_pulse<=1;request_id<=k;request_payload<=expected[k];
   end
   if(out_valid)begin
    if(orr>=ow)$fatal(1,"unexpected RGB ref=%0d",REF);
    k=output_ids[orr];orr=orr+1;outputs=outputs+1;
    if(out_tag!==(expected[k][135:112])||out_rgb!==expected_rgb[k])
     $fatal(1,"integer golden RGB mismatch ref=%0d id=%0d rgb=%h expected=%h",REF,k,out_rgb,expected_rgb[k]);
   end
   rng=rng^(rng<<13);rng=rng^(rng>>17);rng=rng^(rng<<5);
   rsp_valid<=0;
   // Delayed and bursty source responses exercise independent pixel latency.
   if(rr<rw&&rng[2:0]>=2)begin
    k=response_ids[rr];rr=rr+1;response=expected[k];
    rsp_valid<=1;rsp_inside<=response[136];rsp_tag<=response[135:112];rsp_fx<=response[15:8];rsp_fy<=response[7:0];
    p00<=pixel(response[111:88]);p10<=pixel(response[87:64]);p01<=pixel(response[63:40]);p11<=pixel(response[39:16]);
    output_ids[ow]=k;ow=ow+1;
   end
  end
 end
endmodule
module tb_affine_retime #(parameter N=10000);
 reg clk=0,rst_n=0,in_valid=0;always #5.387205387 clk=~clk;
 reg[264:0]vectors[0:N-1];integer drive_id=0;
 wire[239:0]affine=vectors[drive_id][264:25];wire nearest=vectors[drive_id][24];
 wire[11:0]dst_x=vectors[drive_id][11:0],dst_y=vectors[drive_id][23:12];
 wire[31:0]a_requests,b_requests,a_outputs,b_outputs,a_cancelq,b_cancelq,a_cancelp,b_cancelp;
 wire a_pulse,b_pulse,a_drained,b_drained;wire[137:0]a_payload,b_payload;integer a_id,b_id,a_latency,b_latency;
 affine_lane #(.REF(0),.N(N)) newer(clk,rst_n,in_valid,nearest,affine,dst_x,dst_y,drive_id,a_requests,a_outputs,a_cancelq,a_cancelp,a_pulse,a_id,a_payload,a_latency,a_drained);
 affine_lane #(.REF(1),.N(N)) original(clk,rst_n,in_valid,nearest,affine,dst_x,dst_y,drive_id,b_requests,b_outputs,b_cancelq,b_cancelp,b_pulse,b_id,b_payload,b_latency,b_drained);
 reg[137:0]a_seen[0:N-1],b_seen[0:N-1];reg av[0:N-1],bv[0:N-1];integer paired_count=0;
 always @(negedge clk)if(rst_n)begin
  if(a_pulse)begin a_seen[a_id]=a_payload;av[a_id]=1;if(bv[a_id])begin if(a_payload!==b_seen[a_id])$fatal(1,"new/old request difference");paired_count=paired_count+1;end end
  if(b_pulse)begin b_seen[b_id]=b_payload;bv[b_id]=1;if(av[b_id])begin if(b_payload!==a_seen[b_id])$fatal(1,"old/new request difference");paired_count=paired_count+1;end end
 end
 task send(input integer id);begin @(negedge clk);drive_id=id;in_valid=1;end endtask
 task reset;
 begin
  @(negedge clk);in_valid=0;rst_n=0;repeat(3)@(negedge clk);rst_n=1;
  repeat(60)begin @(negedge clk);if(a_pulse||b_pulse)$fatal(1,"reset leaked request");end
 end endtask
 integer i;reg[31:0]rng=32'h91043ace;
 initial begin
  for(i=0;i<N;i=i+1)begin av[i]=0;bv[i]=0;end
  $readmemh("inputs.hex",vectors);reset();
  for(i=0;i<8;i=i+1)send(i);reset();
  for(i=8;i<64;i=i+1)send(i);reset();
  for(i=64;i<N;i=i+1)begin
   rng=rng^(rng<<13);rng=rng^(rng>>17);rng=rng^(rng<<5);
   if(rng[3:0]<3)begin @(negedge clk);in_valid=0;repeat(rng[6:5])@(negedge clk);end
   send(i);
  end
  @(negedge clk);in_valid=0;
  wait(a_drained&&b_drained);repeat(30)@(negedge clk);
  if(a_latency!=b_latency+1||a_requests<N-100||b_requests<N-100||paired_count<N-100||a_cancelq<8||b_cancelq<8)
   $fatal(1,"affine coverage new_latency=%0d old_latency=%0d paired=%0d",a_latency,b_latency,paired_count);
  $display("PASS AFFINE_RETIME new_requests=%0d old_requests=%0d new_rgb=%0d old_rgb=%0d paired=%0d new_latency=%0d old_latency=%0d cancelled=%0d/%0d",a_requests,b_requests,a_outputs,b_outputs,paired_count,a_latency,b_latency,a_cancelq,b_cancelq);
  $finish;
 end
 initial begin #5000000;$fatal(1,"affine timeout");end
endmodule
