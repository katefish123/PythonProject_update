`timescale 1ns/1ps
module ownership_lane #(parameter REF=0,START_RAW=1,BAD_RETRY=0)(
 input wire proc_clk,rx_clk,ui_clk,rst_n,rx_vs,rx_de,input wire[23:0]rx_rgb,
 output wire[31:0]corrected,output wire[1:0]owned,output wire token,bootstrap,active,
 output wire[31:0]recoveries,output wire switched
);
 reg raw_requested=START_RAW;
 wire frame_valid,frame_ready,frame_bank,geometry_valid;
 wire[31:0]frame_generation,frame_capture_ms;wire[95:0]corners;wire[511:0]reject_counts;
 wire[5:0]fifo_peak;wire[31:0]admitted,rejected,dropped;wire[3:0]last_reason,fault_components;
 wire source_fault,cmd_valid,cmd_write;wire[27:0]cmd_addr;wire[255:0]cmd_data;wire[31:0]cmd_mask;wire[2047:0]cmd_burst;
 reg rsp_valid=0;
 integer hold_ns=56000;wire[31:0]writer_generation;
 initial if($value$plusargs("hold_ns=%d",hold_ns))begin end
 reg cmd_ready=1;
 always @(negedge ui_clk)cmd_ready<=!(BAD_RETRY&&writer_generation==3&&$time<hold_ns);
 wire release_valid,release_bank;wire[31:0]release_generation;
 wire start_correct,abort_correct,path_ready;
 reg path_busy=0,path_done=0;integer process_timer=0,tick=0;
 wire publish_toggle,publish_bank,publish_raw,write_bank,source_select;
 wire[31:0]pub_generation,pub_capture_ms,displayed_generation,displayed_capture_ms,raw_publications,controller_rejected;
 wire session_error;wire[3:0]reason;wire[2:0]state;reg display_ack=0;
 assign path_ready=!path_busy;
 assign switched=!raw_requested;
 generate if(REF)begin: reference_source
  continuous_source_path_reference #(.LOW_LATENCY_ADMISSION(1),.PROC_CYCLES_PER_MS(48),
   .IN_W(8),.IN_H(8),.SRC_W(8),.SRC_H(8),.DATA_FIFO_ADDR_BITS(5),.BURST_BEATS(8)) source(
   .rx_clk(rx_clk),.proc_clk(proc_clk),.ui_clk(ui_clk),.rst_n(rst_n),.enabled(1'b1),.raw_requested(raw_requested),
   .rx_vs(rx_vs),.rx_de(rx_de),.rx_rgb(rx_rgb),.frame_valid(frame_valid),.frame_ready(frame_ready),.frame_bank(frame_bank),
   .frame_generation(frame_generation),.frame_corners(corners),.frame_geometry_valid(geometry_valid),
   .data_fifo_peak(fifo_peak),.frame_capture_ms(frame_capture_ms),.reject_reason_counts(reject_counts),.admitted_frames(admitted),
   .release_valid(release_valid),.release_bank(release_bank),.release_generation(release_generation),
   .rejected_frames(rejected),.dropped_frames(dropped),.last_failure_reason(last_reason),.fault(source_fault),.fault_components(fault_components),
   .cmd_valid(cmd_valid),.cmd_ready(cmd_ready),.cmd_write(cmd_write),.cmd_addr(cmd_addr),.cmd_wdata(cmd_data),.cmd_wstrb(cmd_mask),
   .cmd_burst_data(cmd_burst),.rsp_valid(rsp_valid),.rsp_write(1'b1));
  assign owned=source.capture.used;assign token=source.late_admission.admission.token;
  assign bootstrap=source.late_admission.admission.bootstrap_pending;assign active=source.late_admission.admission.active;
  assign recoveries=0;
  assign writer_generation=source.writer.generation;
 end else begin: recovery_source
  continuous_source_path #(.LOW_LATENCY_ADMISSION(1),.PROC_CYCLES_PER_MS(48),
   .IN_W(8),.IN_H(8),.SRC_W(8),.SRC_H(8),.DATA_FIFO_ADDR_BITS(5),.BURST_BEATS(8)) source(
   .rx_clk(rx_clk),.proc_clk(proc_clk),.ui_clk(ui_clk),.rst_n(rst_n),.enabled(1'b1),.raw_requested(raw_requested),
   .rx_vs(rx_vs),.rx_de(rx_de),.rx_rgb(rx_rgb),.frame_valid(frame_valid),.frame_ready(frame_ready),.frame_bank(frame_bank),
   .frame_generation(frame_generation),.frame_corners(corners),.frame_geometry_valid(geometry_valid),
   .data_fifo_peak(fifo_peak),.frame_capture_ms(frame_capture_ms),.reject_reason_counts(reject_counts),.admitted_frames(admitted),
   .release_valid(release_valid),.release_bank(release_bank),.release_generation(release_generation),
   .rejected_frames(rejected),.dropped_frames(dropped),.last_failure_reason(last_reason),.fault(source_fault),.fault_components(fault_components),
   .cmd_valid(cmd_valid),.cmd_ready(cmd_ready),.cmd_write(cmd_write),.cmd_addr(cmd_addr),.cmd_wdata(cmd_data),.cmd_wstrb(cmd_mask),
   .cmd_burst_data(cmd_burst),.rsp_valid(rsp_valid),.rsp_write(1'b1));
  assign owned=source.capture.used;assign token=source.late_admission.admission.token;
  assign bootstrap=source.late_admission.admission.bootstrap_pending;assign active=source.late_admission.admission.active;
  assign recoveries=source.late_admission.admission.recovery_grants;
  assign writer_generation=source.writer.generation;
 end endgenerate
 c_frame_mode_controller modes(
  .clk(proc_clk),.rst_n(rst_n),.enabled(1'b1),.raw_request(raw_requested),
  .frame_valid(frame_valid),.frame_bank(frame_bank),.frame_geometry_valid(1'b1),.frame_generation(frame_generation),.frame_capture_ms(frame_capture_ms),
  .frame_ready(frame_ready),.start_correct(start_correct),.abort_correct(abort_correct),.path_ready(path_ready),.path_busy(path_busy),.path_done(path_done),
  .path_error(1'b0),.fault_condition(source_fault),.path_failure_reason(4'd0),.display_ack(display_ack),
  .source_select_bank(source_select),.result_write_bank(write_bank),.publish_toggle(publish_toggle),.publish_bank(publish_bank),.publish_raw(publish_raw),
  .published_generation(pub_generation),.published_capture_ms(pub_capture_ms),.displayed_generation(displayed_generation),.displayed_capture_ms(displayed_capture_ms),
  .release_valid(release_valid),.release_bank(release_bank),.release_generation(release_generation),
  .raw_publications(raw_publications),.corrected_publications(corrected),.rejected_frames(controller_rejected),.session_error(session_error),.reason(reason),.state(state));
 always @(posedge ui_clk)rsp_valid<=rst_n&&cmd_valid&&cmd_ready;
 always @(posedge proc_clk)begin
  path_done<=0;
  if(rst_n)begin
   tick=tick+1;
   // Source period8us corresponds to exact60fps at48 proc ticks/ms.
   // This explicit16us display model corresponds to30fps; process14.88us
   // represents31ms. Image math and physical DDR are deliberately absent.
   if(tick%1600==0)display_ack<=publish_toggle;
   if(raw_publications==2&&state==2)raw_requested<=0;
   if(start_correct)begin path_busy<=1;process_timer<=0;end
   else if(path_busy)begin
    process_timer<=process_timer+1;
    if(process_timer==1487)begin path_busy<=0;path_done<=1;end
   end
   if(source_fault||session_error)$fatal(1,"ownership integration fault ref=%0d source=%b mode=%0d",REF,fault_components,reason);
   if(publish_raw&&corrected>0)$fatal(1,"RAW republished after corrected transition");
  end
 end
endmodule
module tb_recovery_ownership #(parameter MODE_RAW=1,BAD_RETRY=0,VS_PHASE=0);
 reg proc_clk=0,rx_clk=0,ui_clk=0,rst_n=0,rx_vs=0,rx_de=0;
 reg[23:0]rx_rgb=0;
 always #5 proc_clk=~proc_clk;
 always #4 rx_clk=~rx_clk;
 always #3 ui_clk=~ui_clk;
 wire[31:0]old_corrected,new_corrected,new_recoveries;wire[1:0]old_owned,new_owned;
 wire old_token,new_token,old_boot,new_boot,old_active,new_active,old_switched,new_switched;
 ownership_lane #(.REF(1),.START_RAW(MODE_RAW),.BAD_RETRY(BAD_RETRY)) old_lane(proc_clk,rx_clk,ui_clk,rst_n,rx_vs,rx_de,rx_rgb,
  old_corrected,old_owned,old_token,old_boot,old_active,,old_switched);
 ownership_lane #(.REF(0),.START_RAW(MODE_RAW),.BAD_RETRY(BAD_RETRY)) new_lane(proc_clk,rx_clk,ui_clk,rst_n,rx_vs,rx_de,rx_rgb,
  new_corrected,new_owned,new_token,new_boot,new_active,new_recoveries,new_switched);
 integer matched_begins=0,physical_frames=0;
 always @(posedge proc_clk)if(BAD_RETRY&&rst_n)begin
  if(old_lane.frame_valid&&old_lane.frame_ready)$display("OLD_ACCEPT time=%0t gen=%0d raw=%b",$time,old_lane.frame_generation,old_lane.raw_requested);
  if(old_lane.reference_source.source.terminal_valid&&old_lane.reference_source.source.terminal_ready)
   $display("OLD_TERMINAL time=%0t data=%h",$time,old_lane.reference_source.source.terminal_data);
 end
 always @(posedge rx_clk)if(BAD_RETRY&&rst_n)begin
  if(old_lane.reference_source.source.capture_begin)$display("OLD_BEGIN time=%0t gen=%0d physical=%0d",$time,old_lane.reference_source.source.capture.generation+1,physical_frames);
  if(old_lane.reference_source.source.capture_blocked)$display("OLD_BLOCKED time=%0t token=%b bootstrap=%b",$time,old_token,old_boot);
  if(old_lane.reference_source.source.credit_valid)$display("OLD_CREDIT time=%0t gen=%0d",$time,old_lane.reference_source.source.credit_generation);
  if(old_lane.reference_source.source.late_admission.admission.new_permit)$display("OLD_REARM time=%0t",$time);
 end
 always @(posedge rx_clk)if(rst_n&&!MODE_RAW)begin
  if(old_lane.reference_source.source.capture_begin!==new_lane.recovery_source.source.capture_begin)
   $fatal(1,"steady capture VS selection changed");
  if(new_lane.recovery_source.source.capture_begin)matched_begins=matched_begins+1;
 end
 task sensor_frame;
  integer row,column,rows;
  begin
   @(negedge rx_clk);rx_vs=1;rx_de=0;physical_frames=physical_frames+1;
   rows=(BAD_RETRY&&physical_frames==5)?9:8;
   repeat(2)@(negedge rx_clk);rx_vs=0;
   for(row=0;row<rows;row=row+1)begin
    for(column=0;column<8;column=column+1)begin rx_de=1;rx_rgb={8'h31,8'(row),8'(column)};@(negedge rx_clk);end
    rx_de=0;@(negedge rx_clk);
   end
   repeat(997-rows*9)@(negedge rx_clk);
  end
 endtask
 initial begin
  repeat(12)@(negedge rx_clk);rst_n=1;repeat(12+VS_PHASE)@(negedge rx_clk);
  repeat(28)sensor_frame();
  if(!old_switched||!new_switched||!old_active||!new_active)$fatal(1,"fast setup not reached");
  if(BAD_RETRY)begin
   if(new_corrected<6||new_recoveries==0)$fatal(1,"bad-terminal recovery failed new=%0d recoveries=%0d old=%0d new_owned=%b",new_corrected,new_recoveries,old_corrected,new_owned);
   if(old_corrected==0&&!old_token&&old_owned!=0)
    $display("PASS BAD_TERMINAL_CREDIT_RACE_REPRODUCED old_corrected=%0d old_token=%b old_owned=%b new_corrected=%0d recoveries=%0d hold_ns=%0d",old_corrected,old_token,old_owned,new_corrected,new_recoveries,old_lane.hold_ns);
   else $display("BAD_TERMINAL_PHASE_NOT_NARROW_WINDOW old_corrected=%0d old_token=%b old_owned=%b hold_ns=%0d",old_corrected,old_token,old_owned,old_lane.hold_ns);
  end else if(MODE_RAW)begin
   if(old_corrected!=1||old_token||old_owned!=0)$fatal(1,"old post-first-corrected deadlock not reproduced corrected=%0d token=%b owned=%b",old_corrected,old_token,old_owned);
   if(new_corrected<6||new_recoveries==0)$fatal(1,"recovery failed corrected=%0d recoveries=%0d",new_corrected,new_recoveries);
   $display("PASS RAW_LEASE_POST_BEGIN_DEADLOCK_REPRODUCED old_corrected=%0d old_token=%b old_owned=%b new_corrected=%0d recoveries=%0d",old_corrected,old_token,old_owned,new_corrected,new_recoveries);
  end else begin
   if(new_corrected!=old_corrected||new_corrected<10||new_recoveries!=0||matched_begins<10)
    $fatal(1,"steady recovery triggered or cadence changed old=%0d new=%0d recoveries=%0d",old_corrected,new_corrected,new_recoveries);
   $display("PASS STEADY_IDENTICAL_CAPTURE_VS old_corrected=%0d new_corrected=%0d matched_begins=%0d recoveries=%0d",old_corrected,new_corrected,matched_begins,new_recoveries);
  end
  $finish;
 end
 initial begin #300000;$fatal(1,"ownership test timeout");end
endmodule
