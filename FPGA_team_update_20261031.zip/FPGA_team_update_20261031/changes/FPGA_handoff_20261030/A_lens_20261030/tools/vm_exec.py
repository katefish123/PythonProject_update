"""Run explicit PowerShell through Parallels Tools without UI automation."""
import base64
import subprocess
import sys


def run(script, timeout=60):
    prefix = '[Console]::OutputEncoding=[Text.UTF8Encoding]::new();$ErrorActionPreference="Stop";$ProgressPreference="SilentlyContinue";'
    encoded = base64.b64encode((prefix+script).encode('utf-16le')).decode('ascii')
    result = subprocess.run(['prlctl','exec','Windows 11','--current-user','powershell','-NoProfile',
                             '-NonInteractive','-EncodedCommand',encoded],
                            stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=timeout)
    output=result.stdout.decode('utf-8',errors='replace')
    print(output,end='')
    return result.returncode


def run_file(windows_path, timeout=60):
    if "'" in windows_path:raise ValueError('Quote in task script path')
    # A short command avoids Parallels guest-command length limits. This runs
    # our generated command body without changing Windows execution policy.
    return run("& ([scriptblock]::Create([IO.File]::ReadAllText('"+windows_path+"')))",timeout)


if __name__=='__main__':
    sys.exit(run(sys.stdin.read(), timeout=240))
