"""Package a source- and timing-verified engineering snapshot, without board access."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import shutil
import zipfile
from audit_portable_native import io_check

ROOT=Path(__file__).resolve().parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))


def require(condition,message):
    if not condition:raise ValueError(message)


def release_build_tcl():
    return (
        'source [file join [file dirname [info script]] build_full.tcl]\n'
        'set release_report [file join [pwd] report_timing video_correct_ddr_top.rtr]\n'
        'if {![file exists $release_report]} {error "Final timing report is missing"}\n'
        'set release_handle [open $release_report r]\n'
        'set release_text [read $release_handle]\nclose $release_handle\n'
        'if {[string first "Design Summary : All Constraints Met." $release_text] < 0 || '
        '[string first "Some Constraints Violated." $release_text] >= 0} '
        '{error "Timing did not pass; firmware generation stopped"}\n'
        'gen_bit_stream -create_bit_file TRUE -create_bin_file\n')


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--candidate',required=True,type=Path)
    ap.add_argument('--native-build',required=True,type=Path)
    ap.add_argument('--pds-template',required=True,type=Path)
    ap.add_argument('--firmware-dir',type=Path)
    ap.add_argument('--output',required=True,type=Path)
    a=ap.parse_args()
    candidate=a.candidate.resolve();build=a.native_build.resolve();out=a.output.resolve()
    expected={p.name:sha(p) for p in (candidate/'sources').iterdir() if p.is_file()}
    require(len(expected)==151,'Need the complete151-source engineering snapshot')
    summary=read(candidate/'validation_summary.json')
    require(summary.get('source_sha256')==expected,'Software summary source identity differs')
    require(summary.get('software_verified') is True,'Complete source-bound video/component verification required')
    native=read(build/'native_audit.json');inputs=read(build/'offline_build_inputs.json')
    require(native.get('passed') is True,'Native setup/hold and IO must pass before packaging')
    require(native.get('timing',{}).get('row_count')==104,'Need all104 native timing rows')
    require(native.get('timing',{}).get('minimum_slack_ns',-1)>=0,'Negative native timing margin')
    require(native.get('io',{}).get('pad_count')==144,'Need exact144 IO verification')
    timing_report=build/'report_timing/video_correct_ddr_top.rtr'
    require(sha(timing_report)==native['timing']['report_sha256'],'Native timing report changed after audit')
    live_io=io_check(build/'place_route/video_correct_ddr_top.prr',build/'place_route/video_correct_ddr_top_prr.prt')
    require(inputs.get('source_sha256')==expected,'Native source identity differs from software snapshot')
    vm_inputs=read(build/'vm_source_verification.json')
    require(vm_inputs.get('passed') is True and vm_inputs.get('stage')=='before_and_after_build' and
            vm_inputs.get('source_sha256')==expected and vm_inputs.get('manifest_sha256')==inputs['manifest_sha256'] and
            vm_inputs.get('build_tcl_sha256')==inputs['build_tcl_sha256'],
            'Staged native inputs were not verified before and after the build')
    require(native.get('native_inputs_sha256')==sha(build/'offline_build_inputs.json'),'Native audit binding changed')
    native_candidate=Path(inputs['candidate'])
    require(sha(native_candidate/'project/source_manifest.json')==inputs['manifest_sha256'],'Native project manifest changed')
    require(sha(native_candidate/'project/build_full.tcl')==inputs['build_tcl_sha256'],'Native build script changed')
    baseline=ROOT/'candidate_host_angle_v2_product_stage/sources'
    for p in baseline.iterdir():
        if p.suffix=='.vp' or p.name=='board_ddr.fdc':
            require(sha(p)==expected.get(p.name),'Protected IP or board constraints changed: '+p.name)
    require(not out.exists(),'Refusing to overwrite an existing deliverable')
    archive=out.with_suffix('.zip')
    require(not archive.exists(),'Refusing to overwrite an existing archive')
    firmware=None
    if a.firmware_dir:
        firmware=read(a.firmware_dir/'verification.json')
        require(firmware.get('passed') is True and firmware.get('hardware_accessed') is False and
                firmware.get('source_sha256')==expected and firmware.get('native_audit_sha256')==sha(build/'native_audit.json'),
                'Firmware is not bound to the verified native snapshot')
        require(bool(firmware.get('files')),'No verified firmware files')
        for name,digest in firmware['files'].items():
            require(Path(name).name==name and Path(name).suffix.lower() in ['.sbit','.bit','.bin'],
                    'Unexpected firmware filename')
            require(sha(a.firmware_dir/name)==digest,'Verified firmware bytes changed')
    # Verify all copied evidence before creating the deliverable directory.
    for proof in summary['proofs'].values():
        require(sha(ROOT/proof['path'])==proof['sha256'],'Verification proof changed')
    pds=a.pds_template.read_text().replace('../candidate/sources/','../sources/')
    pds_sources=set(re.findall(r'_file "\.\./sources/([^\"]+)"',pds))
    require(pds_sources==set(expected),'GUI project source inventory differs')
    require(not re.search(r'"(?:[A-Za-z]:[/\\]|\\\\)',pds),'GUI project retains an absolute external path')
    # The portable source package does not copy native intermediate databases.
    # Leave its GUI tasks ready to rebuild instead of displaying stale success.
    pds=re.sub(r'\(_gci_state\s+\(_integer\s+\d+\)\)', '(_gci_state (_integer 0))',pds)
    out.mkdir(parents=True)
    shutil.copytree(candidate/'sources',out/'sources')
    shutil.copytree(candidate/'tests',out/'tests',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    (out/'project').mkdir()
    shutil.copy2(native_candidate/'project/build_full.tcl',out/'project/build_full.tcl')
    shutil.copy2(native_candidate/'project/source_manifest.json',out/'project/source_manifest.json')
    (out/'project/build_release.tcl').write_text(release_build_tcl())
    (out/'project/FPGA_1080p30.pds').write_text(pds)
    (out/'build_project.cmd').write_text(
        '@echo off\nsetlocal\n'
        'set "PDS_BIN=C:\\pango\\PDS_2022.2-SP6.4\\bin\\pds_shell.exe"\n'
        'if not exist "%PDS_BIN%" (echo Pango PDS executable not found. & exit /b 2)\n'
        'if not exist "%~dp0build" mkdir "%~dp0build"\n'
        'pushd "%~dp0build"\nif errorlevel 1 exit /b 2\n'
        '"%PDS_BIN%" -project_name FPGA_1080p30 -work_dir "%~dp0build" -file "%~dp0project\\build_release.tcl"\n'
        'set "FPGA_BUILD_EXIT=%ERRORLEVEL%"\npopd\nexit /b %FPGA_BUILD_EXIT%\n',newline='\r\n')
    (out/'tools').mkdir();host=ROOT/'tools/send_lens_angle.py'
    host_text=host.read_text().replace(
        'DEFAULT_CANDIDATE = Path(__file__).resolve().parents[1]/"candidate_host_angle_v2_product_stage"',
        'DEFAULT_CANDIDATE = Path(__file__).resolve().parents[1]')
    (out/'tools/send_lens_angle.py').write_text(host_text)
    (out/'requirements.txt').write_text('numpy\nopencv-python\npyserial\n')
    for name in ['evaluate_video.py','check_lens_video.py','vm_exec.py']:
        tool_text=(ROOT/'tools'/name).read_text()
        tool_text=tool_text.replace("default=ROOT/'candidate_host_angle_v2_product_stage'",'default=ROOT')
        tool_text=tool_text.replace("ROOT / 'candidate_host_angle_v2_product_stage'",'ROOT')
        (out/'tools'/name).write_text(tool_text)
    shutil.copytree(ROOT/'tests/templates',out/'tests/templates')
    shutil.copytree(ROOT/'calibration',out/'calibration',ignore=shutil.ignore_patterns('__pycache__','*.md'))
    shutil.copytree(ROOT/'external_reference/B_lens_v2/python',out/'external_reference/B_lens_v2/python',
                    ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    (out/'external_reference/B_lens_v2/examples').mkdir()
    shutil.copy2(ROOT/'external_reference/B_lens_v2/examples/real_18mm_input.png',
                 out/'external_reference/B_lens_v2/examples/real_18mm_input.png')
    evidence=out/'verification';evidence.mkdir()
    for key,proof in summary['proofs'].items():
        target=evidence/key;target.mkdir()
        src=ROOT/proof['path'];shutil.copy2(src,target/'verification.json')
        if (src.parent/'inputs.json').exists():shutil.copy2(src.parent/'inputs.json',target/'inputs.json')
    native_out=evidence/'native';native_out.mkdir()
    for src in [build/'native_audit.json',build/'offline_build_inputs.json',build/'vm_source_verification.json',
                build/'report_timing/video_correct_ddr_top.rtr',
                build/'place_route/video_correct_ddr_top.prr',
                build/'place_route/video_correct_ddr_top_prr.prt']:
        shutil.copy2(src,native_out/src.name)
    require(sha(native_out/'video_correct_ddr_top.rtr')==native['timing']['report_sha256'],
            'Timing report changed during packaging')
    require(sha(native_out/'video_correct_ddr_top.prr')==live_io['report_sha256'] and
            sha(native_out/'video_correct_ddr_top_prr.prt')==live_io['pinout_sha256'],
            'IO report changed during packaging')
    if firmware:
        firmware_out=out/'firmware';firmware_out.mkdir()
        shutil.copy2(a.firmware_dir/'verification.json',firmware_out/'verification.json')
        for name,digest in firmware['files'].items():
            shutil.copy2(a.firmware_dir/name,firmware_out/name)
            require(sha(firmware_out/name)==digest,'Firmware changed during packaging')
    qualification=dict(engineering_checks_passed=True,software_verified=True,native_verified=True,
        board_verified=False,physical_latency_measured=False,hardware_accessed=False,
        firmware_generated=firmware is not None,source_sha256=expected,native_audit_sha256=sha(build/'native_audit.json'),
        software_summary_sha256=sha(candidate/'validation_summary.json'),
        copied_io_sha256=live_io,
        source_candidate=str(candidate),native_build=str(build),
        video_metrics={k:v['metrics'] for k,v in summary['proofs'].items() if 'metrics' in v})
    (evidence/'qualification.json').write_text(json.dumps(qualification,indent=2)+'\n')
    copied={p.name:sha(p) for p in (out/'sources').iterdir() if p.is_file()}
    require(copied==expected,'Packaged source bytes changed')
    files={str(p.relative_to(out)):sha(p) for p in out.rglob('*') if p.is_file()}
    (out/'artifact_manifest.json').write_text(json.dumps(files,indent=2)+'\n')
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(out.rglob('*')):
            if p.is_file():z.write(p,Path(out.name)/p.relative_to(out))
    with zipfile.ZipFile(archive) as z:
        require(z.testzip() is None,'Archive CRC verification failed')
        for name,h in files.items():
            require(hashlib.sha256(z.read(out.name+'/'+name)).hexdigest()==h,'Archived file changed: '+name)
    print(json.dumps(dict(directory=str(out),archive=str(archive),archive_sha256=sha(archive),
                          source_count=len(expected),engineering_verified=True,board_verified=False),indent=2))


if __name__=='__main__':
    try:main()
    except (ValueError,KeyError,FileNotFoundError) as error:
        raise SystemExit('PACKAGE_REFUSED: '+str(error))
