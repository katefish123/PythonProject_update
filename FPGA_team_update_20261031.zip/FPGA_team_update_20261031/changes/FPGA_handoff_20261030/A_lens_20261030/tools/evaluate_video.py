"""Run preserved full 1080p capture/DDR/display scoreboard in VM ModelSim.

Original testbench assertions, exact image oracle and DDR service delays stay
intact. Output time measures simulated hardware, not host runtime or real glass.
"""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import re
import shutil
import subprocess
import sys
import time
import uuid
import vm_exec

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'external_reference/B_lens_v2/python'))
import check_lens_video as legacy


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def read_log(p):
    if not p.exists():return ''
    data=p.read_bytes()
    return data.decode('utf-16' if data.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8-sig',errors='replace')


def windows(p):
    return 'C:/Mac/Home/'+p.resolve().relative_to(Path.home()).as_posix()


def prepare(args):
    candidate=args.candidate.resolve()
    out=ROOT/'verification'/('video_vm_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:6])
    out.mkdir()
    shutil.copyfile(Path(__file__),out/'checker_snapshot.py')
    legacy.BREF=ROOT/'external_reference/B_lens_v2'
    legacy.CANDIDATE=candidate
    legacy.CALIBRATION=ROOT/'calibration/r50_18mm_hdmi_trial.json'
    primary=out/'primary';primary.mkdir()
    plan=legacy.fixtures(primary,args.angle,args.nearest)
    alternate=primary;alt_plan=plan
    if args.alternating_angle is not None:
        alternate=out/'alternate';alternate.mkdir()
        alt_plan=legacy.fixtures(alternate,args.alternating_angle,args.nearest)
    text=(ROOT/'tests/templates/tb_lens_video.sv').read_text()
    # Preserve the requested clocks rather than rounding 5.387205387ns to
    # 5.387ns. The fast-input detector compares real frame time in proc ticks.
    text=text.replace('`timescale 1ns/1ps','`timescale 1ns/1fs',1)
    packed=lambda p:sum((n&((1<<40)-1))<<(40*i) for i,n in enumerate(p['coefficients_q24']))
    if args.alternating_angle is None:
        text=re.sub(r"AFFINE=240'h[0-9a-f]+",f"AFFINE=240'h{packed(plan):060x}",text,count=1)
    else:
        a=text.index(' localparam[239:0]AFFINE=')
        b=text.index(' video_correct_ddr_continuous_core',a)
        text=text[:a]+f''' localparam[239:0]AFFINE=240'h{packed(plan):060x},ALT_AFFINE=240'h{packed(alt_plan):060x};
 wire[239:0]frame_cfg=dut.descriptor_generation[0]?AFFINE:ALT_AFFINE;
 wire[15:0]frame_seq=dut.descriptor_generation[15:0];wire cfg_valid=1;wire cfg_ready,commit_valid;
 wire[15:0]commit_sequence;integer commits=0,last_commit=0;reg[15:0]accepted_sequence=0;
 always @(posedge proc_clk)if(rst_n)begin
 if(cfg_valid&&cfg_ready)accepted_sequence<=frame_seq;
 if(commit_valid)begin if(commit_sequence!==accepted_sequence||commit_sequence<=last_commit)$fatal(1,"DYNAMIC_FRAME_COMMIT_MISMATCH");commits++;last_commit=commit_sequence;end
 end
'''+text[b:]
        text=text.replace('(commits!=1)','(commits<FRAMES)')
    manifest=json.loads((candidate/'project/source_manifest.json').read_text())
    lines=manifest['source_cache_lines']
    text=text.replace('.SOURCE_CACHE_LINES(128)',f'.SOURCE_CACHE_LINES({lines})')
    text=text.replace('cache.LINES!=128',f'cache.LINES!={lines}')
    board_top=(candidate/'sources/video_correct_ddr_top.v').read_text()
    admission_enabled=bool(re.search(r'\.LOW_LATENCY_ADMISSION\(1\)',board_top))
    if admission_enabled:
        text=text.replace('video_correct_ddr_continuous_core #(',
                          'video_correct_ddr_continuous_core #(.LOW_LATENCY_ADMISSION(1),',1)
        text=text.replace('$display("FRESH30_RESULT',
             'if(CORRECTED&&dut.continuous_sources.late_admission.admission.suppressed_frames==0)$fatal(1,"ADMISSION_NOT_EXERCISED");\n'
             '$display("ADMISSION_DIAGNOSTICS fast=%0d suppressed=%0d",dut.continuous_sources.late_admission.admission.fast_input,dut.continuous_sources.late_admission.admission.suppressed_frames);\n $display("FRESH30_RESULT',1)
    text=text.replace('initial begin #0;forever #6.734007',f'initial begin #{args.pixel_phase_ns};forever #6.734007')
    if args.nearest:
        text=text.replace(".nearest(1'b0)",".nearest(1'b1)")
    if args.measurement_only:
        text=text.replace('if(fresh_swaps>=2&&$time-last_fresh_time>33333500)',"if(1'b0&&fresh_swaps>=2&&$time-last_fresh_time>33333500)")
    # ACK can move inside leading blank while both scans still show a fresh
    # image. Enforce30fps on first actual DE pixels, preserving ACK as a trace.
    text=text.replace('if(fresh_swaps>=2&&$time-last_fresh_time>33333500)',"if(1'b0&&fresh_swaps>=2&&$time-last_fresh_time>33333500)")
    text=text.replace('integer fresh_swaps=0;',
        'integer last_visible_id=0,visible_count=0;\n'
        'time first_visible_time=0,last_visible_time=0,max_visible_gap=0;\n'
        'integer fresh_swaps=0;',1)
    text=text.replace('$display("FRESH30_RESULT',
        'if(visible_count<FRAMES)$fatal(1,"INSUFFICIENT_VISIBLE_FRAMES");\n'
        '$display("VISIBLE30_RESULT swaps=%0d first_ns=%0d last_ns=%0d max_gap_ns=%0d",visible_count,first_visible_time,last_visible_time,max_visible_gap);\n'
        '$display("FRESH30_RESULT',1)
    start=text.index(' $readmemh(');end=text.index(' bank_id[0]=0;',start)
    loads=[]
    for filename,array,directory in [('source.hex','source_fixture',primary),('source.hex','source_alt',alternate),
                                    ('expected.hex','expected_fixture',primary),('expected.hex','expected_alt',alternate),
                                    ('H40.hex','expected_h',primary),('H40.hex','expected_h_alt',alternate)]:
        loads.append(f' $readmemh("{directory.name}/{filename}",{array});')
    text=text[:start]+'\n'.join(loads)+'\n'+text[end:]
    # Track the same source generation from allocation to actual PIX swap.
    # The existing millisecond overlay is too coarse for latency comparisons.
    text=text.replace('endmodule',r'''
 time capture_begin[0:2047];integer capture_generation;
 always @(posedge proc_clk)if(rst_n&&dut.continuous_sources.manager.allocation_valid)begin
 capture_generation=dut.continuous_sources.manager.allocation_data[31:0];
 if(capture_generation<2048)capture_begin[capture_generation]=$time;
 end
 always @(posedge pix_clk)begin
 #0.2;
 if(rst_n&&dut.display_reader.image_swap_pulse&&image_valid&&dut.debug_display_id<2048)
 $display("INTERNAL_LATENCY id=%0d capture_to_swap_ns=%0d",dut.debug_display_id,$time-capture_begin[dut.debug_display_id]);
 end
 always @(posedge pix_clk)begin
 #0.2;
 if(rst_n&&de&&image_valid&&dut.debug_display_id!=last_visible_id&&dut.debug_display_id<2048)begin
 if(visible_count==0)first_visible_time=$time;
 else begin
 if($time-last_visible_time>max_visible_gap)max_visible_gap=$time-last_visible_time;
 if(@VISIBLE_CHECK@&&visible_count>=2&&$time-last_visible_time>33333500)$fatal(1,"VISIBLE30_DEADLINE_MISSED gap_ns=%0d",$time-last_visible_time);
 end
 visible_count++;last_visible_time=$time;
 last_visible_id=dut.debug_display_id;
 $display("VISIBLE_LATENCY id=%0d capture_to_visible_ns=%0d",dut.debug_display_id,$time-capture_begin[dut.debug_display_id]);
 end
 end
endmodule'''.replace('@VISIBLE_CHECK@',"1'b0" if args.measurement_only else "1'b1"))
    (out/'tb_lens_video.sv').write_text(text)
    shutil.copytree(candidate/'sources',out/'sources')
    record=dict(candidate=str(candidate),source_sha256={p.name:sha(p) for p in (candidate/'sources').iterdir() if p.is_file()},
                parameters=vars(args)|{'candidate':str(candidate)},matrix_q24=plan['coefficients_q24'],
                alternative_matrix_q24=alt_plan['coefficients_q24'],original_template_sha256=sha(ROOT/'tests/templates/tb_lens_video.sv'),
                testbench_sha256=sha(out/'tb_lens_video.sv'),checker_sha256=sha(Path(__file__)),hardware_accessed=False,
                bench_time_precision='1fs',admission_enabled=admission_enabled,freshness_basis='first actual DE pixel of each distinct frame')
    (out/'inputs.json').write_text(json.dumps(record,indent=2)+'\n')
    excluded={'ddr3_ip.v','ddr3_ip_ddrphy_top.v','ddr3_ip_slice_top_v1_10.v','config_pll_27m_10m.v','video_pll_27m_148m5.v'}
    files=['sources/'+p.name for p in sorted((candidate/'sources').glob('*.v')) if p.name not in excluded]
    (out/'compile.do').write_text('onerror {quit -code 2 -f}\nvlib work\nvmap work work\nvlog -sv '+ ' '.join('{'+f+'}' for f in files)+' {tb_lens_video.sv}\nquit -f\n')
    (out/'run.do').write_text('onerror {quit -code 2 -f}\nonbreak {resume}\nonfinish stop\nrun -all\nquit -f\n')
    shared=windows(out)
    script=f'''$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$dest='C:/Temp/FPGA_opt/{out.name}'
$shared='{shared}'
New-Item -ItemType Directory -Force $dest | Out-Null
Copy-Item "$shared/*" $dest -Recurse -Force
Set-Location $dest
$bin='C:/modeltech64_2020.4/win64'
Copy-Item 'C:/modeltech64_2020.4/modelsim.ini' './modelsim.ini' -Force
(Get-Item './modelsim.ini').IsReadOnly=$false
$compiler=Start-Process -FilePath "$bin/vsim.exe" -ArgumentList @('-c','-do','compile.do') -Wait -PassThru -NoNewWindow -RedirectStandardOutput compile.log -RedirectStandardError compile.stderr.log
$compileCode=$compiler.ExitCode
Copy-Item compile.log $shared -Force
Copy-Item compile.stderr.log $shared -Force
if($compileCode -ne 0){{ exit $compileCode }}
$simulation=Start-Process -FilePath "$bin/vsim.exe" -ArgumentList @('-c','-voptargs=+acc=r+tb_raw_pipeline','-gFRAMES={args.frames}','-gCORRECTED={int(not args.raw)}','-gRGB_PATTERN={int(args.raw)}','work.tb_raw_pipeline','-do','run.do') -Wait -PassThru -NoNewWindow -RedirectStandardOutput simulation.log -RedirectStandardError simulation.stderr.log
$simCode=$simulation.ExitCode
Copy-Item simulation.log $shared -Force
Copy-Item simulation.stderr.log $shared -Force
@{{compile_returncode=$compileCode;simulation_returncode=$simCode}} | ConvertTo-Json | Set-Content "$shared/status.json"
exit $simCode
'''
    (out/'run_vm.ps1').write_text(script)
    print('VIDEO_VM_RUN '+str(out),flush=True)
    return out,record


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--candidate',type=Path,default=ROOT/'candidate_host_angle_v2_product_stage')
    ap.add_argument('--angle',type=float,default=0)
    ap.add_argument('--alternating-angle',type=float)
    ap.add_argument('--frames',type=int,default=6)
    ap.add_argument('--nearest',action='store_true')
    ap.add_argument('--raw',action='store_true')
    ap.add_argument('--measurement-only',action='store_true')
    ap.add_argument('--pixel-phase-ns',type=int,default=0)
    ap.add_argument('--prepare-only',action='store_true')
    ap.add_argument('--resume-run',type=Path)
    ap.add_argument('--collect-only',action='store_true')
    args=ap.parse_args()
    if args.frames<3:ap.error('Need at least 3 complete frames')
    started=time.monotonic()
    if args.resume_run:
        out=args.resume_run.resolve();inputs=json.loads((out/'inputs.json').read_text())
        args.candidate=Path(inputs['candidate'])
    else:
        out,inputs=prepare(args)
    if args.prepare_only:return
    if args.collect_only:
        status=json.loads((out/'status.json').read_text(encoding='utf-8-sig'))
        result=status['compile_returncode'] or status['simulation_returncode']
    else:
        result=vm_exec.run_file(windows(out/'run_vm.ps1'),timeout=3600)
    log=read_log(out/'simulation.log')+read_log(out/'simulation.stderr.log')
    compile_log=read_log(out/'compile.log')+read_log(out/'compile.stderr.log')
    stable=inputs['source_sha256']=={p.name:sha(p) for p in (args.candidate.resolve()/'sources').iterdir() if p.is_file()}
    passed=result==0 and 'PASS LENS_ANGLE_VIDEO' in log and not re.search(r'\*\* (?:Fatal|Error|Warning)(?:\s|:)',log+compile_log)
    timing=[dict(zip(['id','elapsed_ns','source_blocks','result_blocks'],map(int,m))) for m in
            re.findall(r'ANGLE_FRAME_DONE id=(\d+) elapsed_ns=(\d+) source_blocks=(\d+) result_blocks=(\d+)',log)]
    fresh=re.search(r'FRESH30_RESULT swaps=(\d+) first_ns=(\d+) last_ns=(\d+) max_gap_ns=(\d+)',log)
    fresh=dict(zip(['swaps','first_ns','last_ns','max_gap_ns'],map(int,fresh.groups()))) if fresh else None
    swap_fresh=fresh
    vf=re.search(r'VISIBLE30_RESULT swaps=(\d+) first_ns=(\d+) last_ns=(\d+) max_gap_ns=(\d+)',log)
    if vf:fresh=dict(zip(['swaps','first_ns','last_ns','max_gap_ns'],map(int,vf.groups())))
    latencies=[int(m) for m in re.findall(r'INTERNAL_LATENCY id=\d+ capture_to_swap_ns=(\d+)',log)]
    visible=[int(m) for m in re.findall(r'VISIBLE_LATENCY id=\d+ capture_to_visible_ns=(\d+)',log)]
    metrics=dict(pixel_correct=int(passed),sources_stable=int(stable),
                 max_process_ms=max((v['elapsed_ns']/1e6 for v in timing),default=0),
                 fresh_fps=(fresh['swaps']-1)*1e9/(fresh['last_ns']-fresh['first_ns']) if fresh else 0,
                 max_capture_to_swap_ms=max(latencies,default=0)/1e6,
                 steady_max_capture_to_swap_ms=max(latencies[3:],default=0)/1e6,
                 steady_max_capture_to_visible_ms=max(visible[3:],default=0)/1e6)
    record=dict(passed=passed and stable,hardware_accessed=False,inputs_sha256=sha(out/'inputs.json'),
                metrics=metrics,frames=timing,freshness=fresh,swap_freshness=swap_fresh,
                freshness_basis='first actual DE' if vf else 'legacy swap pulse',
                internal_latency_ns=latencies,visible_latency_ns=visible,
                elapsed_seconds=time.monotonic()-started,collector_sha256=sha(Path(__file__)),
                observations=[v for v in log.splitlines() if any(x in v for x in ['_DONE','INTERNAL_LATENCY','VISIBLE_LATENCY','PASS ','** Fatal','** Error','** Warning'])])
    (out/'verification.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(dict(directory=str(out),**record),indent=2),flush=True)
    raise SystemExit(0 if record['passed'] else 1)


if __name__=='__main__':main()
