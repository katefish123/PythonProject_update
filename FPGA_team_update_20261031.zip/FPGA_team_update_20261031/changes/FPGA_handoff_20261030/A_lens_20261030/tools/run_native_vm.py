"""Run a prepared build-only job and bind collected Pango reports to its bytes."""
from pathlib import Path
import argparse
import hashlib
import json
import time
import vm_exec

sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    ap=argparse.ArgumentParser();ap.add_argument('build',type=Path)
    a=ap.parse_args();out=a.build.resolve()
    p=out/'offline_build_inputs.json';record=json.loads(p.read_text())
    candidate=Path(record['candidate'])
    actual=lambda:{p.name:sha(p) for p in (candidate/'sources').iterdir() if p.is_file()}
    assert actual()==record['source_sha256'],'source mismatch before native build'
    assert sha(candidate/'project/build_full.tcl')==record['build_tcl_sha256']
    record['status']='running';p.write_text(json.dumps(record,indent=2)+'\n')
    print('NATIVE_VM_RUN '+str(out),flush=True);started=time.monotonic()
    windows_script='C:/Mac/Home/'+(out/'run_vm.ps1').relative_to(Path.home()).as_posix()
    code=vm_exec.run_file(windows_script,timeout=14400)
    status=json.loads((out/'status.json').read_text(encoding='utf-8-sig')) if (out/'status.json').exists() else {}
    final_status=status.get('status','failed')
    if code and final_status=='running':final_status='interrupted'
    record.update(status=final_status,returncode=code,elapsed_seconds=time.monotonic()-started,
                  sources_unchanged=actual()==record['source_sha256'],
                  reports={str(f.relative_to(out)):sha(f) for f in out.rglob('*.rtr')})
    p.write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({k:record[k] for k in ['status','returncode','elapsed_seconds','sources_unchanged','reports']},indent=2),flush=True)
    raise SystemExit(code or (0 if record['sources_unchanged'] else 1))


if __name__=='__main__':main()
