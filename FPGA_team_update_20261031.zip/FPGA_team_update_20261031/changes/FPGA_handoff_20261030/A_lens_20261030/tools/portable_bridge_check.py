"""Replay the handoff's bridge equivalence regression with Icarus Verilog."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import time
import check_bridge_decode as original

ROOT = Path(__file__).resolve().parents[1]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--candidate', type=Path, default=ROOT/'candidate_host_angle_v3_cache64')
    args = ap.parse_args()
    out = ROOT/'verification'/('portable_bridge_'+str(time.time_ns()))
    out.mkdir()
    for name, dims in [('large',(1920,1080,1920,1080)), ('small',(128,16,64,16))]:
        vectors, expected = original.vectors(*dims, 5000)
        (out/(name+'_input.hex')).write_text(''.join(f'{v:050x}\n' for v in vectors))
        (out/(name+'_expected.hex')).write_text(''.join(f'{v:032x}\n' for v in expected))
    ports = ['proc_clk','ui_clk','rst_n','q_valid','q_ready','q_inside','q_nearest',
             'q_addr00','q_addr10','q_addr01','q_addr11','q_tag','q_fx','q_fy',
             'q_generation','q_base','fault','req_valid','req_ready','req_base',
             'req_generation','req_x','req_y','req_nearest','req_inside','req_tag',
             'req_fx','req_fy','rsp_ready','r_valid','r_inside','r_p00','r_p10',
             'r_p01','r_p11','r_tag','r_fx','r_fy','r_generation']
    connection = ','.join(f'.{p}({p})' for p in ports)
    connection += ",.rsp_valid(1'b0),.rsp_inside(1'b0),.rsp_p00(24'd0),.rsp_p10(24'd0),.rsp_p01(24'd0),.rsp_p11(24'd0),.rsp_tag(24'd0),.rsp_fx(8'd0),.rsp_fy(8'd0),.rsp_generation(32'd0),.r_ready(1'b1)"
    bench = original.BENCH.replace('@PORTS@', connection)
    # Verilog disallows mixing initialized nets and plain declarations;
    # 'large' is also a reserved drive-strength keyword.
    bench = bench.replace('q_valid=rst_n&&sent<N&&ptick%9>=2,q_ready;',
                          'q_valid=rst_n&&sent<N&&ptick%9>=2;wire q_ready;')
    bench = bench.replace('req_valid,req_ready=rst_n&&utick%37>=20;',
                          'req_valid;wire req_ready=rst_n&&utick%37>=20;')
    bench = bench.replace('bridge_case large(a);', 'bridge_case native_extent(a);')
    (out/'tb_bridge.sv').write_text(bench)
    old = ROOT/'candidate_host_angle_v2_product_stage/sources/quad_packet_bridge.v'
    ref = out/'quad_packet_bridge_reference.v'
    ref.write_text(old.read_text().replace('module quad_packet_bridge #(',
                                          'module quad_packet_bridge_reference #(', 1))
    source = args.candidate.resolve()/'sources'
    files = [source/n for n in ['quad_packet_bridge.v','async_packet_stream.v','async_packet_fifo.v']]
    files += [ref, out/'tb_bridge.sv']
    hashes = {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    started = time.monotonic()
    for argv, log in [(['iverilog','-g2012','-s','tb_bridge','-o',str(out/'sim'), *map(str,files)], 'compile.log'),
                      (['vvp',str(out/'sim')], 'simulation.log')]:
        with (out/log).open('w') as f:
            result = subprocess.run(argv, cwd=out, stdout=f, stderr=subprocess.STDOUT, timeout=180)
        if result.returncode:
            print((out/log).read_text())
            raise SystemExit(result.returncode)
    log = (out/'simulation.log').read_text()
    passed = 'BRIDGE_DECODE_EQUIVALENCE_PASS' in log and 'FATAL:' not in log
    assert all(hashlib.sha256(p.read_bytes()).hexdigest()==hashes[str(p)] for p in files)
    record = dict(passed=passed, candidate=str(args.candidate.resolve()),
                  division_domain_exhaustive=all((n*34953)>>19==n//15 for n in range(65536)),
                  hardware_accessed=False, source_sha256=hashes,
                  elapsed_seconds=time.monotonic()-started, observations=log.splitlines())
    (out/'verification.json').write_text(json.dumps(record, indent=2)+'\n')
    print(json.dumps(dict(directory=str(out),**record), indent=2))
    raise SystemExit(0 if passed else 1)


if __name__=='__main__':
    main()
