"""Check every native timing corner and preserve the source-bound144 IO map."""
from pathlib import Path
import argparse
import hashlib
import json
import re
from audit_native import timing_rows,io_props,read_pinout

ROOT=Path(__file__).resolve().parents[1]
REFERENCE=ROOT/'tests/native_reference'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()


def io_check(report,pins):
    a=io_props(REFERENCE/'video_correct_ddr_top.prr');b=io_props(report)
    pa=read_pinout(REFERENCE/'video_correct_ddr_top_prr.prt');pb=read_pinout(pins)
    if not (len(a)==144 and set(a)==set(b)==set(pa)==set(pb)):
        raise ValueError('IO inventory changed')
    for name in a:
        for field in ['pad','cell','function','direction','constrained','physical_bank']:
            if pa[name][field]!=pb[name][field]:raise ValueError(f'{name}: physical {field} changed')
        aa,bb=a[name].copy(),b[name].copy()
        aa[2]=pa[name]['physical_bank'];bb[2]=pb[name]['physical_bank']
        if aa!=bb:raise ValueError(f'{name}: electrical attributes changed')
    if pb['uart_rx']['pad']!='B24' or pb['uart_tx']['pad']!='C24':raise ValueError('UART physical pin changed')
    return dict(passed=True,pad_count=144,report_sha256=sha(report),pinout_sha256=sha(pins),
                reference='V1 exact144 IO map; reference timing is failed and never reused as a passing result')


def audit(build):
    record=json.loads((build/'offline_build_inputs.json').read_text())
    candidate=Path(record['candidate'])
    failures=[]
    current={p.name:sha(p) for p in (candidate/'sources').iterdir() if p.is_file()}
    if current!=record['source_sha256']:failures.append('Current sources differ from build input')
    if (candidate/'sources/board_ddr.fdc').read_bytes()!=(ROOT/'candidate_host_angle_v2_product_stage/sources/board_ddr.fdc').read_bytes():
        failures.append('Original timing or IO constraints changed')
    report=build/'report_timing/video_correct_ddr_top.rtr'
    timing={'passed':False}
    if report.exists():
        text=report.read_text(errors='replace')
        rows=timing_rows(text,require_pass=False)
        ref=timing_rows((REFERENCE/'video_correct_ddr_top.rtr').read_text(errors='replace'),require_pass=False)
        keys=lambda rs:{(r['kind'],r['corner'],tuple(r['clocks'])) for r in rs}
        if keys(rows)!=keys(ref):failures.append('Timing corner/clock coverage changed')
        expected={'sys_clk_27m':37.037037,'rx_pixel':6.734007,'cfg_clock':100.,'processing_clock':10.774410,
                  'pixel_clock':13.468013,'tx_pixel':13.468013,'ref_clk':8.,'rst_clk':8.,'ddrphy_sysclk':8.,
                  'phy_dq_clk_0':1.,'phy_dq_clk_1':1.,'phy_dq_sysclk_0':8.,'phy_dq_sysclk_1':8.}
        for name,period in expected.items():
            m=re.search(r'(?m)^\s*'+re.escape(name)+r'\s+([0-9.]+)\s+\{',text)
            # This PDS version quantizes clock periods to a1ps timing grid,
            # then prints four decimals. The unchanged10.774410ns constraint
            # is reported as10.7740ns; allow only half a picosecond rounding.
            if not m or abs(float(m[1])-period)>.00051:failures.append('Clock mismatch: '+name)
        bad=[r for r in rows if r['slack_ns']<0 or r['total_slack_ns']<0 or r['failing_endpoints']]
        try:timing_rows(text,require_pass=True)
        except ValueError as e:failures.append(str(e))
        timing=dict(passed=not bad,row_count=len(rows),minimum_slack_ns=min(r['slack_ns'] for r in rows),
                    minimum_setup_ns=min(r['slack_ns'] for r in rows if r['kind']=='Setup'),
                    minimum_hold_ns=min(r['slack_ns'] for r in rows if r['kind']=='Hold'),
                    negative_rows=bad,report_sha256=sha(report))
    else:failures.append('Final report_timing report unavailable')
    try:io=io_check(build/'place_route/video_correct_ddr_top.prr',build/'place_route/video_correct_ddr_top_prr.prt')
    except (AssertionError,ValueError,FileNotFoundError) as e:io={'passed':False,'error':str(e)};failures.append('IO: '+str(e))
    if record.get('status')!='completed' or record.get('returncode')!=0:failures.append('Native build did not complete successfully')
    result=dict(passed=not failures,qualified=False,hardware_accessed=False,failures=failures,timing=timing,io=io,
                source_manifest_sha256=sha(candidate/'project/source_manifest.json'),native_inputs_sha256=sha(build/'offline_build_inputs.json'),
                auditor_sha256=sha(Path(__file__)),scope='Native timing and IO only; real-board optical and latency acceptance remain separate.')
    (build/'native_audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    return result['passed']


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('build',type=Path)
    a=ap.parse_args();raise SystemExit(0 if audit(a.build.resolve()) else 1)
