"""Bind exact portable source inputs; prepare build-only Pango job for the VM."""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import re
import uuid
from evaluate_video import windows

ROOT=Path(__file__).resolve().parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--candidate',type=Path,required=True)
    ap.add_argument('--route-iterations',type=int,choices=[1,2,3],default=1)
    ap.add_argument('--placement-seed',type=int,default=73)
    ap.add_argument('--route-seed',type=int,default=91)
    ap.add_argument('--fix-hold-violation',action=argparse.BooleanOptionalAction,default=True,help='Enable PDS hold timing optimization (default on); threshold alone does not enable it')
    ap.add_argument('--no-congestion-plot',action='store_true',help='Skip routing diagnostic plots; timing checks remain unchanged')
    args=ap.parse_args();candidate=args.candidate.resolve()
    project=candidate/'project';project.mkdir(exist_ok=True)
    reference=(ROOT/'candidate_host_angle_v2_product_stage/project/build_full.tcl').read_text()
    # Relative root works after copying this exact candidate to the Windows disk.
    script=re.sub(r'^set root .*', 'set root [file normalize [file join [file dirname [info script]] ..]]',reference,count=1)
    # Artifacts are generated only after an independent positive timing review.
    script=re.sub(r'^gen_bit_stream .*\n?', '',script,flags=re.M)
    script=re.sub(r'-gplace_seed\s+\d+',f'-gplace_seed {args.placement_seed}',script)
    script=re.sub(r'-groute_seed\s+\d+',f'-groute_seed {args.route_seed}',script)
    script=re.sub(r'-route_constraint_iterate_times\s+\d+',f'-route_constraint_iterate_times {args.route_iterations}',script)
    if args.fix_hold_violation:
        script=script.replace('pnr -gplace_seed','pnr -fix_hold_violation -gplace_seed',1)
    if not args.no_congestion_plot:
        script=script.replace('pnr ', 'pnr -dump_router_congestion_plot TRUE ',1)
    files=re.findall(r'(?:add_design|add_constraint) \[file join \$root sources ([^\]]+)\]',script)
    actual={p.name:sha(p) for p in (candidate/'sources').iterdir() if p.is_file()}
    assert len(files)==len(set(files)) and set(files)==set(actual),'source-list mismatch'
    fdc=(candidate/'sources/board_ddr.fdc').read_bytes()
    baseline_fdc=(ROOT/'candidate_host_angle_v2_product_stage/sources/board_ddr.fdc').read_bytes()
    assert fdc==baseline_fdc,'timing/IO constraints changed'
    (project/'build_full.tcl').write_text(script)
    prior=json.loads((project/'source_manifest.json').read_text())
    prior.update(source_sha256=actual,build_tcl_sha256=sha(project/'build_full.tcl'),qualified=False,
                 hardware_accessed=False,portable_build_only=True,
                 parent_source_manifest_sha256=sha(ROOT/'candidate_host_angle_v2_product_stage/project/source_manifest.json'))
    (project/'source_manifest.json').write_text(json.dumps(prior,indent=2)+'\n')
    job='pds_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:5]
    out=candidate/'build'/job;out.mkdir(parents=True)
    dest='C:/Temp/FPGA_opt/native_'+job
    shared=windows(out)
    ps=f'''$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$dest='{dest}'
$shared='{shared}'
New-Item -ItemType Directory -Force "$dest/candidate" | Out-Null
Copy-Item '{windows(candidate/'sources')}' "$dest/candidate/sources" -Recurse -Force
Copy-Item '{windows(project)}' "$dest/candidate/project" -Recurse -Force
$locked=Get-Content "$shared/offline_build_inputs.json" -Raw | ConvertFrom-Json
function Assert-StagedInputs {{
 if(@($locked.source_sha256.PSObject.Properties).Count -ne 151){{throw 'Incomplete staged source manifest'}}
 foreach($entry in $locked.source_sha256.PSObject.Properties) {{
  $path=Join-Path "$dest/candidate/sources" $entry.Name
  if((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -cne $entry.Value){{throw "Staged source differs: $($entry.Name)"}}
 }}
 if((Get-FileHash "$dest/candidate/project/build_full.tcl" -Algorithm SHA256).Hash.ToLowerInvariant() -cne $locked.build_tcl_sha256){{throw 'Staged build script differs'}}
 if((Get-FileHash "$dest/candidate/project/source_manifest.json" -Algorithm SHA256).Hash.ToLowerInvariant() -cne $locked.manifest_sha256){{throw 'Staged project manifest differs'}}
}}
Assert-StagedInputs
@{{passed=$true;stage='before_build';source_count=151;hardware_accessed=$false;source_sha256=$locked.source_sha256;manifest_sha256=$locked.manifest_sha256;build_tcl_sha256=$locked.build_tcl_sha256}} | ConvertTo-Json -Depth 8 | Set-Content "$shared/vm_source_verification.json"
New-Item -ItemType Directory -Force "$dest/build" | Out-Null
Set-Location "$dest/build"
@{{status='running';local_build="$dest/build";started=(Get-Date -Format o)}} | ConvertTo-Json | Set-Content "$shared/status.json"
$proc=Start-Process -FilePath 'C:/pango/PDS_2022.2-SP6.4/bin/pds_shell.exe' -ArgumentList @('-project_name','Lens_Angle_1080p30','-work_dir',"$dest/build",'-file',"$dest/candidate/project/build_full.tcl") -PassThru -NoNewWindow -RedirectStandardOutput "$dest/build/build.log" -RedirectStandardError "$dest/build/stderr.log"
$null=$proc.Handle
$proc.WaitForExit()
$proc.Refresh()
Assert-StagedInputs
@{{passed=$true;stage='before_and_after_build';source_count=151;hardware_accessed=$false;source_sha256=$locked.source_sha256;manifest_sha256=$locked.manifest_sha256;build_tcl_sha256=$locked.build_tcl_sha256}} | ConvertTo-Json -Depth 8 | Set-Content "$shared/vm_source_verification.json"
Get-ChildItem "$dest/build" -Recurse -File | Where-Object {{ $_.Extension -in '.rtr','.prr','.prt','.log','.txt','.tcl','.csv' -and $_.Length -lt 20000000 }} | ForEach-Object {{
 $relative=$_.FullName.Substring((Get-Item "$dest/build").FullName.Length+1)
 $target=Join-Path $shared $relative
 New-Item -ItemType Directory -Force (Split-Path $target) | Out-Null
 Copy-Item $_.FullName $target -Force
}}
@{{status=if($proc.ExitCode -eq 0){{'completed'}}else{{'failed'}};returncode=$proc.ExitCode;local_build="$dest/build";completed=(Get-Date -Format o)}} | ConvertTo-Json | Set-Content "$shared/status.json"
exit $proc.ExitCode
'''
    (out/'run_vm.ps1').write_text(ps)
    record=dict(status='prepared',hardware_accessed=False,qualified=False,candidate=str(candidate),
                source_sha256=actual,manifest_sha256=sha(project/'source_manifest.json'),
                build_tcl_sha256=sha(project/'build_full.tcl'),vm_local_build=dest+'/build',
                io_and_timing_constraints_unchanged=True,firmware_generation_requested=False)
    record['placement_options']={'placement_seed':args.placement_seed,'route_seed':args.route_seed,'route_iterations':args.route_iterations,'congestion_plot':not args.no_congestion_plot,'fix_hold_violation':args.fix_hold_violation}
    (out/'offline_build_inputs.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(dict(build=str(out),vm_local_build=dest+'/build',source_count=len(files)),indent=2))


if __name__=='__main__':main()
