"""Summarize source-bound simulation/native evidence without claiming board tests."""
from pathlib import Path
import argparse
import hashlib
import json

ROOT=Path(__file__).resolve().parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()


def tested_sources_match(bound, hashes, required, source_prefix=None):
    selected={Path(k).name:h for k,h in bound.items()
              if '/sources/' in k and (source_prefix is None or source_prefix in k)}
    return set(required).issubset(selected) and all(hashes.get(k)==h for k,h in selected.items())


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--candidate',type=Path,required=True)
    a=ap.parse_args();candidate=a.candidate.resolve()
    hashes={p.name:sha(p) for p in (candidate/'sources').iterdir() if p.is_file()}
    proofs={};missing=[]
    for p in sorted((ROOT/'verification').glob('video_vm_*/verification.json')):
        inputs=p.parent/'inputs.json'
        if not inputs.exists():continue
        d=json.loads(inputs.read_text());v=json.loads(p.read_text())
        if d.get('source_sha256')!=hashes or not v.get('passed'):continue
        par=d['parameters']
        if par['frames']<6 or d.get('bench_time_precision')!='1fs':continue
        if not v.get('freshness') or v['freshness']['max_gap_ns']>33333500:continue
        if par.get('raw'):key='raw'
        elif par.get('nearest') and par.get('angle')==12:key='nearest12'
        elif par.get('alternating_angle')==90 and par.get('angle')==0:key='dynamic0_90'
        elif par.get('alternating_angle') is None and not par.get('nearest') and par.get('angle')==0:key='bilinear0'
        elif par.get('alternating_angle') is None and not par.get('nearest') and par.get('angle')==90:key='bilinear90'
        else:continue
        proofs[key]={'path':str(p.relative_to(ROOT)),'sha256':sha(p),'metrics':v['metrics']}
    for key in ['bilinear0','bilinear90','dynamic0_90','raw','nearest12']:
        if key not in proofs:missing.append(key)
    unit=candidate/'verification/verification.json'
    if unit.exists():
        u=json.loads(unit.read_text())
        if u.get('passed') and u.get('source_sha256')==hashes:
            proofs['capture_modes_and_rates']={'path':str(unit.relative_to(ROOT)),'sha256':sha(unit)}
    if 'capture_modes_and_rates' not in proofs:missing.append('capture_modes_and_rates')
    for p in sorted((ROOT/'verification').glob('portable_bridge_*/verification.json')):
        v=json.loads(p.read_text())
        if not v.get('passed'):continue
        bound=v.get('source_sha256',{})
        if tested_sources_match(bound, hashes, {'quad_packet_bridge.v','async_packet_stream.v','async_packet_fifo.v'}):
            proofs['request_bridge']={'path':str(p.relative_to(ROOT)),'sha256':sha(p)}
    if 'request_bridge' not in proofs:missing.append('request_bridge')
    # Accept only final recovery integration with all exercised source components bound.
    recovery_sources={'continuous_source_path.v','continuous_capture_rx.v',
                      'continuous_capture_writer.v','manager_raw.v','c_frame_mode_controller.v',
                      'async_packet_stream.v','async_packet_fifo.v',
                      'async_packet_stream_monitored.v','async_packet_fifo_monitored.v','snapshot_cdc.v'}
    for experiment in ['admission_recovery','display_shift']:
        mode=ROOT/f'experiments/{experiment}/verification/recovery_verification.json'
        if not mode.exists():continue
        v=json.loads(mode.read_text());bound=v.get('input_sha256',{})
        if (v.get('passed') and v.get('sources_unchanged') and
            tested_sources_match(bound,hashes,recovery_sources,f'/experiments/{experiment}/sources/')):
            proofs['mode_entry_recovery']={'path':str(mode.relative_to(ROOT)),'sha256':sha(mode)}
    mode=candidate/'verification/recovery_verification.json'
    if mode.exists():
        v=json.loads(mode.read_text())
        if (v.get('passed') and v.get('sources_unchanged') and
            tested_sources_match(v.get('input_sha256',{}),hashes,recovery_sources,str(candidate/'sources')+'/')):
            proofs['mode_entry_recovery']={'path':str(mode.relative_to(ROOT)),'sha256':sha(mode)}
    if 'mode_entry_recovery' not in proofs:missing.append('mode_entry_recovery')
    native=None
    native_reports=list((candidate/'build').glob('*/native_audit.json'))
    native_reports+=list((ROOT/'experiments').glob('native_*/build/*/native_audit.json'))
    for p in sorted(native_reports):
        v=json.loads(p.read_text());i=json.loads((p.parent/'offline_build_inputs.json').read_text())
        if (v.get('passed') and i.get('source_sha256')==hashes and
            v.get('native_inputs_sha256')==sha(p.parent/'offline_build_inputs.json')):
            native={'path':str(p.relative_to(ROOT)),'sha256':sha(p),'timing':v['timing'],'io':v['io']}
    # A reused MAP must pass the separate run-bound audit, including unchanged PCF and clocks.
    for p in sorted((ROOT/'experiments/pnr_reuse/runs').glob('*/native_audit.json')):
        v=json.loads(p.read_text())
        if v.get('passed') and v.get('source_sha256')==hashes:
            native={'path':str(p.relative_to(ROOT)),'sha256':sha(p),'timing':v['timing'],'io':v['io']}
    result=dict(software_verified=not missing,native_verified=native is not None,board_verified=False,
                release_qualified=False,hardware_accessed=False,source_sha256=hashes,proofs=proofs,
                missing_software_checks=missing,native=native,
                remaining_hardware='Independent real-camera calibration, board video/mode switching and physical end-to-end latency have not been measured.')
    (candidate/'validation_summary.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['software_verified','native_verified','board_verified','missing_software_checks']},indent=2))


if __name__=='__main__':main()
