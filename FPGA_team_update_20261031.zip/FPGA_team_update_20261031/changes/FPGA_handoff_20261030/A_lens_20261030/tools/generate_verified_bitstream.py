"""Prepare, or explicitly run, bitstream generation from an audited project clone."""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import math
import re
import sys
import uuid

sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
import vm_exec
from audit_native import timing_rows
from audit_portable_native import io_check

REFERENCE=ROOT/'tests/native_reference'
REFERENCE_FDC=ROOT/'candidate_host_angle_v2_product_stage/sources/board_ddr.fdc'
TOP='video_correct_ddr_top'
CLOCKS={'sys_clk_27m':37.037037,'rx_pixel':6.734007,'cfg_clock':100.,'processing_clock':10.774410,
        'pixel_clock':13.468013,'tx_pixel':13.468013,'ref_clk':8.,'rst_clk':8.,'ddrphy_sysclk':8.,
        'phy_dq_clk_0':1.,'phy_dq_clk_1':1.,'phy_dq_sysclk_0':8.,'phy_dq_sysclk_1':8.}


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read_json(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def write_json(path,data):Path(path).write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
def require(condition,message):
    if not condition:raise ValueError(message)


def source_hashes(directory):
    return {p.name:sha(p) for p in sorted(Path(directory).iterdir()) if p.is_file()}


def windows(path):
    return 'C:/Mac/Home/'+Path(path).resolve().relative_to(Path.home()).as_posix()


def validate_native_build(build):
    build=Path(build).resolve()
    audit_path=build/'native_audit.json'
    audit=read_json(audit_path)
    require(audit.get('passed') is True,'Native audit must pass before preparing firmware')
    require(audit.get('hardware_accessed') is False and not audit.get('failures'),'Native audit has failures or unbound hardware scope')
    timing=audit.get('timing',{});io=audit.get('io',{})
    require(timing.get('passed') is True and timing.get('row_count')==104,'Native audit must cover all104 timing rows')
    margin=timing.get('minimum_slack_ns',-1)
    require(isinstance(margin,(int,float)) and math.isfinite(margin) and margin>=0,'Native timing margin is not nonnegative')
    require(io.get('passed') is True and io.get('pad_count')==144,'Native audit must pass exact144 IO')
    report=build/f'report_timing/{TOP}.rtr'
    require(sha(report)==timing.get('report_sha256'),'Native timing report changed after audit')
    text=report.read_text(errors='replace')
    rows=timing_rows(text,require_pass=True)
    reference=timing_rows((REFERENCE/f'{TOP}.rtr').read_text(errors='replace'),require_pass=False)
    keys=lambda rr:{(r['kind'],r['corner'],tuple(r['clocks'])) for r in rr}
    require(len(rows)==104 and keys(rows)==keys(reference),'Live timing-clock/corner coverage differs')
    for name,period in CLOCKS.items():
        match=re.search(r'(?m)^\s*'+re.escape(name)+r'\s+([0-9.]+)\s+\{',text)
        require(match is not None and abs(float(match[1])-period)<=.00051,'Live clock period differs: '+name)
    live_io=io_check(build/f'place_route/{TOP}.prr',build/f'place_route/{TOP}_prr.prt')
    require(live_io['report_sha256']==io.get('report_sha256') and live_io['pinout_sha256']==io.get('pinout_sha256'),'Live IO reports changed after audit')
    input_path=build/'offline_build_inputs.json'
    inputs=read_json(input_path)
    require(audit.get('native_inputs_sha256')==sha(input_path),'Native audit/input binding changed')
    require(inputs.get('status')=='completed' and inputs.get('returncode')==0 and inputs.get('sources_unchanged') is True,'Original native build did not complete against frozen sources')
    require(inputs.get('hardware_accessed') is False and inputs.get('firmware_generation_requested') is False,'Original job is not the expected build-only job')
    require(inputs.get('io_and_timing_constraints_unchanged') is True,'Original IO/timing constraints were not preserved')
    candidate=Path(inputs['candidate']).resolve()
    require(candidate==build.parents[1],'Build does not belong to its recorded candidate')
    actual=source_hashes(candidate/'sources')
    require(len(actual)==151 and actual==inputs.get('source_sha256'),'Need the exact complete151 source SHA256 bindings')
    manifest=candidate/'project/source_manifest.json'
    script=candidate/'project/build_full.tcl'
    require(sha(manifest)==inputs.get('manifest_sha256')==audit.get('source_manifest_sha256'),'Native source manifest changed')
    require(read_json(manifest).get('source_sha256')==actual,'Source manifest inventory differs')
    require(sha(script)==inputs.get('build_tcl_sha256'),'Native build Tcl changed')
    require((candidate/'sources/board_ddr.fdc').read_bytes()==REFERENCE_FDC.read_bytes(),'Original board constraints changed')
    vm_path=inputs['vm_local_build'].replace('\\','/')
    require(re.fullmatch(r'C:/Temp/FPGA_opt/[A-Za-z0-9_-]+/build',vm_path) is not None,'Unexpected VM job/build location')
    require(vm_path+f'/place_route/{TOP}_pnr.adf' in text.replace('\\','/'),'Final STA report did not read this native PNR DB')
    require(inputs.get('reports',{}).get(f'report_timing/{TOP}.rtr')==sha(report),'Original input record does not bind the current RTR')
    vm_path_local=build/'vm_source_verification.json'
    vm=read_json(vm_path_local)
    require(vm.get('passed') is True and vm.get('stage')=='before_and_after_build' and vm.get('source_count')==151 and
            vm.get('hardware_accessed') is False and vm.get('source_sha256')==actual and
            vm.get('manifest_sha256')==inputs['manifest_sha256'] and vm.get('build_tcl_sha256')==inputs['build_tcl_sha256'],
            'VM sources were not verified before and after the native build')
    bound=[audit_path,input_path,vm_path_local,report,build/f'place_route/{TOP}.prr',build/f'place_route/{TOP}_prr.prt',manifest,script]
    return dict(build=str(build),candidate=str(candidate),source_sha256=actual,
                native_audit_sha256=sha(audit_path),vm_original_build=vm_path,
                manifest_sha256=inputs['manifest_sha256'],build_tcl_sha256=inputs['build_tcl_sha256'],
                rtr_sha256=sha(report),bound_files_sha256={str(p):sha(p) for p in bound})


def forbidden_action(text):
    if re.search(r'(?im)^\s*Executing\s*:\s*(compile|synthesize|dev_map|pnr)\b',text):return True
    for name in re.findall(r'(?im)^\s*Process\s+"([^"]+)"\s+started',text):
        if re.sub('[^a-z]','',name.lower())!='generatebitstream':return True
    return False


PS_TEMPLATE=r'''
$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new()
$shared=@SHARED@
$config=Get-Content "$shared/request.json" -Raw | ConvertFrom-Json
$original=$config.vm_original_build
$clone=$config.vm_clone_build
$tool='C:/pango/PDS_2022.2-SP6.4/bin/pds_shell.exe'
$firmwareExtensions=@('.sbit','.bit','.bin')
$proc=$null
$exitCode=$null
$errorMessage=$null
$success=$false
$originalBefore=$null
$originalPnrBefore=$null
$clonePnrBefore=$null
$originalPnrAfter=$null
$clonePnrAfter=$null
$files=[ordered]@{}
$logFiles=[ordered]@{}
function Convert-Map($value) {
 $result=[ordered]@{}
 foreach($entry in $value.PSObject.Properties){$result[$entry.Name]=[string]$entry.Value}
 return $result
}
$expectedSources=Convert-Map $config.source_sha256
function Get-HashTree([string]$directory,[string]$filter='*') {
 $result=[ordered]@{}
 $base=(Get-Item -LiteralPath $directory).FullName
 Get-ChildItem -LiteralPath $directory -Recurse -File -Filter $filter | Sort-Object FullName | ForEach-Object {
  $name=$_.FullName.Substring($base.Length+1).Replace([char]92,'/')
  $result[$name]=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
 }
 return $result
}
function Assert-EqualMaps($actual,$expected,[string]$label) {
 if($actual.Count -ne $expected.Count){throw "$label inventory changed"}
 foreach($key in $expected.Keys){if($actual[$key] -cne $expected[$key]){throw "$label changed: $key"}}
}
function Assert-BoundEvidence {
 foreach($entry in $config.bound_files_vm_sha256.PSObject.Properties) {
  if((Get-FileHash -LiteralPath $entry.Name -Algorithm SHA256).Hash.ToLowerInvariant() -cne $entry.Value){throw "Audited evidence changed: $($entry.Name)"}
 }
 $rtr=Join-Path $original 'report_timing/video_correct_ddr_top.rtr'
 if((Get-FileHash -LiteralPath $rtr -Algorithm SHA256).Hash.ToLowerInvariant() -cne $config.rtr_sha256){throw 'VM RTR differs from the audited report'}
}
function Assert-SourceInputs {
 foreach($directory in @($config.vm_sources,$config.host_sources)) {
  $actual=[ordered]@{}
  Get-ChildItem -LiteralPath $directory -File | ForEach-Object {$actual[$_.Name]=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()}
  if($actual.Count -ne 151){throw 'Need exactly151 staged sources'}
  Assert-EqualMaps $actual $expectedSources '151 source SHA256'
 }
 foreach($entry in @(@{name='source_manifest.json';hash=$config.manifest_sha256},@{name='build_full.tcl';hash=$config.build_tcl_sha256})) {
  if((Get-FileHash -LiteralPath (Join-Path $config.vm_project $entry.name) -Algorithm SHA256).Hash.ToLowerInvariant() -cne $entry.hash){throw "Staged project changed: $($entry.name)"}
 }
}
function Assert-NoFirmware([string]$directory) {
 $existing=@(Get-ChildItem -LiteralPath $directory -Recurse -File | Where-Object {$_.Extension -in $firmwareExtensions})
 if($existing.Count){throw 'Refusing original/clone build with preexisting bitstream output'}
}
function Assert-OriginalUnchanged {
 Assert-EqualMaps (Get-HashTree $original) $originalBefore 'Original native build'
 Assert-EqualMaps (Get-HashTree $original '*_pnr.adf') $originalPnrBefore 'Original PNR DB'
 Assert-EqualMaps (Get-HashTree $clone '*_pnr.adf') $clonePnrBefore 'Cloned PNR DB'
 Assert-SourceInputs
 Assert-BoundEvidence
}
function Test-ForbiddenAction([string]$text) {
 if($text -match '(?im)^\s*Executing\s*:\s*(compile|synthesize|dev_map|pnr)\b'){return $true}
 foreach($match in [regex]::Matches($text,'(?im)^\s*Process\s+"([^"]+)"\s+started')) {
  if(($match.Groups[1].Value.ToLowerInvariant() -replace '[^a-z]','') -cne 'generatebitstream'){return $true}
 }
 return $false
}
function Stop-CloneTree {
 if($null -ne $proc) {
  $proc.Refresh()
  if(!$proc.HasExited){& "$env:SystemRoot/System32/taskkill.exe" /PID $proc.Id /T /F | Out-Null}
 }
}
function Get-CurrentLog {
 $text=''
 foreach($name in @('firmware_tool.log','firmware_tool.err')) {
  $path=Join-Path $clone $name
  if(Test-Path -LiteralPath $path){$text+=Get-Content -LiteralPath $path -Raw -ErrorAction SilentlyContinue}
 }
 return $text
}
try {
 Assert-BoundEvidence
 Assert-SourceInputs
 Assert-NoFirmware $original
 if(Test-Path -LiteralPath $clone){throw 'Firmware clone already exists; refusing stale generation'}
 $originalBefore=Get-HashTree $original
 $originalPnrBefore=Get-HashTree $original '*_pnr.adf'
 if(!$originalPnrBefore.Contains('place_route/video_correct_ddr_top_pnr.adf')){throw 'Audited native PNR DB is missing'}
 $projects=@(Get-ChildItem -LiteralPath $original -File -Filter '*.pds')
 if($projects.Count -ne 1){throw 'Need one unambiguous original PDS project'}
 $projectText=Get-Content -LiteralPath $projects[0].FullName -Raw
 foreach($option in @('prj_work_dir','prj_impl_dir')) {
  if($projectText -notmatch ('\(_option\s+'+$option+'\s+\(_string\s+"\."\)')){throw 'PDS working/implementation directory is not proven relative'}
 }
 foreach($command in @('cmd_compile','cmd_synthesize','cmd_devmap','cmd_pnr','cmd_report_post_pnr_timing')) {
  $pattern='\(_command\s+'+$command+'\s+\(_gci_state\s+\(_integer\s+2\)\)' 
  if($projectText -notmatch $pattern){throw "Audited PDS predecessor is not completed: $command"}
 }
 $normalized=$projectText.Replace([char]92,'/')
 if($normalized.IndexOf($original,[StringComparison]::OrdinalIgnoreCase) -ge 0){throw 'PDS retains an absolute original-build path; isolated generation is not proven'}
 Copy-Item -LiteralPath $original -Destination $clone -Recurse
 Assert-EqualMaps (Get-HashTree $clone) $originalBefore 'Complete native build clone'
 Assert-NoFirmware $clone
 $clonePnrBefore=Get-HashTree $clone '*_pnr.adf'
 Assert-EqualMaps $clonePnrBefore $originalPnrBefore 'Cloned PNR DB'
 $project=Join-Path $clone $projects[0].Name
 $proc=Start-Process -FilePath $tool -WorkingDirectory $clone -ArgumentList @('-project',$project,'-run','gen_bit_stream') -PassThru -NoNewWindow -RedirectStandardOutput "$clone/firmware_tool.log" -RedirectStandardError "$clone/firmware_tool.err"
 $null=$proc.Handle
 @{status='running';pid=$proc.Id;hardware_accessed=$false;clone=$clone} | ConvertTo-Json | Set-Content "$shared/vm_status.json" -Encoding UTF8
 $deadline=[DateTime]::UtcNow.AddMinutes(30)
 while(!$proc.WaitForExit(250)) {
  if(Test-ForbiddenAction (Get-CurrentLog)){Stop-CloneTree;throw 'PDS scheduled a forbidden upstream/non-bitstream action'}
  if([DateTime]::UtcNow -gt $deadline){Stop-CloneTree;throw 'Bitstream generation timed out'}
 }
 $proc.WaitForExit()
 $proc.Refresh()
 if($null -eq $proc.ExitCode){throw 'Native exit code is unavailable'}
 $exitCode=[int]$proc.ExitCode
 $text=Get-CurrentLog
 if(Test-ForbiddenAction $text){Stop-CloneTree;throw 'PDS scheduled a forbidden upstream/non-bitstream action'}
 if($exitCode -ne 0 -or $text -match '(?im)^\s*E:'){throw 'PDS bitstream action failed'}
 Assert-OriginalUnchanged
 $generated=@(Get-ChildItem -LiteralPath $clone -Recurse -File | Where-Object {$_.Extension -in $firmwareExtensions})
 if(!$generated.Count){throw 'PDS produced no new firmware output'}
 foreach($file in $generated) {
  if($file.Length -le 0){throw "Empty generated firmware: $($file.Name)"}
  if($files.Contains($file.Name)){throw 'Generated firmware basenames collide'}
  $files[$file.Name]=(Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
 }
 Assert-SourceInputs
 Assert-BoundEvidence
 foreach($file in $generated) {
  $target=Join-Path $shared $file.Name
  if(Test-Path -LiteralPath $target){throw 'Refusing to overwrite local firmware'}
  Copy-Item -LiteralPath $file.FullName -Destination $target
  if((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -cne $files[$file.Name]){throw 'Copied firmware hash mismatch'}
 }
 Assert-OriginalUnchanged
 $success=$true
} catch {
 $errorMessage=$_.Exception.Message
 Stop-CloneTree
} finally {
 try {
  if($null -ne $originalPnrBefore){$originalPnrAfter=Get-HashTree $original '*_pnr.adf'}
  if($null -ne $clonePnrBefore){$clonePnrAfter=Get-HashTree $clone '*_pnr.adf'}
  if($success) {
   Assert-EqualMaps $originalPnrAfter $originalPnrBefore 'Final original PNR DB'
   Assert-EqualMaps $clonePnrAfter $clonePnrBefore 'Final cloned PNR DB'
  }
 } catch {
  $success=$false
  $errorMessage='Final DB hash verification failed: '+$_.Exception.Message
 }
 if(Test-Path -LiteralPath $clone) {
  Get-ChildItem -LiteralPath $clone -Recurse -File -Filter '*.log' | ForEach-Object {
   $relative=$_.FullName.Substring((Get-Item -LiteralPath $clone).FullName.Length+1).Replace([char]92,'/')
   $hash=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
   if($null -eq $originalBefore -or !$originalBefore.Contains($relative) -or $hash -cne $originalBefore[$relative]) {
    $target=Join-Path "$shared/logs" $relative
    New-Item -ItemType Directory -Force (Split-Path $target) | Out-Null
    Copy-Item -LiteralPath $_.FullName -Destination $target
    $logFiles[$relative]=$hash
   }
  }
  if(Test-Path -LiteralPath "$clone/firmware_tool.err") {
   New-Item -ItemType Directory -Force "$shared/logs" | Out-Null
   Copy-Item -LiteralPath "$clone/firmware_tool.err" -Destination "$shared/logs/firmware_tool.err"
  }
 }
 $mainHash=$null
 if($null -ne $originalPnrBefore){$mainHash=$originalPnrBefore['place_route/video_correct_ddr_top_pnr.adf']}
 @{passed=$success;status=if($success){'completed'}else{'failed'};returncode=$exitCode;error=$errorMessage;
   hardware_accessed=$false;clone=$clone;pnr_db_sha256=$mainHash;pnr_db_sha256_all=$originalPnrBefore;
   pnr_db_evidence=@{original_before=$originalPnrBefore;clone_before=$clonePnrBefore;original_after=$originalPnrAfter;clone_after=$clonePnrAfter};
   files=$files;logs=$logFiles;source_sha256=$config.source_sha256;native_audit_sha256=$config.native_audit_sha256;
   original_and_clone_pnr_unchanged=$success;original_build_unchanged=$success;sources_unchanged=$success} |
   ConvertTo-Json -Depth 12 | Set-Content "$shared/vm_result.json" -Encoding UTF8
}
if(!$success){exit 1}
exit 0
'''


def powershell(config):
    return PS_TEMPLATE.replace('@SHARED@',"'"+config['shared'].replace("'","''")+"'")


def prepare(build,gate):
    build=Path(build).resolve();out=build/'firmware_verified'
    if out.exists():
        old=read_json(out/'request.json')
        require(read_json(out/'verification.json').get('status')=='prepared_only','Firmware attempt already ran; preserve it instead of reusing the directory')
        require(old.get('bound_files_sha256')==gate['bound_files_sha256'] and old.get('source_sha256')==gate['source_sha256'],'Prepared evidence no longer matches the native build')
        require(old.get('driver_sha256')==sha(Path(__file__)) and old.get('script_sha256')==sha(out/'run_vm.ps1'),'Prepared driver or script changed')
        return out
    out.mkdir()
    run_id=datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:6]
    parent=gate['vm_original_build'].rsplit('/',1)[0]
    config=dict(gate,shared=windows(out),vm_clone_build=parent+'/firmware_build_'+run_id,
                vm_sources=parent+'/candidate/sources',vm_project=parent+'/candidate/project',
                host_sources=windows(Path(gate['candidate'])/'sources'),driver_sha256=sha(Path(__file__)),
                bound_files_vm_sha256={windows(Path(path)):value for path,value in gate['bound_files_sha256'].items()})
    (out/'run_vm.ps1').write_text(powershell(config))
    config['script_sha256']=sha(out/'run_vm.ps1')
    write_json(out/'request.json',config)
    write_json(out/'verification.json',dict(passed=False,status='prepared_only',hardware_accessed=False,
               source_sha256=gate['source_sha256'],native_audit_sha256=gate['native_audit_sha256'],
               pnr_db_sha256=None,files={}))
    return out


def execute(out):
    out=Path(out)
    config=read_json(out/'request.json')
    current=validate_native_build(Path(config['build']))
    require(current['bound_files_sha256']==config['bound_files_sha256'] and current['source_sha256']==config['source_sha256'],'Native inputs changed before explicit run')
    require(sha(out/'run_vm.ps1')==config['script_sha256'] and sha(Path(__file__))==config['driver_sha256'],'Prepared generation script changed')
    require(read_json(out/'verification.json').get('status')=='prepared_only','Only a never-run prepared attempt may generate firmware')
    write_json(out/'verification.json',dict(passed=False,status='running',hardware_accessed=False,
               source_sha256=config['source_sha256'],native_audit_sha256=config['native_audit_sha256'],pnr_db_sha256=None,files={}))
    errors=[];result={};code=None
    try:
        code=vm_exec.run_file(windows(out/'run_vm.ps1'),timeout=2100)
        result=read_json(out/'vm_result.json')
        after=validate_native_build(Path(config['build']))
        require(after['bound_files_sha256']==config['bound_files_sha256'] and after['source_sha256']==config['source_sha256'],'Native evidence/sources changed during firmware generation')
        require(code==0 and result.get('passed') is True and result.get('returncode')==0,'Generation failed: '+str(result.get('error')))
        require(result.get('hardware_accessed') is False and result.get('source_sha256')==config['source_sha256'] and
                result.get('native_audit_sha256')==config['native_audit_sha256'],'VM generation lost source/audit binding')
        require(result.get('original_and_clone_pnr_unchanged') is True and result.get('original_build_unchanged') is True and
                result.get('sources_unchanged') is True,'Original build, clone PNR DB or sources changed')
        require(re.fullmatch('[0-9a-f]{64}',result.get('pnr_db_sha256') or '') is not None,'PNR DB hash unavailable')
        db_evidence=result.get('pnr_db_evidence',{})
        original_db=db_evidence.get('original_before',{})
        require(bool(original_db) and all(db_evidence.get(key)==original_db for key in
                ['clone_before','original_after','clone_after']),'Original/clone recursive PNR DB hashes changed')
        require(original_db.get(f'place_route/{TOP}_pnr.adf')==result['pnr_db_sha256'] and
                result.get('pnr_db_sha256_all')==original_db,'Main and recursive PNR DB bindings differ')
        files=result.get('files',{})
        require(bool(files),'No generated firmware was collected')
        for name,expected in files.items():
            require(Path(name).name==name and Path(name).suffix.lower() in ('.sbit','.bit','.bin'),'Unexpected firmware filename')
            require((out/name).is_file() and (out/name).stat().st_size>0 and sha(out/name)==expected,'Collected firmware is empty or changed: '+name)
    except Exception as error:
        errors.append(str(error))
    verification=dict(passed=not errors,status='completed' if not errors else 'failed',hardware_accessed=False,
                      source_sha256=config['source_sha256'],native_audit_sha256=config['native_audit_sha256'],
                      pnr_db_sha256=result.get('pnr_db_sha256'),pnr_db_sha256_all=result.get('pnr_db_sha256_all'),
                      pnr_db_evidence=result.get('pnr_db_evidence',{}),
                      files=result.get('files',{}),logs=result.get('logs',{}),vm_returncode=code,errors=errors,
                      original_and_clone_pnr_unchanged=result.get('original_and_clone_pnr_unchanged',False),
                      original_build_unchanged=result.get('original_build_unchanged',False),
                      sources_unchanged=result.get('sources_unchanged',False),vm_clone_build=config['vm_clone_build'])
    write_json(out/'verification.json',verification)
    return verification


def main(argv=None):
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--native-build',type=Path,required=True)
    ap.add_argument('--run',action='store_true')
    args=ap.parse_args(argv)
    gate=validate_native_build(args.native_build)
    out=prepare(args.native_build,gate)
    if args.run:
        result=execute(out)
        print(json.dumps(dict(directory=str(out),passed=result['passed'],files=result['files'],errors=result['errors']),indent=2))
        return 0 if result['passed'] else 1
    print(json.dumps(dict(directory=str(out),status='prepared_only',firmware_generated=False,hardware_accessed=False),indent=2))
    return 0


if __name__=='__main__':
    try:raise SystemExit(main())
    except (ValueError,KeyError,FileNotFoundError) as error:
        print('BITSTREAM_REFUSED: '+str(error),file=sys.stderr)
        raise SystemExit(2)
