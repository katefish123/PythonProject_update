@echo off
cd /d "%~dp0results\hardware_20261009\thermal_adc_watch"
start "" "C:\pango\PDS_2022.2-SP6.4\bin\cdt_dbg.exe"
