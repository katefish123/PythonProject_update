# FPGA 视频矫正集成工程

2026-10-10：**按用户要求保存并暂停**。相机直连采集卡已在OBS显示取景；独立板卡诊断实测收到1920×1080有效像素，RX/TX配置均完成、无通信错误。当前板上是临时状态诊断程序，显示带状态标记的彩条。接收优先直通对照已构建，尚未下载且仿真入口还需修复；真实相机透视校正未验收。当前依据见 [暂停记录](docs/暂停记录_20261010.md)，成果另归档于 `release/hdmi_bringup_paused_20261010`。

2026-10-09：**工程已进入实体上板联调**。DDR初始化和保留区读写自检通过，板内测试图经过真实DDR、四色检测、透视校正、双线性插值和HDMI输出后，与参考图位置对齐；原生MJPEG采集的99.731%像素最大RGB误差不超过4。启动重试修正版已构建、临时下载并回读验证成功。相机实拍与长期运行尚待验收。

工程位于 `C:\D\FPGA\video_correct_integrated_20261008`。A、B 的原材料保留；C 本地仓库按用户要求更新到 `main-C / 1ba75f5130efed3719c99c1ff9dcc3046dd0f69d`，更新后的93个文件复制至 `vendor/c_current`，旧快照仍在 `vendor/c`。原材料哈希与本次编译源码哈希均有记录。

## 当前DDR版本

输入1920×1080 RGB888，采样为640×480完整源帧，使用B的四色检测、透视映射与插值生成320×452结果。源图和两个结果区域存入实际DDR3；显示预取到双行缓冲，以1080p60扫描。新结果尚未完成时重复上一完整结果。

144,640个输出像素的实际参数仿真全部匹配参考模型；四个异步时钟的整机仿真验证了完整源回读、结果发布顺序、显示像素、坏帧保持和共同复位恢复。启动修正版PDS `All Constraints Met`，像素域setup余量2.059 ns、HDMI输出2.129 ns、DDR UI 2.231 ns；这些是厂商PHY和当前HDMI IO模型下的工具结果。

- 详细设计与接线说明：[DDR工程说明](docs/DDR工程说明.md)。
- 当前板顶：`rtl/top/video_correct_ddr_top.v`；重建时指定新输出目录：`scripts/build_ddr_board.ps1 -OutputName board_ddr_startup_fixed_20261009`；PDS项目在 `results/board_ddr_startup_fixed_20261009`。
- 最新下载文件：`release/ddr_startup_fixed_20261009/video_correct_ddr_top.sbit`，同目录有匹配smsk、SHA256清单、约束、时序、资源报告和源码快照ZIP。上一版在 `release/ddr_integrated_20261009` 保留。
- 启动修正：TX先初始化，I²C复位后等待10ms；允许初始scratch探测重试，探测成功后的配置NACK仍阻止处理。细节和测试记录在 `docs/hdmi_startup_fix_20261009.md`。
- 测试回放图片：`results/ddr_fixture/hdmi_replay_1920x1080.png`；期望图：`results/ddr_fixture/expected_320x452.png`。

DDR地址按32位word计，一次256位搬运8个像素，地址步长8。DDR bank映射、参考时钟N3/N2、CA/DQ时钟关系和颗粒等待时间已经核对；tFAW使用26 CK/52 ns，物理CL7/CWL6。软件验证和码流归档索引在 `docs/ddr_stage_verification.json`。

当前用OBS显示VC-002Pro真实采集卡，网页自动采集已停止。`http://127.0.0.1:8766/target` 是可全屏的静态相机测试图。佳能R50输入报告为1080p59.94Hz；2026-10-10诊断已实测收到1920×1080有效像素和HS/VS，但直通画面仍待恢复。下一步按暂停记录先完成接收优先对照，再做四色测试图实拍、复位和持续运行检查。HDMI 60 Hz是扫描刷新率，算法结果更新率还要实测。

## 保留的BRAM验证版

HDMI RGB888 输入先采集完整源帧，再做四色检测、求透视参数、取四邻域像素、插值并写完整结果。计算期间源快照保持不变；完成后仅在显示帧边界换图；坏帧继续显示上一张完整结果。处理与扫描使用不同的时钟。

|配置|当前验证版|
|---|---|
|板卡/主控|MES2L676-100HP / PG2L100H-6 FBG676|
|HDMI输入|1920×1080 RGB888，1080p60基线|
|算法源快照|320×180，横纵每6像素取1个|
|矫正结果|160×226，RGB888|
|HDMI输出|1920×1080，148.5 MHz，标称60 Hz|
|显示窗口|640×904，最近邻4倍放大，左上角(640,88)，外侧填黑|
|处理/配置时钟|板载27 MHz / PLL 10 MHz|
|显示读取延迟|显示模块2拍，再经板顶1拍；RGB/HS/VS/DE共3拍对齐|
|源/目的存储|1个源BRAM快照；2个目的BRAM缓存|
|源帧归属|处理结束前锁定；期间丢弃其他输入帧|
|结果显示|新帧未完成时重复上一完整帧|

第一张有效结果出现前显示彩条。KEY0复位；按住KEY1显示彩条；按住KEY2选择最近邻采样，松开使用双线性（在开始处理一帧时采样该设置）。

LED0为处理时钟心跳，LED1为RX控制器初始化完成，LED2为TX控制器初始化完成，LED3表示已有完整结果，LED4表示帧处理/检测拒绝，LED5表示等待输入超时，LED6表示探测成功后的I²C配置/通信错误，LED7表示两路PLL已锁定。以上为工作源码的BRAM顶层映射，历史BRAM发布码流保持原状。初始化指示不等同于真实HDMI链路已通过验收。

## 已保存的验证

- B 原算法8项本机 ModelSim 测试通过；缓存可变延迟、读写等待、复位取消均有测试。
- 三个异步时钟的整合仿真通过：双线性/最近邻显示逐像素匹配；源快照保护、活动显示bank保护、坏帧保持和复位恢复通过。
- 实际上板参数的36,160个输出像素全部匹配参考模型。一次算法处理共1,454,008个27 MHz周期，理论时间53.852 ms；未把这个数当作实测整机帧率。
- 真实HDMI配置模块/I²C器件模型通过正常事务、开漏和无器件测试。SDA只拉低或释放，ACK错误有独立指示；共享总线在事务结束后交接。
- 最终 PDS 报告 `All Constraints Met`。像素域建立余量2.350 ns，HDMI输出路径2.067 ns；使用6740 LUT、8291 FF、53 APM、145/155 DRM、71 IO。

外部HDMI延迟采用C交接的初步模型，走线偏差与实体芯片采样关系仍需上板检查。I²C驱动保留原参考的SCL行为，尚未验证clock stretching和实体故障恢复。DDR IP虽已针对本板生成，但未接入当前顶层；尚未完成PHY实测校准、DDR帧缓存与原定分辨率/吞吐验证。当前电脑未接下载器，未烧录此工程。

## 本机重建与日志

在本工程目录运行 `scripts/build_board.ps1`。PDS项目保存在 `results/board_bram_final/video_correct_bram.pds`，顶层为 `rtl/top/video_correct_board_top.v`。板卡约束在 `constr/board_bram.fdc`。脚本使用当前机器安装的PDS与ModelSim路径。

测试入口：`scripts/qualify_b.py`、`scripts/run_integration.py`、`scripts/run_video_tests.ps1`、`scripts/run_core_tests.ps1`、`scripts/run_board_frame.ps1`；HDMI配置测试入口为 `sim/run_hdmi_config.do`。测试脚本检查仿真通过信号，不以日志出现PASS文字作为唯一依据。

最新下载文件及配套掩码位于 `release/bram_bringup_20261009`。该目录含源码/码流SHA256、时序报告、资源报告和约束副本。以该目录为本次归档版本，不使用早期 `results/board_bram` 的试构建产物。

## 下一次接续

先将板子上电并连接本机USB/JTAG，核对设备与码流，进行当前DDR版的临时下载和真实画面测试。必要时可使用已保留的BRAM版本作对照。实际连接应经过“输入设备→FPGA HDMI IN→FPGA HDMI OUT→显示设备/采集卡”。

DDR事务适配、像素缓存、输入跨域搬运和显示预取已经接入。详细接续记录见 `docs/继续工作.md`，DDR接口约定见 `docs/ddr_ip_notes.md`。不需要重新拉取或重做已通过的测试；有新改动时仅检查受影响部分。
