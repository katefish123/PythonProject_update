onerror {quit -f -code 1}
transcript file pixels.log
if {![file isdirectory work_pixels]} {vlib work_pixels}
vmap work_pixels work_pixels
vlog -sv -work work_pixels hdmi_camera_passthrough_rx_first_top.v {C:/D/FPGA/video_correct_integrated_20261008/rtl/common/reset_sync.v} {C:/D/FPGA/video_correct_integrated_20261008/vendor/c_current/01_design_code/hdmi_vs_recover.v} tb_rx_first_pixels.sv
vsim -c -voptargs=+acc -wlf pixels.wlf work_pixels.tb_hdmi_camera_native
run -all
quit -f -code 0
