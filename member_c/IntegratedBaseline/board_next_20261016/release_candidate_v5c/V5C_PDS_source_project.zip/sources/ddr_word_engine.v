`timescale 1ns/1ps
`default_nettype none

// Single-outstanding word/burst adapter for the PG2L100H DDR IP.
// cmd_source_block explicitly requests a safe aligned 64-word source block.
// rsp_source_block packs beat0 in bits255:0 through beat7 in bits2047:1792.
// Addresses are 32-bit word addresses; one beat covers eight words.
module ddr_word_engine #(
    parameter integer WATCHDOG_CYCLES = 1024,
    parameter integer CAPTURE_BURST_BEATS=1,
    parameter integer READ_AHEAD_ENABLE = 0,
    parameter integer SOURCE_PREFETCH_ENABLE = 0,
    parameter integer SOURCE_WORDS = 1920*1080,
    parameter [27:0] SOURCE_BASE0 = 28'd0,
    parameter [27:0] SOURCE_BASE1 = 28'h0800000,
    parameter integer RESULT_WORDS = 640*904,
    parameter [27:0] RESULT_BASE0 = 28'h0100000,
    parameter [27:0] RESULT_BASE1 = 28'h0200000
) (
    input  wire          clk,
    input  wire          rst_n,
    input  wire          init_done,

    input  wire          cmd_valid,
    output wire          cmd_ready,
    input  wire          cmd_write,
    input wire cmd_source_block,
    input  wire [27:0]   cmd_addr,
    input  wire [255:0]  cmd_wdata,
    input  wire [31:0]   cmd_wstrb,
    input wire [2047:0] capture_burst_data,

    output wire          rsp_valid,
    output reg           rsp_write,
    output reg  [255:0]  rsp_rdata,
    output reg [2047:0] rsp_source_block,
    output reg           fault,
    output reg [3:0] fault_reason,

    output wire [27:0]   axi_awaddr,
    output wire          axi_awuser_ap,
    output wire [3:0]    axi_awuser_id,
    output wire [3:0]    axi_awlen,
    output wire          axi_awvalid,
    input  wire          axi_awready,

    output wire [255:0]  axi_wdata,
    output wire [31:0]   axi_wstrb,
    input  wire          axi_wready,
    input  wire [3:0]    axi_wusero_id,
    input  wire          axi_wusero_last,

    output wire [27:0]   axi_araddr,
    output wire          axi_aruser_ap,
    output wire [3:0]    axi_aruser_id,
    output wire [3:0]    axi_arlen,
    output wire          axi_arvalid,
    input  wire          axi_arready,

    input  wire [255:0]  axi_rdata,
    input  wire [3:0]    axi_rid,
    input  wire          axi_rlast,
    input  wire          axi_rvalid
);

    localparam [2:0] ST_IDLE = 3'd0;
    localparam [2:0] ST_AW   = 3'd1;
    localparam [2:0] ST_W    = 3'd2;
    localparam [2:0] ST_AR   = 3'd3;
    localparam [2:0] ST_R    = 3'd4;
    localparam [2:0] ST_RSP  = 3'd5;

    reg [2:0] state;
    reg [27:0] addr_hold;
    reg [255:0] wdata_hold;
    reg [31:0] wstrb_hold;
    reg [31:0] watchdog_count;
    reg write_burst;
    reg [3:0] write_index;
    reg [2047:0] write_buffer;
    wire source_write=cmd_write &&
        ((cmd_addr>=SOURCE_BASE0 && cmd_addr<SOURCE_BASE0+SOURCE_WORDS) ||
         (cmd_addr>=SOURCE_BASE1 && cmd_addr<SOURCE_BASE1+SOURCE_WORDS));
    wire capture_command=CAPTURE_BURST_BEATS>1 && source_write;
    reg cache_valid,read_burst;
    reg [21:0] cache_tag;
    reg [2:0] read_index;
    reg [255:0] result_cache[0:7];
    wire [27:0] request_block={cmd_addr[27:6],6'b0};
    wire force_source_block=(cmd_source_block === 1'b1);
    wire result_read=READ_AHEAD_ENABLE && !force_source_block && !cmd_write &&
        ((request_block>=RESULT_BASE0 && request_block+28'd63<RESULT_BASE0+RESULT_WORDS) ||
         (request_block>=RESULT_BASE1 && request_block+28'd63<RESULT_BASE1+RESULT_WORDS));
    reg source_cache_valid,read_source,source_next_valid;
    reg [21:0] source_cache_tag;
    reg [27:0] source_next_addr;
    reg [255:0] source_cache[0:7];
    wire source_read=(SOURCE_PREFETCH_ENABLE || force_source_block) && !cmd_write &&
        ((cmd_addr>=SOURCE_BASE0 && cmd_addr<SOURCE_BASE0+SOURCE_WORDS) ||
         (cmd_addr>=SOURCE_BASE1 && cmd_addr<SOURCE_BASE1+SOURCE_WORDS));
    wire source_block_safe=
        ((request_block>=SOURCE_BASE0 && request_block+28'd63<SOURCE_BASE0+SOURCE_WORDS) ||
         (request_block>=SOURCE_BASE1 && request_block+28'd63<SOURCE_BASE1+SOURCE_WORDS));
    wire source_prefetch=source_read && source_block_safe &&
        (force_source_block || cmd_addr==SOURCE_BASE0 || cmd_addr==SOURCE_BASE1 ||
         (source_next_valid && cmd_addr==source_next_addr));
    wire source_hit=source_read && source_cache_valid && source_cache_tag==cmd_addr[27:6];
    wire result_hit=result_read && cache_valid && cache_tag==cmd_addr[27:6];
    wire cache_hit=result_hit || source_hit;

    // Public clients still receive exactly one response for one accepted command.
    // A cache fill consumes every unbackpressurable IP beat before responding.
    task receive_read;
        begin
            if(read_burst)begin
                if(axi_rid!==4'd0 || axi_rlast!==(read_index==3'd7))begin
                    fault_reason<=3;fault<=1;cache_valid<=0;source_cache_valid<=0;rsp_rdata<=0;rsp_source_block<=0;state<=ST_RSP;
                end else begin
                    if(read_source)source_cache[read_index]<=axi_rdata;
                    else result_cache[read_index]<=axi_rdata;
                    if(read_index==3'd7)begin
                        if(read_source)begin
                            source_cache_tag<=addr_hold[27:6];source_cache_valid<=1;
                            rsp_source_block<={axi_rdata,source_cache[6],source_cache[5],source_cache[4],source_cache[3],source_cache[2],source_cache[1],source_cache[0]};
                        end
                        else begin cache_tag<=addr_hold[27:6];cache_valid<=1;end
                        rsp_rdata<=(addr_hold[5:3]==3'd7) ? axi_rdata :
                            (read_source ? source_cache[addr_hold[5:3]] : result_cache[addr_hold[5:3]]);
                        state<=ST_RSP;
                    end else begin
                        read_index<=read_index+1'b1;watchdog_count<=0;state<=ST_R;
                    end
                end
            end else begin
                rsp_rdata<=axi_rdata;
                if(axi_rid!==4'd0 || axi_rlast!==1'b1)begin fault_reason<=3;fault<=1;cache_valid<=0;source_cache_valid<=0;end
                state<=ST_RSP;
            end
        end
    endtask

    // A sticky protocol/timeout fault is a hard stop until the shared DDR
    // reset flushes both this adapter and the DDR IP's in-flight responses.
    assign cmd_ready = rst_n && init_done && !fault && (state == ST_IDLE);
    assign rsp_valid = rst_n && (state == ST_RSP);

    assign axi_awaddr = addr_hold;
    assign axi_awuser_ap = 1'b0;
    assign axi_awuser_id = 4'b0000;
    assign axi_awlen = write_burst?CAPTURE_BURST_BEATS-1:4'd0;
    assign axi_awvalid = (state == ST_AW);

    // There is no WVALID on this IP. Keep the beat stable from command
    // acceptance through the WREADY consumption edge.
    assign axi_wdata = write_burst?write_buffer[write_index*256+:256]:wdata_hold;
    assign axi_wstrb = wstrb_hold;

    assign axi_araddr = read_burst?{addr_hold[27:6],6'b0}:addr_hold;
    assign axi_aruser_ap = 1'b0;
    assign axi_aruser_id = 4'b0000;
    assign axi_arlen = read_burst?4'd7:4'd0;
    assign axi_arvalid = (state == ST_AR);

    task receive_write;
        begin
            if(axi_wusero_id!==4'd0 || axi_wusero_last!==(write_burst?(write_index==CAPTURE_BURST_BEATS-1):1'b1))begin
                fault_reason<=2;fault<=1;state<=ST_RSP;
            end else if(!write_burst || write_index==CAPTURE_BURST_BEATS-1)begin
                write_burst<=0;state<=ST_RSP;
            end else begin
                write_index<=write_index+1'b1;watchdog_count<=0;state<=ST_W;
            end
        end
    endtask

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= ST_IDLE;write_burst<=0;write_index<=0;write_buffer<=0;fault_reason<=0;
            addr_hold <= 28'd0;
            wdata_hold <= 256'd0;
            wstrb_hold <= 32'd0;
            watchdog_count <= 32'd0;
            rsp_write <= 1'b0;
            rsp_rdata <= 256'd0; rsp_source_block<=0;
            source_cache_valid<=0;source_cache_tag<=0;source_next_valid<=0;source_next_addr<=0;read_source<=0;
            fault <= 1'b0;cache_valid<=0;cache_tag<=0;read_burst<=0;read_index<=0;
        end else begin
            case (state)
                ST_IDLE: begin
                    watchdog_count <= 32'd0;
                    if (cmd_valid && cmd_ready) begin
                        write_burst<=capture_command;write_index<=0;write_buffer<=capture_burst_data;
                        addr_hold <= cmd_addr;
                        wdata_hold <= cmd_wdata;
                        wstrb_hold <= cmd_wstrb;
                        rsp_write <= cmd_write;
                        rsp_rdata <= 256'd0; rsp_source_block<=0;
                        read_burst<=0;read_index<=0;read_source<=0;
                        if(source_read)begin source_next_valid<=1;source_next_addr<=cmd_addr+28'd8;end
                        if(cmd_write && source_cache_valid && source_cache_tag==cmd_addr[27:6])source_cache_valid<=0;
                        if(cmd_write && cache_valid && cache_tag==cmd_addr[27:6])cache_valid<=0;
                        if (cmd_addr[2:0] != 3'b000 || (capture_command && (cmd_addr[5:0]!=0 || !source_block_safe)) ||
                            (force_source_block && (cmd_write || cmd_addr[5:0]!=0 || !source_block_safe))) begin
                            // Misaligned block commands cannot be represented
                            // by one 256-bit beat. Retire with zero data.
                            fault_reason<=1;fault <= 1'b1;
                            state <= ST_RSP;
                        end else if (cmd_write) begin
                            state <= ST_AW;
                        end else if(cache_hit)begin
                            rsp_rdata<=source_hit ? source_cache[cmd_addr[5:3]] : result_cache[cmd_addr[5:3]];
                            if(source_hit)rsp_source_block<={source_cache[7],source_cache[6],source_cache[5],source_cache[4],source_cache[3],source_cache[2],source_cache[1],source_cache[0]};
                            state<=ST_RSP;
                        end else begin
                            read_burst<=result_read || source_prefetch;read_source<=source_prefetch;
                            if(source_prefetch)source_cache_valid<=0;
                            if(result_read)cache_valid<=0;
                            state <= ST_AR;
                        end
                    end
                end

                ST_AW: begin
                    if (axi_awready) begin
                        if (axi_wready) begin
                            receive_write;
                        end else begin
                            state <= ST_W;
                        end
                    end else if (watchdog_count >= WATCHDOG_CYCLES-1) begin
                        fault_reason<=4'd4;fault <= 1'b1;
                        rsp_rdata <= 256'd0; rsp_source_block<=0;
                        state <= ST_RSP;
                    end else begin
                        watchdog_count <= watchdog_count + 1'b1;
                    end
                end

                ST_W: begin
                    if (axi_wready) begin
                        receive_write;
                    end else if (watchdog_count >= WATCHDOG_CYCLES-1) begin
                        fault_reason<=4'd5;fault <= 1'b1;
                        rsp_rdata <= 256'd0; rsp_source_block<=0;
                        state <= ST_RSP;
                    end else begin
                        watchdog_count <= watchdog_count + 1'b1;
                    end
                end

                ST_AR: begin
                    if (axi_arready) begin
                        if (axi_rvalid) begin
                            receive_read;
                        end else begin
                            state <= ST_R;
                        end
                    end else if (watchdog_count >= WATCHDOG_CYCLES-1) begin
                        fault_reason<=4'd6;fault <= 1'b1;
                        rsp_rdata <= 256'd0; rsp_source_block<=0;
                        state <= ST_RSP;
                    end else begin
                        watchdog_count <= watchdog_count + 1'b1;
                    end
                end

                ST_R: begin
                    if (axi_rvalid) begin
                        // No RREADY exists; consecutive beats cannot be dropped.
                        receive_read;
                    end else if (watchdog_count >= WATCHDOG_CYCLES-1) begin
                        fault_reason<=4'd7;fault <= 1'b1;
                        rsp_rdata <= 256'd0; rsp_source_block<=0;
                        state <= ST_RSP;
                    end else begin
                        watchdog_count <= watchdog_count + 1'b1;
                    end
                end

                ST_RSP: begin
                    watchdog_count <= 32'd0;
                    state <= ST_IDLE;
                end

                default: begin
                    fault <= 1'b1;
                    rsp_rdata <= 256'd0; rsp_source_block<=0;
                    rsp_write <= 1'b0;
                    state <= ST_RSP;
                end
            endcase
        end
    end

endmodule

`default_nettype wire


