from pathlib import Path
import hashlib, importlib.util, json, shutil, sys
import cv2
import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parent
SRC = Path('C:/Users/Lenovo/Documents/ChatGPT/FPGA/initial_display_fix/v4s_board_20261016/user_black_marker_source.jpg')
RTL = Path('D:/FPGA/output/c_stream_board_v4s_20261016/vendor/b/rtl')
REF = Path('D:/FPGA/worktrees/c_pipeline_next/member_c/IntegratedBaseline/a_black_sync_20261014/upstream/diagnostics/ddr_camera_black_20261014/b_algorithm/python')
sys.path.insert(0, str(REF))
from brect.fixed import solve_fixed, map_fixed, sample_fixed

def prepare():
    a = np.array(Image.open(SRC).convert('RGB'))
    sh, sw = a.shape[:2]
    _, _, stats, centers = cv2.connectedComponentsWithStats(np.all(a <= 64, axis=2).astype('uint8'), 8)
    pts = [c for s,c in zip(stats[1:], centers[1:]) if 25 <= s[2] <= 70 and 25 <= s[3] <= 70 and s[4] > 500 and s[4]/(s[2]*s[3]) > .8]
    assert len(pts) == 4
    top = sorted(sorted(pts, key=lambda p:p[1])[:2], key=lambda p:p[0])
    bottom = sorted(sorted(pts, key=lambda p:p[1])[2:], key=lambda p:p[0])
    corners = np.floor(np.array([top[0],top[1],bottom[1],bottom[0]])+.5).astype(int).tolist()
    ow, oh = 765, 1080
    h = solve_fixed(corners, ow, oh, sw, sh)
    spec = importlib.util.spec_from_file_location('vector_reference', Path('D:/FPGA/worktrees/c_pipeline_next/member_c/IntegratedBaseline/stream_video_20261015/fixtures/generate.py'))
    ref = importlib.util.module_from_spec(spec); spec.loader.exec_module(ref)
    expected = ref.rectify(a,h,ow,oh,ow,0,'bilinear')
    for x,y in [(0,0),(ow-1,0),(ow-1,oh-1),(0,oh-1),(123,456),(382,540)]:
        sx,sy,ok = map_fixed(h,x,y)
        np.testing.assert_array_equal(expected[y,x],sample_fixed(a,sx,sy,'bilinear') if ok else np.zeros(3,dtype=np.uint8))
    Image.fromarray(a).save(ROOT/'input.png')
    Image.fromarray(expected).save(ROOT/'software_fixed_reference.png')
    words = (a[:,:,0].astype(np.uint32)<<16)|(a[:,:,1].astype(np.uint32)<<8)|a[:,:,2]
    np.savetxt(ROOT/'source.hex',words.ravel(),fmt='%06x')
    np.savetxt(ROOT/'H40.hex',np.array([v&((1<<40)-1) for v in h],dtype=np.uint64),fmt='%010x')
    names = ['unsigned_div_seq.v','signed_div_seq.v','homography_solver.v','scaled_div_pipe.v','perspective_coord.v','bilinear_interp.v','perspective_core.v']
    snap=ROOT/'rtl_snapshot';snap.mkdir(exist_ok=True)
    for n in names: shutil.copyfile(RTL/n,snap/n)
    ports=','.join(f'.{n}(12\'d{v})' for n,v in zip(['x0','y0','x1','y1','x2','y2','x3','y3'],np.array(corners).ravel()))
    bench = r'''`timescale 1ns/1ps
module tb_offline_demo;
 localparam SW=__SW__,SH=__SH__,OW=765,OH=1080;
 reg clk=0;always #5 clk=~clk;
 reg rst_n=0,start=0,iv=0;reg[11:0]dx=0,dy=0;
 wire busy,done,error;wire signed[39:0]h00,h01,h02,h10,h11,h12,h20,h21,h22;
 reg[39:0]expected_h[0:8];
 homography_solver #(.SRC_W(SW),.SRC_H(SH),.OUT_W(OW),.OUT_H(OH)) solver(
 .clk(clk),.rst_n(rst_n),.start(start),__PORTS__,.busy(busy),.done(done),.error(error),
 .h00(h00),.h01(h01),.h02(h02),.h10(h10),.h11(h11),.h12(h12),.h20(h20),.h21(h21),.h22(h22));
 reg[23:0]source[0:SW*SH-1];wire qv,inside_q,qe;wire[23:0]qt,a00,a10,a01,a11;wire[7:0]fx,fy;
 reg rv=0,ri=0;reg[23:0]rt=0,p00=0,p10=0,p01=0,p11=0;reg[7:0]rfx=0,rfy=0;
 wire ov;wire[23:0]rgb,ot;
 perspective_core #(.SRC_W(SW),.SRC_H(SH)) core(.clk(clk),.rst_n(rst_n),.in_valid(iv),.nearest(1'b0),.geometry_valid(1'b1),
 .dst_x(dx),.dst_y(dy),.h00(h00),.h01(h01),.h02(h02),.h10(h10),.h11(h11),.h12(h12),.h20(h20),.h21(h21),.h22(h22),
 .req_valid(qv),.req_inside(inside_q),.req_error(qe),.req_tag(qt),.addr00(a00),.addr10(a10),.addr01(a01),.addr11(a11),.req_fx(fx),.req_fy(fy),
 .rsp_valid(rv),.rsp_inside(ri),.rsp_tag(rt),.p00(p00),.p10(p10),.p01(p01),.p11(p11),.rsp_fx(rfx),.rsp_fy(rfy),
 .out_valid(ov),.out_rgb(rgb),.out_tag(ot));
 integer fd,received=0,ticks=0;
 always @(posedge clk)begin
  if(rst_n)begin
   rv<=qv;ri<=inside_q;rt<=qt;rfx<=fx;rfy<=fy;
   if(qv)begin
    if(qe)$fatal(1,"coordinate error");
    p00<=inside_q?source[a00]:0;p10<=inside_q?source[a10]:0;p01<=inside_q?source[a01]:0;p11<=inside_q?source[a11]:0;
   end
   if(ov)begin
    if(ot[11:0]!==received%OW||ot[23:12]!==received/OW)$fatal(1,"pixel order %d %h",received,ot);
    if((^rgb)===1'bx)$fatal(1,"unknown RGB");
    $fdisplay(fd,"%06h",rgb);received=received+1;
   end
   ticks=ticks+1;if(ticks>OW*OH+20000)$fatal(1,"timeout");
  end
 end
 initial begin
  $readmemh("source.hex",source);$readmemh("H40.hex",expected_h);fd=$fopen("rtl_output.hex","w");if(fd==0)$fatal(1,"file open");
  repeat(5)@(negedge clk);rst_n=1;@(negedge clk);start=1;@(negedge clk);start=0;
  wait(done);@(negedge clk);if(error)$fatal(1,"solver rejected");
  if({h00,h01,h02,h10,h11,h12,h20,h21,h22}!=={expected_h[0],expected_h[1],expected_h[2],expected_h[3],expected_h[4],expected_h[5],expected_h[6],expected_h[7],expected_h[8]})$fatal(1,"H mismatch");
  for(integer y=0;y<OH;y=y+1)for(integer x=0;x<OW;x=x+1)begin iv=1;dx=x;dy=y;@(negedge clk);end
  iv=0;wait(received==OW*OH);@(negedge clk);$fclose(fd);$display("PASS OFFLINE_B_RTL pixels=%0d solver=matched order=checked",received);$finish;
 end
endmodule
'''.replace('__SW__',str(sw)).replace('__SH__',str(sh)).replace('__PORTS__',ports)
    (ROOT/'tb_offline_demo.sv').write_text(bench)
    manifest={'input_sha256':hashlib.sha256(SRC.read_bytes()).hexdigest(),'source_dimensions':[sw,sh],'output_dimensions':[ow,oh],'corners_TL_TR_BR_BL':corners,'H_q24':h,'corner_detection':'Offline connected black components, NOT board automatic detection','scope':'B RTL solver, coordinate mapping, bilinear sampling; memory is an ideal local image array, no DDR or HDMI','aspect':'Existing project765:1080 convention; not inferred from single image','rtl_sources':{n:hashlib.sha256((snap/n).read_bytes()).hexdigest() for n in names}}
    (ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print('PREPARED',corners,flush=True)

def verify():
    values=np.array([int(x,16) for x in (ROOT/'rtl_output.hex').read_text().splitlines()],dtype=np.uint32)
    assert values.size==765*1080,values.size
    actual=np.stack(((values>>16)&255,(values>>8)&255,values&255),axis=-1).astype(np.uint8).reshape(1080,765,3)
    expected=np.array(Image.open(ROOT/'software_fixed_reference.png'))
    np.testing.assert_array_equal(actual,expected)
    Image.fromarray(actual).save(ROOT/'rtl_corrected.png')
    report=json.loads((ROOT/'manifest.json').read_text());report.update({'actual_rtl_pixels_checked':int(values.size),'different_pixels':0,'rtl_png_sha256':hashlib.sha256((ROOT/'rtl_corrected.png').read_bytes()).hexdigest(),'hardware_accepted':False})
    (ROOT/'result.json').write_text(json.dumps(report,indent=2)+'\n')
    print('PASS PIXEL_EXACT',values.size,'different_pixels=0')

if __name__=='__main__':
    verify() if '--verify' in sys.argv else prepare()
