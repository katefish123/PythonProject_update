`timescale 1ns/1ps
module tb_offline_demo;
 localparam SW=1586,SH=992,OW=765,OH=1080;
 reg clk=0;always #5 clk=~clk;
 reg rst_n=0,start=0,iv=0;reg[11:0]dx=0,dy=0;
 wire busy,done,error;wire signed[39:0]h00,h01,h02,h10,h11,h12,h20,h21,h22;
 reg[39:0]expected_h[0:8];
 homography_solver #(.SRC_W(SW),.SRC_H(SH),.OUT_W(OW),.OUT_H(OH)) solver(
 .clk(clk),.rst_n(rst_n),.start(start),.x0(12'd489),.y0(12'd104),.x1(12'd1331),.y1(12'd197),.x2(12'd1405),.y2(12'd909),.x3(12'd148),.y3(12'd875),.busy(busy),.done(done),.error(error),
 .h00(h00),.h01(h01),.h02(h02),.h10(h10),.h11(h11),.h12(h12),.h20(h20),.h21(h21),.h22(h22));
 reg[23:0]source[0:SW*SH-1];wire qv,inside_q,qe;wire[23:0]qt,a00,a10,a01,a11;wire[7:0]fx,fy;
 reg rv=0,ri=0;reg[23:0]rt=0,p00=0,p10=0,p01=0,p11=0;reg[7:0]rfx=0,rfy=0;
 wire ov;wire[23:0]rgb,ot;
 perspective_core #(.SRC_W(SW),.SRC_H(SH)) core(.clk(clk),.rst_n(rst_n),.in_valid(iv),.nearest(1'b0),.geometry_valid(1'b1),
 .dst_x(dx),.dst_y(dy),.h00(h00),.h01(h01),.h02(h02),.h10(h10),.h11(h11),.h12(h12),.h20(h20),.h21(h21),.h22(h22),
 .req_valid(qv),.req_inside(inside_q),.req_error(qe),.req_tag(qt),.addr00(a00),.addr10(a10),.addr01(a01),.addr11(a11),.req_fx(fx),.req_fy(fy),
 .rsp_valid(rv),.rsp_inside(ri),.rsp_tag(rt),.p00(p00),.p10(p10),.p01(p01),.p11(p11),.rsp_fx(rfx),.rsp_fy(rfy),
 .out_valid(ov),.out_rgb(rgb),.out_tag(ot));
 integer fd,received=0,ticks=0;
 always @(posedge clk)begin
  if(rst_n)begin
   rv<=qv;ri<=inside_q;rt<=qt;rfx<=fx;rfy<=fy;
   if(qv)begin
    if(qe)$fatal(1,"coordinate error");
    p00<=inside_q?source[a00]:0;p10<=inside_q?source[a10]:0;p01<=inside_q?source[a01]:0;p11<=inside_q?source[a11]:0;
   end
   if(ov)begin
    if(ot[11:0]!==received%OW||ot[23:12]!==received/OW)$fatal(1,"pixel order %d %h",received,ot);
    if((^rgb)===1'bx)$fatal(1,"unknown RGB");
    $fdisplay(fd,"%06h",rgb);received=received+1;
   end
   ticks=ticks+1;if(ticks>OW*OH+20000)$fatal(1,"timeout");
  end
 end
 initial begin
  $readmemh("source.hex",source);$readmemh("H40.hex",expected_h);fd=$fopen("rtl_output.hex","w");if(fd==0)$fatal(1,"file open");
  repeat(5)@(negedge clk);rst_n=1;@(negedge clk);start=1;@(negedge clk);start=0;
  wait(done);@(negedge clk);if(error)$fatal(1,"solver rejected");
  if({h00,h01,h02,h10,h11,h12,h20,h21,h22}!=={expected_h[0],expected_h[1],expected_h[2],expected_h[3],expected_h[4],expected_h[5],expected_h[6],expected_h[7],expected_h[8]})$fatal(1,"H mismatch");
  for(integer y=0;y<OH;y=y+1)for(integer x=0;x<OW;x=x+1)begin iv=1;dx=x;dy=y;@(negedge clk);end
  iv=0;wait(received==OW*OH);@(negedge clk);$fclose(fd);$display("PASS OFFLINE_B_RTL pixels=%0d solver=matched order=checked",received);$finish;
 end
endmodule
