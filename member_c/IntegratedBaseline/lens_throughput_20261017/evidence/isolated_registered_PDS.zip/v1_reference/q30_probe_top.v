module q30_probe_top(input wire clk,rst_n,start,input wire[1:0]op,input wire signed[63:0]a,b,
 output reg ready,done,error,output reg signed[63:0]value);
 reg start_q;reg[1:0]op_q;reg signed[63:0]a_q,b_q;
 wire ready_d,done_d,error_d;wire signed[63:0]value_d;
 q30_alu dut(.clk(clk),.rst_n(rst_n),.start(start_q),.op(op_q),.a(a_q),.b(b_q),.ready(ready_d),.done(done_d),.error(error_d),.value(value_d));
 always @(posedge clk or negedge rst_n)begin
 if(!rst_n)begin start_q<=0;op_q<=0;a_q<=0;b_q<=0;ready<=0;done<=0;error<=0;value<=0;end
 else begin start_q<=start;op_q<=op;a_q<=a;b_q<=b;ready<=ready_d;done<=done_d;error<=error_d;value<=value_d;end
 end endmodule
