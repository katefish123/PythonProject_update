set_arch -family Logos2 -device PG2L100H -speedgrade -6 -package FBG676
add_design {D:/FPGA/output/lens_alu_registered_probe_20261017/fast/q30_alu_fast.v}
add_design {D:/FPGA/output/lens_alu_registered_probe_20261017/fast/q30_probe_top.v}
add_constraint {D:/FPGA/output/lens_alu_registered_probe_20261017/fast/probe.fdc}
compile -top_module q30_probe_top
synthesize -ads
dev_map
pnr -gplace_seed 17 -groute_seed 17 -optimize_multi_corner_timing -slack_prior_in_global_router TRUE
report_timing
