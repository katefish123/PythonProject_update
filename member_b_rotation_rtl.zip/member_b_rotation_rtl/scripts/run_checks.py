"""Reproduce software-oracle, RTL, video and test-sensitivity checks locally."""
import argparse
import csv
import hashlib
import json
import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / "build"
RESULTS = ROOT / "results"


def run(command, log_name, pass_marker=None, expected_failure=None):
    proc = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, timeout=60)
    output = proc.stdout + proc.stderr
    (RESULTS / log_name).write_text(output, encoding="utf-8")
    if expected_failure:
        if proc.returncode == 0 or expected_failure not in output:
            raise RuntimeError(f"negative check did not fail as intended: {log_name}\n{output}")
    elif proc.returncode != 0 or (pass_marker and pass_marker not in output):
        raise RuntimeError(f"verification failed: {log_name}\n{output}")
    if not expected_failure and re.search(r"\b(warning|error|TEST_FAIL)\b", output, re.I):
        raise RuntimeError(f"unexpected diagnostic: {log_name}\n{output}")
    return output


def compile_coord(iverilog, group, source="rtl/rotation_coord.v", suffix=""):
    executable = BUILD / (group["name"]+suffix+".vvp")
    overrides = {"SRC_W": group["source_width"], "SRC_H": group["source_height"],
        "OUT_W": group["output_width"], "OUT_H": group["output_height"], "FRAC_BITS": group["frac_bits"]}
    flags = [f"-Ptb_rotation_coord.{name}={value}" for name, value in overrides.items()]
    run([iverilog,"-g2012","-Wall","-s","tb_rotation_coord",*flags,"-o",str(executable),source,"sim/tb_rotation_coord.sv"], group["name"]+suffix+"_compile.log")
    return executable


def actual_images():
    cases = {}
    with (BUILD / "video_actual.csv").open(newline="") as f:
        for row in csv.DictReader(f):
            if int(row["frame"]) != 0:
                continue
            angle = int(row["angle"])
            cases.setdefault(angle, {})[(int(row["x_output"]),int(row["y_output"]))] = int(row["rgb_hex"],16)
    if set(cases) != {0,30,-30,90,180,270}:
        raise RuntimeError("incomplete video trace")
    for angle, pixels in cases.items():
        if len(pixels)!=48:
            raise RuntimeError("incomplete reconstructed frame")
        image = Image.new("RGB",(8,6))
        for (x,y), word in pixels.items():
            image.putpixel((x,y),(word>>16,(word>>8)&255,word&255))
        tag=str(angle).replace("-","minus_")
        expected=Image.open(ROOT/"vectors"/f"rotate_{tag}.png").convert("RGB")
        if image.tobytes()!=expected.tobytes():
            raise RuntimeError("reconstructed RTL frame differs from software")
        image.save(RESULTS/f"rtl_rotate_{tag}.png")
    shutil.copyfile(BUILD/"video_actual.csv",RESULTS/"video_actual.csv")


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--skip-generate",action="store_true")
    args=parser.parse_args()
    iverilog,vvp=shutil.which("iverilog"),shutil.which("vvp")
    if not iverilog or not vvp:
        raise RuntimeError("install Icarus Verilog (iverilog and vvp) before verification")
    BUILD.mkdir(exist_ok=True);RESULTS.mkdir(exist_ok=True)
    report_path=RESULTS/"verification.json"
    report_path.unlink(missing_ok=True)
    if not args.skip_generate:
        run([sys.executable,"-B","scripts/generate_vectors.py"],"generate.log","Generated")
    run([sys.executable,"-B","reference/geometry_float.py","self-test"],"float_model.log","Float self-test passed")
    run([sys.executable,"-B","reference/geometry_fixed.py","self-test"],"fixed_model.log","Fixed self-test passed")
    manifest=json.loads((ROOT/"vectors/manifest.json").read_text())
    tclsh=shutil.which("tclsh")
    tcl_cases_checked=False
    if tclsh:
        tcl_test=BUILD/"check_cases.tcl"
        tcl_test.write_text('source vectors/coordinate_cases.tcl\nforeach item $coord_cases { puts [join $item ","] }\n')
        output=run([tclsh,str(tcl_test)],"tcl_cases.log")
        wanted=[",".join(str(g[k]) for k in ("name","source_width","source_height","output_width","output_height","frac_bits")) for g in manifest["groups"]]
        if output.splitlines()!=wanted:
            raise RuntimeError("ModelSim/Python parameter lists differ")
        tcl_cases_checked=True
    results=[]
    for group in manifest["groups"]:
        executable=compile_coord(iverilog,group)
        output=run([vvp,str(executable),f"+vectors=vectors/{group['name']}.txt"],group["name"]+"_run.log","TEST_PASS_COORD")
        match=re.search(r"checked=(\d+) errors_checked=(\d+) bubbles=(\d+) resets=(\d+)",output)
        checked,errors,bubbles,resets=map(int,match.groups())
        if checked!=group["records"]+1 or errors!=group["errors_expected"]+1 or resets!=1:
            raise RuntimeError("coordinate test coverage/count mismatch")
        results.append(dict(group,checked_transactions=checked,errors_checked=errors,bubbles=bubbles,resets=resets,status="passed"))
        print(f"PASS {group['name']}: {checked} transactions")
    video_sources=["vendor/video_timing_vtc.v","rtl/rotation_coord.v","rtl/rotation_video_demo.v","sim/tb_rotation_video_demo.sv"]
    video_executable=BUILD/"video.vvp"
    run([iverilog,"-g2012","-Wall","-s","tb_rotation_video_demo","-o",str(video_executable),*video_sources],"video_compile.log")
    video_output=run([vvp,str(video_executable)],"video_run.log","TEST_PASS_VIDEO")
    video_match=re.search(r"TEST_PASS_VIDEO pixels=(\d+) cycles=(\d+) cases=(\d+) error_pixels=(\d+)",video_output)
    pixels,cycles,cases,error_pixels=map(int,video_match.groups())
    if (pixels,cycles,cases,error_pixels)!=(720,1918,7,48):
        raise RuntimeError("video coverage mismatch")
    actual_images()
    # Deliberate local mutations prove that the tests can detect wrong arithmetic and alignment.
    mutation=BUILD/"rotation_coord_bad_rounding.v"
    mutation.write_text((ROOT/"rtl/rotation_coord.v").read_text().replace("qx_wide+HALF","qx_wide"))
    exe=compile_coord(iverilog,manifest["groups"][1],str(mutation),"_mutation")
    run([vvp,str(exe),"+vectors=vectors/half_centers.txt"],"rounding_mutation.log",expected_failure="coordinate/reference mismatch")
    gating_mutation=BUILD/"rotation_coord_bad_gating.v"
    gating_mutation.write_text((ROOT/"rtl/rotation_coord.v").read_text().replace("in_bounds<=valid_s2&&inside_window;","in_bounds<=inside_window;"))
    exe=compile_coord(iverilog,manifest["groups"][0],str(gating_mutation),"_gating_mutation")
    run([vvp,str(exe),"+vectors=vectors/tiny_f16.txt"],"gating_mutation.log",expected_failure="invalid-slot read gating mismatch")
    mutation_video=BUILD/"rotation_video_bad_sync.v"
    mutation_video.write_text((ROOT/"rtl/rotation_video_demo.v").read_text().replace("assign hsync=hsync_pipe[3]","assign hsync=hsync_pipe[2]"))
    bad_exe=BUILD/"bad_sync.vvp"
    run([iverilog,"-g2012","-Wall","-s","tb_rotation_video_demo","-o",str(bad_exe),video_sources[0],video_sources[1],str(mutation_video),video_sources[3]],"sync_mutation_compile.log")
    run([vvp,str(bad_exe)],"sync_mutation.log",expected_failure="video timing/pixel mismatch")
    error_mutation=BUILD/"rotation_video_bad_error.v"
    error_mutation.write_text((ROOT/"rtl/rotation_video_demo.v").read_text().replace("error<=coord_valid&&coord_error;","error<=1'b0;"))
    error_exe=BUILD/"bad_error.vvp"
    run([iverilog,"-g2012","-Wall","-s","tb_rotation_video_demo","-o",str(error_exe),video_sources[0],video_sources[1],str(error_mutation),video_sources[3]],"error_mutation_compile.log")
    run([vvp,str(error_exe)],"error_mutation.log",expected_failure="video timing/pixel mismatch")
    # The mutation writes a partial trace; restore the authoritative trace from the unmodified design.
    shutil.copyfile(RESULTS/"video_actual.csv",BUILD/"video_actual.csv")
    invalid=dict(manifest["groups"][0],name="invalid_fraction",frac_bits=9)
    exe=compile_coord(iverilog,invalid)
    run([vvp,str(exe),"+vectors=vectors/tiny_f16.txt"],"invalid_fraction.log",expected_failure="FRAC_BITS must be 10..20")
    provenance=json.loads((ROOT/"reference/provenance.json").read_text())
    for entry in provenance:
        if hashlib.sha256((ROOT/entry["copy"]).read_bytes()).hexdigest()!=entry["sha256"]:
            raise RuntimeError("reference copy was modified")
    hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
        for folder in ("rtl","sim","scripts","vendor","reference","vectors")
        for p in (ROOT/folder).rglob("*") if p.is_file() and "__pycache__" not in p.parts}
    report={"status":"passed","verified_at_utc":datetime.now(timezone.utc).isoformat(),"groups":results,
        "coordinate_vector_records":sum(g["records"] for g in results),"coordinate_transactions_checked":sum(g["checked_transactions"] for g in results),
        "video":{"cases":cases,"normal_angle_cases":6,"frames_per_normal_case":2,"error_recovery_frames":3,"pixels_checked":pixels,"error_pixels_checked":error_pixels,"clock_positions_checked":cycles,"mismatches":0},
        "sensitivity_checks":{"proof_first_evidence":"results/pre_implementation_red.json","wrong_rounding_detected":True,"wrong_sync_delay_detected":True,"invalid_fraction_rejected":True,"invalid_slot_read_gate_detected":True,"disconnected_video_error_detected":True},
        "shared_modelsim_parameter_list_checked_with_tcl":tcl_cases_checked,
        "original_references_unchanged":True,"file_sha256":hashes,
        "limitations":["functional simulation only; PDS synthesis/place-route/timing and board HDMI display not verified", "rotation + nearest only; perspective and bilinear interpolation are outside this first version"]}
    report_path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n")
    print(f"PASS video: {pixels} pixels, {cycles} clock positions; mutation tests detected all four errors")
    print(f"ALL_CHECKS_PASS coordinates={report['coordinate_transactions_checked']} video_pixels={pixels}")


if __name__=="__main__":
    main()
