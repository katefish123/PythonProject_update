"""Generate RTL expectations by calling the existing checked integer model."""
import csv
import hashlib
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "reference"))
import geometry_float as floating
import geometry_fixed as fixed

ANGLES = [0, 30, -30, 90, 180, 270]
GROUPS = [
    ("tiny_f16", 8, 6, 8, 6, 16),
    ("half_centers", 5, 4, 5, 4, 16),
    ("different_canvas", 9, 7, 8, 6, 16),
    ("one_pixel", 1, 1, 1, 1, 16),
    ("tiny_f10", 8, 6, 8, 6, 10),
    ("tiny_f20", 8, 6, 8, 6, 20),
    ("overflow_f20", 4095, 4095, 4095, 4095, 20),
]
FIELDS = ["x_output", "y_output", "cos_q", "sin_q", "x_source_q", "y_source_q",
          "x_nearest", "y_nearest", "in_bounds", "address_pixel", "error"]


def parameters(sw, sh, ow, oh, angle, frac):
    p = floating.rotation_parameters(sw, sh, angle, canvas="same")
    p.update(width=ow, height=oh)
    c, s = p["cos"], p["sin"]
    cx, cy, ox, oy = (sw-1)/2, (sh-1)/2, (ow-1)/2, (oh-1)/2
    p["inverse_matrix"] = [[c, -s, cx-c*ox+s*oy], [s, c, cy-s*ox-c*oy], [0, 0, 1]]
    return p, fixed.quantize_parameters(p, frac)


def expected(x, y, p, cq=None, sq=None):
    p = dict(p)
    if cq is not None:
        p.update(cos_q=cq, sin_q=sq)
    base = [x, y, p["cos_q"], p["sin_q"]]
    if x >= p["width"] or y >= p["height"] or abs(p["cos_q"]) > p["scale"] or abs(p["sin_q"]) > p["scale"]:
        return base + [0, 0, -1, -1, 0, -1, 1]
    try:
        xq, yq, valid = fixed.map_rotation(x, y, p)
        assert valid
        xi, yi = fixed.nearest_index(xq, p["scale"]), fixed.nearest_index(yq, p["scale"])
    except fixed.FixedOverflowError:
        return base + [0, 0, -1, -1, 0, -1, 1]
    inside = int(0 <= xi < p["source_width"] and 0 <= yi < p["source_height"])
    addr = yi*p["source_width"]+xi if inside else -1
    return base + [xq, yq, xi, yi, inside, addr, 0]


def save_records(path, rows):
    path.with_suffix(".txt").write_text("".join(" ".join(f"{v & 0xffffffff:08x}" for v in row)+"\n" for row in rows))
    with path.with_suffix(".csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(FIELDS)
        writer.writerows(rows)


def preview(source_rgb, outputs, path):
    tiles = [("Source 8 x 6", source_rgb)] + [(f"{angle:+d} deg / same canvas", output) for angle, output in outputs]
    sheet = Image.new("RGB", (720, 190*((len(tiles)+2)//3)), "#eef1f5")
    draw = ImageDraw.Draw(sheet)
    for i, (label, rgb) in enumerate(tiles):
        x, y = (i % 3)*240, (i // 3)*190
        draw.text((x+16, y+10), label, fill="#17243a")
        tile = Image.fromarray(rgb).resize((192, 144), Image.Resampling.NEAREST)
        sheet.paste(tile, (x+24, y+32))
    sheet.save(path)


def main():
    vector_dir = ROOT / "vectors"
    vector_dir.mkdir(exist_ok=True)
    image = floating.read_image(ROOT / "reference" / "tiny_8x6.png")
    assert image.shape == (6, 8, 3)
    floating.save_image(vector_dir / "source.png", image)
    rgb = image[:, :, ::-1]
    packed = (rgb[:, :, 0].astype(np.uint32) << 16) | (rgb[:, :, 1].astype(np.uint32) << 8) | rgb[:, :, 2]
    (vector_dir / "source_rgb.mem").write_text("".join(f"{int(v):06x}\n" for v in packed.flat))
    manifest = {"groups": [], "fields": FIELDS, "preview_cases": [], "origin": "top-left pixel center", "positive_angle": "visually counterclockwise"}
    outputs = []
    for name, sw, sh, ow, oh, frac in GROUPS:
        rows = []
        points = [(x, y) for y in range(oh) for x in range(ow)] if name != "overflow_f20" else [(0, 0), (ow-1, 0), (0, oh-1), (ow-1, oh-1), (2047, 2047)]
        for angle in ANGLES:
            pf, p = parameters(sw, sh, ow, oh, angle, frac)
            rows.extend(expected(x, y, p) for x, y in points)
            if name == "tiny_f16":
                result = fixed.render(image, p)
                output, xq, yq, xi, yi, inside, addr, _, _ = result
                tag = str(angle).replace("-", "minus_")
                floating.save_image(vector_dir / f"rotate_{tag}.png", output)
                outputs.append((angle, output[:, :, ::-1]))
                save_records(vector_dir / f"rotate_{tag}", [expected(x, y, p) for y in range(oh) for x in range(ow)])
                floating_output = floating.render(image, pf)[0]
                fx, fy = floating.map_grid(pf)
                max_error = float(max(np.max(np.abs(xq/p["scale"]-fx)), np.max(np.abs(yq/p["scale"]-fy))))
                manifest["preview_cases"].append({"angle": angle, "cos_q": p["cos_q"], "sin_q": p["sin_q"], "pixels": ow*oh,
                    "black_border_pixels": int(np.count_nonzero(~inside)), "float_coordinate_max_error": max_error,
                    "float_pixel_changes": int(np.count_nonzero(np.any(output != floating_output, axis=2)))})
                p["rtl_contract"] = {"coordinate_bits": 12, "pipeline_register_stages": 3, "capture_to_result_clock_intervals": 2,
                    "pixel_format": "RGB888: R[23:16],G[15:8],B[7:0]", "error": "invalid request or coordinate narrowing overflow; suppress read"}
                floating.dump_json(vector_dir / f"rotate_{tag}_parameters.json", p)
                expected_rgb = output[:, :, ::-1]
                expected_words = (expected_rgb[:, :, 0].astype(np.uint32)<<16) | (expected_rgb[:, :, 1].astype(np.uint32)<<8) | expected_rgb[:, :, 2]
                (vector_dir / f"rotate_{tag}_rgb.mem").write_text("".join(f"{int(v):06x}\n" for v in expected_words.flat))
        _, p0 = parameters(sw, sh, ow, oh, 0, frac)
        scale=p0["scale"]
        rows.extend([expected(ow, 0, p0), expected(0, oh, p0),
            expected(0, 0, p0, scale+1, 0), expected(0, 0, p0, -scale-1, 0),
            expected(0, 0, p0, 0, scale+1), expected(0, 0, p0, 0, -scale-1)])
        save_records(vector_dir / name, rows)
        manifest["groups"].append({"name": name, "source_width": sw, "source_height": sh, "output_width": ow, "output_height": oh,
            "frac_bits": frac, "records": len(rows), "errors_expected": sum(row[-1] for row in rows), "angles": ANGLES})
    preview(rgb, outputs, vector_dir / "preview.png")
    case_lines=["set coord_cases {"]
    for group in manifest["groups"]:
        values=[group[key] for key in ("name","source_width","source_height","output_width","output_height","frac_bits")]
        case_lines.append("    {"+" ".join(map(str,values))+"}")
    (vector_dir/"coordinate_cases.tcl").write_text("\n".join(case_lines+["}",""]))
    manifest["source_rgb_mem_sha256"] = hashlib.sha256((vector_dir / "source_rgb.mem").read_bytes()).hexdigest()
    floating.dump_json(vector_dir / "manifest.json", manifest)
    print(f"Generated {sum(g['records'] for g in manifest['groups'])} coordinate records, 7 groups and 6 images")


if __name__ == "__main__":
    main()
