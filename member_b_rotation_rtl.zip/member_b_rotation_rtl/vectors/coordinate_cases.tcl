set coord_cases {
    {tiny_f16 8 6 8 6 16}
    {half_centers 5 4 5 4 16}
    {different_canvas 9 7 8 6 16}
    {one_pixel 1 1 1 1 16}
    {tiny_f10 8 6 8 6 10}
    {tiny_f20 8 6 8 6 20}
    {overflow_f20 4095 4095 4095 4095 20}
}
