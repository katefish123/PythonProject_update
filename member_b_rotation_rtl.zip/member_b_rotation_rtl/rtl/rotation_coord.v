`timescale 1ns/1ps
`default_nettype none

// Inverse rotation + nearest sampling address. Pixel memory is owned by A.
// Three register stages: request captured at E0, result available after E2.
module rotation_coord #(
    parameter integer SRC_W=8, SRC_H=6, OUT_W=8, OUT_H=6,
    parameter integer FRAC_BITS=16
)(
    input wire clk, rst_n, in_valid,
    input wire [11:0] x_out, y_out,
    input wire signed [31:0] cos_q, sin_q,
    output reg out_valid,
    output reg [11:0] out_x, out_y,
    output reg signed [31:0] sx_q, sy_q,
    output reg signed [31:0] x_nearest, y_nearest,
    output reg in_bounds,
    output reg signed [31:0] source_addr,
    output reg out_error
);
localparam signed [63:0] SCALE = 64'sd1 <<< FRAC_BITS;
localparam signed [63:0] HALF = SCALE >>> 1;
localparam signed [63:0] SW=SRC_W, SH=SRC_H, OW=OUT_W, OH=OUT_H;
localparam signed [63:0] CENTER_X=(SW-64'sd1)*SCALE;
localparam signed [63:0] CENTER_Y=(SH-64'sd1)*SCALE;
localparam signed [63:0] MIN_Q=-64'sd2147483648, MAX_Q=64'sd2147483647;

// Explicit extension prevents unsigned promotion and premature narrowing.
wire signed [63:0] px=$signed({52'b0,x_out});
wire signed [63:0] py=$signed({52'b0,y_out});
wire signed [63:0] cq={{32{cos_q[31]}},cos_q};
wire signed [63:0] sq={{32{sin_q[31]}},sin_q};
wire signed [63:0] dx2=(px <<< 1)-(OW-64'sd1);
wire signed [63:0] dy2=(py <<< 1)-(OH-64'sd1);
wire request_error=(px>=OW)||(py>=OH)||(cq>SCALE)||(cq < -SCALE)||(sq>SCALE)||(sq < -SCALE);

reg valid_s1, error_s1;
reg [11:0] x_s1,y_s1;
reg signed [63:0] num_x_s1,num_y_s1;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        valid_s1<=0;error_s1<=0;x_s1<=0;y_s1<=0;num_x_s1<=0;num_y_s1<=0;
    end else begin
        valid_s1<=in_valid;
        error_s1<=request_error;
        x_s1<=x_out;y_s1<=y_out;
        num_x_s1<=cq*dx2-sq*dy2+CENTER_X;
        num_y_s1<=sq*dx2+cq*dy2+CENTER_Y;
    end
end

// floor((n+1)/2) implements nearest division by 2, ties toward +infinity.
// This is deliberately different from signed Verilog '/' for negative values.
wire signed [63:0] rounded_x=(num_x_s1+64'sd1) >>> 1;
wire signed [63:0] rounded_y=(num_y_s1+64'sd1) >>> 1;
wire narrowing_error=(rounded_x<MIN_Q)||(rounded_x>MAX_Q)||(rounded_y<MIN_Q)||(rounded_y>MAX_Q);
reg valid_s2,error_s2;
reg [11:0] x_s2,y_s2;
reg signed [31:0] qx_s2,qy_s2;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        valid_s2<=0;error_s2<=0;x_s2<=0;y_s2<=0;qx_s2<=0;qy_s2<=0;
    end else begin
        valid_s2<=valid_s1;
        error_s2<=error_s1||narrowing_error;
        x_s2<=x_s1;y_s2<=y_s1;
        qx_s2<=(error_s1||narrowing_error) ? 32'sd0 : rounded_x[31:0];
        qy_s2<=(error_s1||narrowing_error) ? 32'sd0 : rounded_y[31:0];
    end
end

wire signed [63:0] qx_wide={{32{qx_s2[31]}},qx_s2};
wire signed [63:0] qy_wide={{32{qy_s2[31]}},qy_s2};
wire signed [63:0] ix=(qx_wide+HALF) >>> FRAC_BITS;
wire signed [63:0] iy=(qy_wide+HALF) >>> FRAC_BITS;
wire inside_window=!error_s2&&(ix>=0)&&(ix<SW)&&(iy>=0)&&(iy<SH);
wire signed [63:0] address=iy*SW+ix;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        out_valid<=0;out_x<=0;out_y<=0;sx_q<=0;sy_q<=0;
        x_nearest<=-32'sd1;y_nearest<=-32'sd1;in_bounds<=0;source_addr<=-32'sd1;out_error<=0;
    end else begin
        out_valid<=valid_s2;
        out_x<=x_s2;out_y<=y_s2;sx_q<=qx_s2;sy_q<=qy_s2;
        x_nearest<=error_s2 ? -32'sd1 : ix[31:0];
        y_nearest<=error_s2 ? -32'sd1 : iy[31:0];
        in_bounds<=valid_s2&&inside_window;
        source_addr<=(valid_s2&&inside_window) ? address[31:0] : -32'sd1;
        out_error<=valid_s2&&error_s2;
    end
end

`ifndef SYNTHESIS
initial begin
    if(SRC_W<1||SRC_W>4095||SRC_H<1||SRC_H>4095||OUT_W<1||OUT_W>4095||OUT_H<1||OUT_H>4095)
        $fatal(1,"dimensions must be 1..4095");
    if(FRAC_BITS<10||FRAC_BITS>20) $fatal(1,"FRAC_BITS must be 10..20");
end
`endif
endmodule
`default_nettype wire
