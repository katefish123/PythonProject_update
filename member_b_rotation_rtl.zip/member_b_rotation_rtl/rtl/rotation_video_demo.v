`timescale 1ns/1ps
`default_nettype none

// Static ROM demonstration: C's VTC -> B's coordinates -> synchronous ROM read.
// The RGB/control output is registered four times from the VTC sampling edge.
module rotation_video_demo #(
    parameter integer SRC_W=8, SRC_H=6, OUT_W=8, OUT_H=6,
    parameter integer FRAC_BITS=16,
    parameter SOURCE_FILE="vectors/source_rgb.mem",
    parameter [11:0] H_SYNC=12'd2,H_BACK=12'd2,H_FRONT=12'd2,
    parameter [11:0] V_SYNC=12'd1,V_BACK=12'd1,V_FRONT=12'd1
)(
    input wire clk,rst_n,
    input wire signed [31:0] cos_q,sin_q,
    output wire hsync,vsync,
    output reg de,
    output reg [23:0] rgb,
    output reg error
);
localparam [11:0] H_START=H_SYNC+H_BACK, V_START=V_SYNC+V_BACK;
wire [11:0] h_cnt,v_cnt;
wire raw_hsync,raw_vsync,raw_de;
video_timing_vtc #(
    .H_SYNC(H_SYNC),.H_BACK(H_BACK),.H_ACTIVE(OUT_W[11:0]),.H_FRONT(H_FRONT),
    .V_SYNC(V_SYNC),.V_BACK(V_BACK),.V_ACTIVE(OUT_H[11:0]),.V_FRONT(V_FRONT)
) u_vtc (.clk(clk),.rst_n(rst_n),.h_cnt(h_cnt),.v_cnt(v_cnt),.hsync(raw_hsync),.vsync(raw_vsync),.de(raw_de));

wire [11:0] x_out=raw_de ? h_cnt-H_START : 12'd0;
wire [11:0] y_out=raw_de ? v_cnt-V_START : 12'd0;
wire coord_valid,inside_window,coord_error;
wire signed [31:0] address;
rotation_coord #(.SRC_W(SRC_W),.SRC_H(SRC_H),.OUT_W(OUT_W),.OUT_H(OUT_H),.FRAC_BITS(FRAC_BITS)) u_coord (
    .clk(clk),.rst_n(rst_n),.in_valid(raw_de),.x_out(x_out),.y_out(y_out),.cos_q(cos_q),.sin_q(sin_q),
    .out_valid(coord_valid),.out_x(),.out_y(),.sx_q(),.sy_q(),.x_nearest(),.y_nearest(),
    .in_bounds(inside_window),.source_addr(address),.out_error(coord_error));

reg [23:0] source_rom[0:SRC_W*SRC_H-1];
initial $readmemh(SOURCE_FILE,source_rom);
reg [3:0] hsync_pipe,vsync_pipe;
assign hsync=hsync_pipe[3];
assign vsync=vsync_pipe[3];
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        hsync_pipe<=0;vsync_pipe<=0;de<=0;rgb<=0;error<=0;
    end else begin
        hsync_pipe<={hsync_pipe[2:0],raw_hsync};
        vsync_pipe<={vsync_pipe[2:0],raw_vsync};
        de<=coord_valid;
        error<=coord_valid&&coord_error;
        // Display validity stays asserted even when the source mapping is outside.
        rgb<=(coord_valid&&inside_window&&!coord_error) ? source_rom[address] : 24'h000000;
    end
end
endmodule
`default_nettype wire
