# Stop this script on errors while keeping the ModelSim window open.
onerror {abort}
catch {quit -sim}
file mkdir build
file mkdir results
transcript file results/modelsim_check.log
if {[file exists work_b]} {vdel -lib work_b -all}
vlib work_b
vmap work_b work_b
vlog -work work_b vendor/video_timing_vtc.v
vlog -work work_b rtl/rotation_coord.v
vlog -work work_b rtl/rotation_video_demo.v
vlog -sv -work work_b sim/tb_rotation_coord.sv
vlog -sv -work work_b sim/tb_rotation_video_demo.sv
source vectors/coordinate_cases.tcl
foreach item $coord_cases {
    lassign $item name sw sh ow oh frac
    vsim -voptargs=+acc -onfinish stop -gSRC_W=$sw -gSRC_H=$sh -gOUT_W=$ow -gOUT_H=$oh -gFRAC_BITS=$frac work_b.tb_rotation_coord +vectors=vectors/$name.txt
    run -all
    if {[examine -radix decimal sim:/tb_rotation_coord/test_passed] != 1} {error "TEST_FAIL_COORD: $name"}
    quit -sim
}
vsim -voptargs=+acc -onfinish stop work_b.tb_rotation_video_demo
run -all
if {[examine -radix decimal sim:/tb_rotation_video_demo/test_passed] != 1} {error "TEST_FAIL_VIDEO"}
puts "ALL_MODELSIM_CHECKS_PASS"
