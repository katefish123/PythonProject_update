`timescale 1ns/1ps
module tb_rotation_coord;
parameter integer SRC_W=8, SRC_H=6, OUT_W=8, OUT_H=6, FRAC_BITS=16;
reg clk=0, rst_n=0, in_valid=0;
reg [11:0] x_out=0, y_out=0;
reg signed [31:0] cos_q=0, sin_q=0;
wire out_valid, in_bounds, out_error;
wire [11:0] out_x, out_y;
wire signed [31:0] sx_q, sy_q, x_nearest, y_nearest, source_addr;
rotation_coord #(.SRC_W(SRC_W),.SRC_H(SRC_H),.OUT_W(OUT_W),.OUT_H(OUT_H),.FRAC_BITS(FRAC_BITS)) dut (
 .clk(clk),.rst_n(rst_n),.in_valid(in_valid),.x_out(x_out),.y_out(y_out),.cos_q(cos_q),.sin_q(sin_q),
 .out_valid(out_valid),.out_x(out_x),.out_y(out_y),.sx_q(sx_q),.sy_q(sy_q),
 .x_nearest(x_nearest),.y_nearest(y_nearest),.in_bounds(in_bounds),.source_addr(source_addr),.out_error(out_error));
always #5 clk=~clk;

reg [31:0] input_words[0:10];
reg [31:0] pending[0:10];
reg [31:0] scoreboard[0:2][0:10];
reg [2:0] valid_pipe=0;
integer checked=0, injected=0, error_checked=0, bubbles=0, reset_count=0;
integer fd, n, i, j, record_count=0;
integer test_passed=0;
string vector_file;

always @(posedge clk) begin
 if (!rst_n) valid_pipe=0;
 else begin
  for (i=2;i>0;i=i-1) begin
   valid_pipe[i]=valid_pipe[i-1];
   for (j=0;j<11;j=j+1) scoreboard[i][j]=scoreboard[i-1][j];
  end
  valid_pipe[0]=in_valid;
  for (j=0;j<11;j=j+1) scoreboard[0][j]=pending[j];
 end
 #1;
 if (out_valid !== valid_pipe[2]) $fatal(1,"valid pipeline mismatch");
 if (out_valid === 1'b0 &&
     (in_bounds !== 1'b0 || source_addr !== -32'sd1 || out_error !== 1'b0))
  $fatal(1,"invalid-slot read gating mismatch");
 if (out_valid) begin
  if (out_x !== scoreboard[2][0][11:0] || out_y !== scoreboard[2][1][11:0] ||
      sx_q !== scoreboard[2][4] || sy_q !== scoreboard[2][5] ||
      x_nearest !== scoreboard[2][6] || y_nearest !== scoreboard[2][7] ||
      in_bounds !== scoreboard[2][8][0] || source_addr !== scoreboard[2][9] || out_error !== scoreboard[2][10][0]) begin
   $display("input (%0d,%0d) cos=%0d sin=%0d",scoreboard[2][0],scoreboard[2][1],$signed(scoreboard[2][2]),$signed(scoreboard[2][3]));
   $display("actual xq=%0d yq=%0d ix=%0d iy=%0d inside=%0d addr=%0d error=%0d",sx_q,sy_q,x_nearest,y_nearest,in_bounds,source_addr,out_error);
   $display("expected xq=%0d yq=%0d ix=%0d iy=%0d inside=%0d addr=%0d error=%0d",$signed(scoreboard[2][4]),$signed(scoreboard[2][5]),$signed(scoreboard[2][6]),$signed(scoreboard[2][7]),scoreboard[2][8],$signed(scoreboard[2][9]),scoreboard[2][10]);
   $fatal(1,"coordinate/reference mismatch");
  end
  checked=checked+1;
  if (out_error) error_checked=error_checked+1;
 end
end

task send_record;
 begin
  @(negedge clk);
  in_valid=1;
  x_out=input_words[0][11:0]; y_out=input_words[1][11:0]; cos_q=input_words[2];sin_q=input_words[3];
  for(integer k=0;k<11;k=k+1) pending[k]=input_words[k];
  injected=injected+1;
 end
endtask
task bubble;
 begin @(negedge clk);in_valid=0;bubbles=bubbles+1;end
endtask

initial begin
 if (!$value$plusargs("vectors=%s",vector_file)) $fatal(1,"missing vectors argument");
 fd=$fopen(vector_file,"r");
 if (!fd) $fatal(1,"cannot open vector file");
 repeat(3) @(negedge clk);
 rst_n=1;
 while (!$feof(fd)) begin
  n=$fscanf(fd,"%h %h %h %h %h %h %h %h %h %h %h\n",input_words[0],input_words[1],input_words[2],input_words[3],input_words[4],input_words[5],input_words[6],input_words[7],input_words[8],input_words[9],input_words[10]);
  if(n!=11) $fatal(1,"malformed vector record");
  send_record();record_count=record_count+1;
  if(record_count%7==0) bubble();
 end
 $fclose(fd);
 bubble();repeat(4) @(negedge clk);
 if(checked!=injected) $fatal(1,"dropped/duplicate coordinate transaction");
 // Reset a request before it reaches the output; it must never leak after reset.
 send_record();
 @(negedge clk);rst_n=0;in_valid=0;reset_count=reset_count+1;
 #1;if(out_valid !== 0) $fatal(1,"async reset did not clear output valid");
 if(in_bounds !== 1'b0 || source_addr !== -32'sd1 || out_error !== 1'b0)
  $fatal(1,"async reset did not clear safe-read flags");
 repeat(2) @(negedge clk);
 rst_n=1;repeat(4) @(negedge clk);
 injected=checked;
 send_record();bubble();repeat(4) @(negedge clk);
 if(checked!=injected) $fatal(1,"reset recovery lost request");
 $display("TEST_PASS_COORD checked=%0d errors_checked=%0d bubbles=%0d resets=%0d",checked,error_checked,bubbles,reset_count);
 test_passed=1;
 $finish;
end
initial begin #2000000;$fatal(1,"timeout");end
endmodule
