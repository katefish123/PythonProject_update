`timescale 1ns/1ps
module tb_rotation_video_demo;
localparam integer HT=14,VT=9,W=8;
reg clk=0,rst_n=0;
reg signed [31:0] cos_q=65536,sin_q=0;
wire hsync,vsync,de,error;
wire [23:0] rgb;
rotation_video_demo dut(.clk(clk),.rst_n(rst_n),.cos_q(cos_q),.sin_q(sin_q),.hsync(hsync),.vsync(vsync),.de(de),.rgb(rgb),.error(error));
always #5 clk=~clk;

reg [23:0] expected_pixels[0:47];
reg [23:0] pixel_pipe[0:3];
reg [3:0] de_pipe=0,h_pipe=0,v_pipe=0,error_pipe=0;
reg error_mode=0,trace_enabled=1;
integer x_pipe[0:3],y_pipe[0:3];
integer ref_h=0,ref_v=0,checked_pixels=0,checked_cycles=0,total_pixels=0,total_cycles=0;
integer checked_error_pixels=0,total_error_pixels=0,total_cases=0;
integer trace_fd,angle=0,i;
integer test_passed=0;

always @(posedge clk) begin
 if(!rst_n) begin
  ref_h=0;ref_v=0;de_pipe=0;h_pipe=0;v_pipe=0;error_pipe=0;
  for(i=0;i<4;i=i+1) begin pixel_pipe[i]=0;x_pipe[i]=0;y_pipe[i]=0;end
 end else begin
  for(i=3;i>0;i=i-1) begin
   de_pipe[i]=de_pipe[i-1];h_pipe[i]=h_pipe[i-1];v_pipe[i]=v_pipe[i-1];error_pipe[i]=error_pipe[i-1];
   pixel_pipe[i]=pixel_pipe[i-1];x_pipe[i]=x_pipe[i-1];y_pipe[i]=y_pipe[i-1];
  end
  h_pipe[0]=(ref_h<2);v_pipe[0]=(ref_v<1);
  de_pipe[0]=(ref_h>=4&&ref_h<12&&ref_v>=2&&ref_v<8);
  error_pipe[0]=de_pipe[0]&&error_mode;
  x_pipe[0]=de_pipe[0] ? ref_h-4 : 0;
  y_pipe[0]=de_pipe[0] ? ref_v-2 : 0;
  pixel_pipe[0]=(de_pipe[0]&&!error_mode) ? expected_pixels[y_pipe[0]*W+x_pipe[0]] : 24'h000000;
  if(ref_h==HT-1) begin ref_h=0;ref_v=(ref_v==VT-1) ? 0 : ref_v+1;end
  else ref_h=ref_h+1;
 end
 #1;
 if(rst_n) begin
  checked_cycles=checked_cycles+1;
  if(hsync!==h_pipe[3]||vsync!==v_pipe[3]||de!==de_pipe[3]||rgb!==pixel_pipe[3]||error!==error_pipe[3]) begin
   $display("angle=%0d cycle=%0d pixel=(%0d,%0d) expected de=%b rgb=%h hs=%b vs=%b error=%b actual de=%b rgb=%h hs=%b vs=%b error=%b",angle,checked_cycles,x_pipe[3],y_pipe[3],de_pipe[3],pixel_pipe[3],h_pipe[3],v_pipe[3],error_pipe[3],de,rgb,hsync,vsync,error);
   $fatal(1,"video timing/pixel mismatch");
  end
  if(de) begin
   if(trace_enabled) $fdisplay(trace_fd,"%0d,%0d,%0d,%0d,%06h",angle,checked_pixels/48,x_pipe[3],y_pipe[3],rgb);
   checked_pixels=checked_pixels+1;
   if(error) checked_error_pixels=checked_error_pixels+1;
  end
 end
end

task run_angle(input integer a,input integer cq,input integer sq,input string file_name);
 begin
  @(negedge clk);rst_n=0;angle=a;cos_q=cq;sin_q=sq;error_mode=0;trace_enabled=1;
  #1;if(de!==0||rgb!==0||error!==0) $fatal(1,"video reset did not clear output");
  $readmemh(file_name,expected_pixels);
  repeat(3) @(negedge clk);
  checked_pixels=0;checked_cycles=0;checked_error_pixels=0;rst_n=1;
  repeat(HT*VT*2+4) @(negedge clk);
  if(checked_pixels!=96) $fatal(1,"video frame missing pixels");
  total_pixels=total_pixels+checked_pixels;total_cycles=total_cycles+checked_cycles;
  total_error_pixels=total_error_pixels+checked_error_pixels;total_cases=total_cases+1;
  $display("VIDEO_CASE_PASS angle=%0d pixels=%0d cycles=%0d",angle,checked_pixels,checked_cycles);
 end
endtask

task run_error_recovery;
 begin
  @(negedge clk);rst_n=0;angle=0;cos_q=65536;sin_q=0;error_mode=0;trace_enabled=0;
  #1;if(de!==0||rgb!==0||error!==0) $fatal(1,"video reset did not clear output");
  $readmemh("vectors/rotate_0_rgb.mem",expected_pixels);
  repeat(3) @(negedge clk);
  checked_pixels=0;checked_cycles=0;checked_error_pixels=0;rst_n=1;
  repeat(HT*VT) @(negedge clk);
  cos_q=65537;error_mode=1;
  repeat(HT*VT) @(negedge clk);
  cos_q=65536;error_mode=0;
  repeat(HT*VT+4) @(negedge clk);
  if(checked_pixels!=144||checked_error_pixels!=48||checked_cycles!=382)
   $fatal(1,"video error/recovery frame counts mismatch pixels=%0d error_pixels=%0d cycles=%0d",checked_pixels,checked_error_pixels,checked_cycles);
  total_pixels=total_pixels+checked_pixels;total_cycles=total_cycles+checked_cycles;
  total_error_pixels=total_error_pixels+checked_error_pixels;total_cases=total_cases+1;
  $display("VIDEO_ERROR_RECOVERY_PASS pixels=%0d cycles=%0d error_pixels=%0d",checked_pixels,checked_cycles,checked_error_pixels);
 end
endtask

initial begin
 trace_fd=$fopen("build/video_actual.csv","w");
 if(!trace_fd) $fatal(1,"cannot open actual pixel trace");
 $fdisplay(trace_fd,"angle,frame,x_output,y_output,rgb_hex");
 run_angle(0,65536,0,"vectors/rotate_0_rgb.mem");
 run_angle(30,56756,32768,"vectors/rotate_30_rgb.mem");
 run_angle(-30,56756,-32768,"vectors/rotate_minus_30_rgb.mem");
 run_angle(90,0,65536,"vectors/rotate_90_rgb.mem");
 run_angle(180,-65536,0,"vectors/rotate_180_rgb.mem");
 run_angle(270,0,-65536,"vectors/rotate_270_rgb.mem");
 run_error_recovery;
 @(negedge clk);rst_n=0;
 $fclose(trace_fd);
 $display("TEST_PASS_VIDEO pixels=%0d cycles=%0d cases=%0d error_pixels=%0d",total_pixels,total_cycles,total_cases,total_error_pixels);
 test_passed=1;
 $finish;
end
initial begin #100000;$fatal(1,"timeout");end
endmodule
